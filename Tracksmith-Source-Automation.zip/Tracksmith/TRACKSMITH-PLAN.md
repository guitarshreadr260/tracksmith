# Tracksmith development plan

Updated October 14, 2026.

Windows DAW using the current React/TypeScript interface with JUCE native audio. Custom UI design is deferred until more core features are complete. AVRX Drums is removed. AVRX Groove v0.17 is preserved separately for future work. AVRX NAM remains a separate guitar VST3.

## Working foundation

- WAV recording, multitrack playback, live processed monitoring and Volt/ASIO support.
- Save/Open, track naming, gain, pan, mute, solo, arming and master controls.
- Five VST3 inserts per track/master, plugin editors, saved states and bounded playback latency compensation.
- AVRX NAM guitar plugin, metronome, pre-roll and supported Windows editing shortcuts.
- Multiple clips, movement, trimming, splitting, deletion, undo/redo, beat snapping, selected-range looping and selection punch.
- General MIDI/instrument lanes, piano-roll note editing and MIDI import/export. Hardware MIDI recording remains pending.
- Stereo WAV export through the mix and plugins: full session/selection, 16/24-bit PCM, current sample rate, effects tail, progress/cancel and safe destination replacement. See EXPORT-GUIDE.md.

## Next builds

1. Recording: separate track inputs and simultaneous capture up to eight armed audio tracks are implemented. Next: hardware latency-aligned takes and multi-track live monitoring.
2. Routing: implemented stereo aux/bus tracks, two post-fader sends, source output selection, saved routing and aux-stage delay compensation. Next: pre-fader sends, nested buses, wider hardware routing and stereo channel meters.
3. Editing: fades/crossfades, take playlists and comping.
4. Plugin workflow: cached browser, loading recovery, sidechains and automation.
5. Reliability: large-session streaming, recovery, stress testing and installation packaging.
6. Custom UI: resume Main Arrangement design when the core workflow is further developed.

Export follow-ups: selectable sample-rate conversion, dithering/normalization, wider plugin compatibility tests. Current plugin instances are used exclusively while live playback is detached during export.

Recording update: existing clips play with live input through one track/master insert path; per-track input routes persist in sessions, and grouped capture shares count-in/punch boundaries. See RECORDING-GUIDE.md.

Routing milestone: see MIXER-ROUTING-GUIDE.md. Sessions now save as version 5 and read versions 1–4.

Implemented retakes, linear fades, crossfades and audio/MIDI playlists with selected-range comp copying. New saves use version 6 and read versions 1-5. See TAKES-PLAYLISTS-GUIDE.md. Loop playlists, ratings, playlist deletion/reordering and grouped comping remain future work.


Plugin browser milestone: cached per-bundle VST3 discovery in a child process, saved-name/manufacturer search, interrupted-loading recovery and preserved-state retry, plus Ctrl+Shift+N New Tracks dialog with quantity/name/input format. Next: volume/pan/plugin automation. Full plugin runtime isolation and folder scanning remain future work.


Automation milestone: audio/instrument/aux track volume and pan lanes, Off/Read/Write, buffered transport-clock capture, interval replacement and grouped automation undo, version 7 persistence, sample-level curve rendering and source/aux latency alignment. Plugin scanner deferred as requested. Next: plugin parameter automation and Touch/Latch.
