#include <juce_audio_utils/juce_audio_utils.h>
#include "NativeNam.h"
#include "NoiseGate.h"

class NamProcessor final : public juce::AudioProcessor, private juce::Thread, private juce::Timer
{
public:
    juce::AudioProcessorValueTreeState parameters;
    std::atomic<float> inputPeak { 0 }, outputPeak { 0 }, gateLevel { 1 };
    NamProcessor() : AudioProcessor(BusesProperties().withInput("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput("Output", juce::AudioChannelSet::stereo(), true)), Thread("AVRX NAM model loader"),
        parameters(*this, nullptr, "AVRX_NAM", layout())
    {
        inputGain = parameters.getRawParameterValue("input"); outputGain = parameters.getRawParameterValue("output");
        gateOn = parameters.getRawParameterValue("gate"); threshold = parameters.getRawParameterValue("threshold"); release = parameters.getRawParameterValue("release");
        bypass = parameters.getRawParameterValue("bypass"); startThread(); startTimerHz(20);
    }
    ~NamProcessor() override { stopTimer(); signalThreadShouldExit(); notify(); stopThread(-1); }
    const juce::String getName() const override { return "AVRX NAM"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return {}; }
    void changeProgramName(int, const juce::String&) override {}
    bool hasEditor() const override { return true; }
    juce::AudioProcessorEditor* createEditor() override;
    bool isBusesLayoutSupported(const BusesLayout& buses) const override
    {
        const auto input = buses.getMainInputChannelSet();
        return input == buses.getMainOutputChannelSet() && (input == juce::AudioChannelSet::mono() || input == juce::AudioChannelSet::stereo());
    }
    void prepareToPlay(double sampleRate, int block) override
    {
        const juce::ScopedLock lock(jobs);
        rate = sampleRate; maximumBlock = std::max(1, block); mono.setSize(1, maximumBlock.load()); gateGains.resize(static_cast<size_t>(maximumBlock.load())); gate.reset();
        smoothInput = juce::Decibels::decibelsToGain(inputGain->load()); smoothOutput = juce::Decibels::decibelsToGain(outputGain->load());
        if (model)
        {
            juce::String error; const bool prepared = model->prepare(sampleRate, maximumBlock.load(), error); usable = prepared && model->ready();
            if (!error.isEmpty()) { const juce::ScopedLock lock(jobs); message = error; }
        }
    }
    void releaseResources() override {}
    void processBlock(juce::AudioBuffer<float>& audio, juce::MidiBuffer&) override
    {
        juce::ScopedNoDenormals noDenormals;
        // Sequential-consistent gate lets the message thread replace/destruct DSP
        // without locking, waiting or freeing objects on the audio thread.
        readers.fetch_add(1);
        if (updating.load() || !usable.load() || bypass->load() > 0.5f || !model || audio.getNumSamples() > mono.getNumSamples())
        {
            float peak = 0; for(int ch=0;ch<audio.getNumChannels();++ch) for(int n=0;n<audio.getNumSamples();++n) peak=std::max(peak,std::abs(audio.getSample(ch,n)));
            inputPeak=peak;outputPeak=peak;gateLevel=1;readers.fetch_sub(1); return;
        } // Dry pass-through while loading/unavailable.
        const int count = audio.getNumSamples(); const float in = juce::Decibels::decibelsToGain(inputGain->load());
        const float out = juce::Decibels::decibelsToGain(outputGain->load());
        const float smoothing = static_cast<float>(1.0 - std::exp(-1.0 / (rate.load() * 0.005)));
        float rawPeak = 0, wetPeak = 0;
        const bool enabled = gateOn->load() > .5f; const float cutoff = threshold->load(), releaseTime = release->load();
        for (int n = 0; n < count; ++n)
        {
            smoothInput += smoothing * (in - smoothInput);
            float sample = 0; for (int ch = 0; ch < audio.getNumChannels(); ++ch) sample += audio.getSample(ch, n);
            sample /= static_cast<float>(audio.getNumChannels());
            rawPeak = std::max(rawPeak, std::abs(sample));
            gateGains[static_cast<size_t>(n)] = gate.next(sample, enabled, cutoff, releaseTime, rate.load());
            mono.setSample(0, n, sample * smoothInput);
        }
        model->process(mono, count);
        for (int n = 0; n < count; ++n)
        {
            smoothOutput += smoothing * (out - smoothOutput);
            const float sample = mono.getSample(0, n) * smoothOutput * gateGains[static_cast<size_t>(n)];
            wetPeak = std::max(wetPeak, std::abs(sample));
            for (int ch = 0; ch < audio.getNumChannels(); ++ch) audio.setSample(ch, n, sample);
        }
        inputPeak = rawPeak; outputPeak = wetPeak; gateLevel = gate.gain;
        readers.fetch_sub(1);
    }
    void requestCapture(const juce::File& file)
    {
        const juce::ScopedLock lock(jobs); requested = file;
        ++generation; requestPending = true; message = "Loading " + file.getFileName() + "..."; notify();
    }
    juce::String status() { const juce::ScopedLock lock(jobs); return message; }
    void getStateInformation(juce::MemoryBlock& destination) override
    {
        auto state = parameters.copyState();
        { const juce::ScopedLock lock(jobs); state.setProperty("modelPath", savedPath, nullptr); }
        copyXmlToBinary(*state.createXml(), destination);
    }
    void setStateInformation(const void* bytes, int count) override
    {
        if (auto xml = getXmlFromBinary(bytes, count))
        {
            auto state = juce::ValueTree::fromXml(*xml); if (!state.hasType("AVRX_NAM")) return;
            for (const auto& setting : { std::pair<const char*,float>{"gate",0}, {"threshold",-60}, {"release",120} })
            {
                bool found = false; for (int n=0;n<state.getNumChildren();++n) if(state.getChild(n).getProperty("id").toString()==setting.first) found=true;
                if(!found) { juce::ValueTree child("PARAM");child.setProperty("id",setting.first,nullptr);child.setProperty("value",setting.second,nullptr);state.appendChild(child,nullptr); }
            }
            parameters.replaceState(state);
            const auto path = state.getProperty("modelPath").toString();
            if (path.isNotEmpty() && juce::File::isAbsolutePath(path))
            { { const juce::ScopedLock lock(jobs); savedPath = path; } requestCapture(juce::File(path)); }
            else if (path.isEmpty()) requestCapture(juce::File());
        }
    }
private:
    static juce::AudioProcessorValueTreeState::ParameterLayout layout()
    {
        juce::AudioProcessorValueTreeState::ParameterLayout result;
        result.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("input", 1), "Input dB", -24.0f, 24.0f, 0.0f));
        result.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("output", 1), "Output dB", -24.0f, 12.0f, 0.0f));
        result.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID("bypass", 1), "Bypass", false));
        result.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID("gate",1), "Noise gate", false));
        result.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("threshold",1), "Gate threshold dBFS", -90.0f, -20.0f, -60.0f));
        result.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID("release",1), "Gate release ms", 20.0f, 500.0f, 120.0f)); return result;
    }
    void run() override
    {
        while (!threadShouldExit())
        {
            juce::File file; int job = 0;
            { const juce::ScopedLock lock(jobs); if (requestPending) { file = requested; job = generation; requestPending = false; } }
            if (job == 0) { wait(100); continue; }
            auto next = std::make_unique<NativeNam>(); juce::String error;
            const bool loaded = file == juce::File() || next->load(file, rate.load(), maximumBlock.load(), error, true);
            if (threadShouldExit()) return;
            const juce::ScopedLock lock(jobs);
            if (job != generation) continue;
            if (loaded) { pending = std::move(next); pendingGeneration = job; }
            else message = "Load failed: " + error + ". Previous model kept.";
        }
    }
    void timerCallback() override
    {
        const juce::ScopedLock lock(jobs);
        if (!pending) return;
        if (pendingGeneration != generation) { pending.reset(); updating = false; return; }
        updating = true;
        if (readers.load() != 0) return;
        juce::String error; const bool prepared = pending->prepare(rate.load(), maximumBlock.load(), error);
        model = std::move(pending); usable = prepared && model->ready();
        const bool pathChanged = savedPath != model->file().getFullPathName();
        savedPath = model->file().getFullPathName();
        message = usable ? "Loaded " + model->file().getFileName() + " · mono model"
                         : (model->file() == juce::File() ? "Load a .nam model. Audio passes through until a model is ready." : error);
        updating = false;
        if (pathChanged) updateHostDisplay(ChangeDetails().withNonParameterStateChanged(true));
    }
    std::atomic<float>* inputGain = nullptr; std::atomic<float>* outputGain = nullptr; std::atomic<float>* bypass = nullptr;
    std::atomic<double> rate { 48000.0 }; std::atomic<int> maximumBlock { 256 }, readers { 0 };
    std::atomic<bool> updating { false }, usable { false };
    float smoothInput = 1, smoothOutput = 1;
    NoiseGate gate; std::vector<float> gateGains;
    std::atomic<float>* gateOn = nullptr; std::atomic<float>* threshold = nullptr; std::atomic<float>* release = nullptr;
    juce::AudioBuffer<float> mono;
    std::unique_ptr<NativeNam> model, pending;
    juce::CriticalSection jobs; // Loader/message/state threads only.
    juce::File requested; juce::String savedPath, message { "Load a .nam model. Audio passes through until a model is ready." };
    bool requestPending = false; int generation = 0, pendingGeneration = 0;
};

class NamEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit NamEditor(NamProcessor& p) : AudioProcessorEditor(p), processor(p),
        inputAttachment(p.parameters, "input", input), outputAttachment(p.parameters, "output", output), bypassAttachment(p.parameters, "bypass", bypass), thresholdAttachment(p.parameters,"threshold",threshold), releaseAttachment(p.parameters,"release",release), gateAttachment(p.parameters,"gate",gate)
    {
        setSize(600, 450);
        title.setText("AVRX NAM", juce::dontSendNotification); title.setFont(juce::FontOptions(24.0f));
        for (auto* slider : { &input, &output, &threshold, &release }) { slider->setSliderStyle(juce::Slider::LinearHorizontal); slider->setTextBoxStyle(juce::Slider::TextBoxRight, false, 90, 24); slider->setTextValueSuffix(" dB"); addAndMakeVisible(slider); }
        threshold.setTextValueSuffix(" dBFS"); release.setTextValueSuffix(" ms");
        thresholdLabel.setText("Threshold", juce::dontSendNotification); releaseLabel.setText("Release", juce::dontSendNotification);
        gate.setButtonText("Noise gate"); addAndMakeVisible(gate);
        inputLabel.setText("Input", juce::dontSendNotification); outputLabel.setText("Output", juce::dontSendNotification);
        for (auto* label : { &title, &inputLabel, &outputLabel, &message, &thresholdLabel, &releaseLabel, &levels }) addAndMakeVisible(label);
        load.setButtonText("Load .nam model"); bypass.setButtonText("Bypass"); addAndMakeVisible(load); addAndMakeVisible(bypass);
        load.onClick = [this]
        {
            if (chooser) return;
            chooser = std::make_unique<juce::FileChooser>("Load a NAM capture", juce::File(), "*.nam");
            chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                [safe = juce::Component::SafePointer<NamEditor>(this)](const juce::FileChooser& selection)
                {
                    if (!safe) return; const auto file = selection.getResult(); if (file.existsAsFile()) safe->processor.requestCapture(file);
                    juce::MessageManager::callAsync([safe] { if (safe) safe->chooser.reset(); });
                });
        };
        startTimerHz(10); timerCallback();
    }
    void paint(juce::Graphics& g) override { g.fillAll(juce::Colour(0xff191c24)); }
    void resized() override
    {
        title.setBounds(20, 15, 300, 35); load.setBounds(20, 60, 180, 30); bypass.setBounds(350, 60, 160, 30);
        inputLabel.setBounds(20, 105, 65, 30); input.setBounds(85, 105, 425, 30);
        outputLabel.setBounds(20, 150, 65, 30); output.setBounds(85, 150, 425, 30); gate.setBounds(20,195,180,30);
        thresholdLabel.setBounds(20,235,80,30); threshold.setBounds(100,235,470,30);
        releaseLabel.setBounds(20,275,80,30); release.setBounds(100,275,470,30);
        levels.setBounds(20,315,550,30); message.setBounds(20,355,550,75);
    }
private:
    void timerCallback() override
    {
        message.setText(processor.status(), juce::dontSendNotification);
        levels.setText("Input " + juce::String(juce::Decibels::gainToDecibels(processor.inputPeak.load(), -90.0f),1)
            + " dBFS   Output " + juce::String(juce::Decibels::gainToDecibels(processor.outputPeak.load(), -90.0f),1)
            + " dBFS   Gate " + juce::String(juce::Decibels::gainToDecibels(processor.gateLevel.load(), -90.0f),1) + " dB", juce::dontSendNotification);
    }
    NamProcessor& processor;
    juce::Label title, inputLabel, outputLabel, message, thresholdLabel, releaseLabel, levels; juce::TextButton load; juce::ToggleButton bypass, gate;
    juce::Slider input, output, threshold, release;
    juce::AudioProcessorValueTreeState::SliderAttachment inputAttachment, outputAttachment, thresholdAttachment, releaseAttachment;
    juce::AudioProcessorValueTreeState::ButtonAttachment bypassAttachment, gateAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
};
juce::AudioProcessorEditor* NamProcessor::createEditor() { return new NamEditor(*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new NamProcessor(); }
