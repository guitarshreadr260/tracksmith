#include "../source/PluginRack.h"
#include "../source/MixExport.h"
#include "../source/GrooveWorker.h"
#include "../source/SessionFile.h"
#include "../source/AudioEngine.h"
#include <iostream>
#include "../plugins/AvrxNam/NoiseGate.h"
#include <cstdlib>
static void require(bool value, const char* message) { if (!value) { std::cerr << "FAIL: " << message << '\n'; std::exit(1); } }
static bool near(float a, float b) { return std::abs(a - b) < 0.0001f; }
int main(int argc, char** argv)
{
    NoiseGate gate;
    for(int n=0;n<96000;++n)gate.next(.000063f,true,-60,120,48000);
    require(gate.gain<.00001f,"gate suppresses low idle noise");
    for(int n=0;n<480;++n)gate.next(.1f,true,-60,120,48000);
    require(gate.gain>.999f,"gate opens for instrument attack");
    for(int n=0;n<96000;++n)gate.next(0,true,-60,120,48000);
    require(gate.gain<.00001f,"gate releases smoothly to silence");
    for(int n=0;n<480;++n)gate.next(0,false,-60,120,48000);
    require(gate.gain>.999f,"disabled gate passes sustained quiet input");
    juce::ScopedJuceInitialiser_GUI gui;
    require(argc > 2, "provide stock NAM and delay-test VST3 paths");
    const auto folder = juce::File::getCurrentWorkingDirectory().getChildFile("work/plugin-tests");
    require(folder.createDirectory().wasOk(), "test folder");
    const auto capture = folder.getChildFile("Linear.nam");
    require(capture.replaceWithText(R"({"version":"0.5.4","architecture":"Linear","sample_rate":48000,"config":{"receptive_field":1,"bias":false},"weights":[0.5]})"), "linear model fixture");
    PluginRack rack;
    juce::OwnedArray<juce::PluginDescription> descriptions;
    rack.formats.getFormat(0)->findAllTypesForFile(descriptions, juce::String(argv[1]));
    require(descriptions.size() == 1 && descriptions[0]->name == "AVRX NAM", "scan actual stock VST3");
    juce::String error;
    auto instance = rack.formats.createPluginInstance(*descriptions[0], 48000, 256, error);
    require(instance != nullptr, "instantiate actual stock VST3");
    auto state = juce::ValueTree("AVRX_NAM"); state.setProperty("modelPath", capture.getFullPathName(), nullptr);
    juce::MemoryBlock component; juce::AudioProcessor::copyXmlToBinary(*state.createXml(), component);
    juce::XmlElement hostState("VST3PluginState"); hostState.createNewChildElement("IComponent")->addTextElement(component.toBase64Encoding());
    juce::MemoryBlock bytes; juce::AudioProcessor::copyXmlToBinary(hostState, bytes);
    require(rack.install(0, 0, *descriptions[0], std::move(instance), bytes, false, 48000).wasOk(), "install stock VST3");
    float left[256], right[256];
    auto render = [&]
    {
        std::fill_n(left, 256, 0.4f); std::fill_n(right, 256, 0.4f);
        PluginRack::process(&rack, 0, left, right, 256, 1.0, 120.0, true);
    };
    bool loaded = false;
    for (int i = 0; i < 100 && !loaded; ++i)
    {
        juce::MessageManager::getInstance()->runDispatchLoopUntil(30); render(); loaded = near(left[255], 0.2f);
    }
    require(loaded && near(right[255], 0.2f), "worker-loaded NAM produces expected linear DSP samples");
    render(); require(near(left[0], 0.2f), "model runs at block start");
    require(near(static_cast<float>(*rack.clock.getPosition()->getTimeInSeconds()), 1.0f), "VST3 host publishes transport time");
    rack.channels[0][0]->bypass = true; render(); require(near(left[255], 0.4f), "host bypass passes stereo through"); rack.channels[0][0]->bypass = false;
    const auto saved = rack.save(); require(saved.size() == 1, "insert state saved");
    juce::MemoryBlock retained; require(retained.fromBase64Encoding(saved[0].getProperty("state", {}).toString()), "state base64 decodes");
    auto second = rack.formats.createPluginInstance(*descriptions[0], 48000, 256, error);
    require(second != nullptr && rack.install(0, 1, *descriptions[0], std::move(second), retained, false, 48000).wasOk(), "second independent instance restores state");
    loaded = false;
    for (int i = 0; i < 100 && !loaded; ++i) { juce::MessageManager::getInstance()->runDispatchLoopUntil(30); render(); loaded = near(left[255], 0.1f); }
    require(loaded, "two independent inserts process in serial order");
    rack.channels[0][1].reset();
    const auto setParameter=[&](const juce::String& id,float value)
    {
        for(auto* parameter:rack.channels[0][0]->instance->getParameters())
            if(parameter->getName(100)==(id=="gate"?"Noise gate":id=="threshold"?"Gate threshold dBFS":"Gate release ms"))
            {parameter->setValueNotifyingHost(id=="gate"?value:id=="threshold"?(value+90)/70:(value-20)/480);return;}
        require(false,"NAM gate parameter exposed through VST3");
    };
    setParameter("gate",1); setParameter("threshold",-55);setParameter("release",80);
    for(int i=0;i<400;++i){std::fill_n(left,256,.000063f);std::fill_n(right,256,.000063f);PluginRack::process(&rack,0,left,right,256,0,120,false);}
    require(std::abs(left[255])<1.e-8f,"actual NAM gate suppresses amplified idle input");
    for(int i=0;i<4;++i)render();require(near(left[255],.2f),"actual NAM gate opens for performance");
    const auto gateState=rack.save();juce::MemoryBlock gateBytes;require(gateBytes.fromBase64Encoding(gateState[0].getProperty("state",{}).toString()),"gate state serializes");
    setParameter("gate",0);rack.channels[0][0]->instance->setStateInformation(gateBytes.getData(),static_cast<int>(gateBytes.getSize()));
    for(int i=0;i<400;++i){std::fill_n(left,256,.000063f);std::fill_n(right,256,.000063f);PluginRack::process(&rack,0,left,right,256,0,120,false);}
    require(std::abs(left[255])<1.e-8f,"NAM gate settings restore with plugin state");
    setParameter("gate",0); for(int i=0;i<4;++i)render();

    const auto malformedModel = folder.getChildFile("Malformed.nam"); require(malformedModel.replaceWithText("{bad json"), "bad model fixture");
    state.setProperty("modelPath", malformedModel.getFullPathName(), nullptr);
    juce::AudioProcessor::copyXmlToBinary(*state.createXml(), component);
    juce::XmlElement malformedState("VST3PluginState"); malformedState.createNewChildElement("IComponent")->addTextElement(component.toBase64Encoding());
    juce::MemoryBlock malformedBytes; juce::AudioProcessor::copyXmlToBinary(malformedState, malformedBytes);
    rack.channels[0][0]->instance->setStateInformation(malformedBytes.getData(), static_cast<int>(malformedBytes.getSize()));
    for(int i=0;i<20;++i) { juce::MessageManager::getInstance()->runDispatchLoopUntil(30);render(); }
    require(near(left[255],0.2f),"malformed NAM load keeps previously active DSP");
    require(rack.install(128, 0, *descriptions[0], nullptr, retained, true, 48000).wasOk(), "unavailable insert placeholder retained");
    require(rack.snapshot(1).size() == 2 && static_cast<bool>(rack.snapshot(1)[1].getProperty("missing", false)), "missing insert visible in mixer");
    require(rack.save()[1].getProperty("state", {}).toString() == retained.toBase64Encoding(), "missing plugin state survives save");
    SavedSession session; session.tracks.push_back({ "Guitar", {} }); session.inserts = rack.save();
    SavedSession restored; const auto file = folder.getChildFile("Plugin.tracksmith");
    require(SessionFile::decode(SessionFile::encode(session, file), file, restored).wasOk() && restored.inserts.size() == 2, "plugin session roundtrip");
    auto invalid = SessionFile::encode(session, file); auto entries = invalid.getProperty("inserts", {});
    entries.getArray()->add(entries.getArray()->getReference(0)); require(SessionFile::decode(invalid, file, restored).failed(), "duplicate insert slots reject");
    juce::AudioBuffer<float> audio(2, 48000 * 8); audio.clear();
    for (int beat = 0; beat < 16; ++beat) for (int n = 0; n < 4000; ++n)
    {
        const float sample = static_cast<float>(0.8 * std::exp(-n / 700.0) * std::sin(6.283185307179586 * 80 * n / 48000));
        audio.setSample(0, beat * 24000 + n, sample); audio.setSample(1, beat * 24000 + n, -sample);
    }
    const auto groove = GrooveAnalysis::analyse(audio, 48000);
    require(groove.valid && groove.onsetCount >= 12 && std::abs(groove.bpm - 120) <= 2, "AVRX GROOVE detects synthetic drum tempo without stereo cancellation");
    const auto midiPath = folder.getChildFile("Suggested.mid"); require(GrooveWorker::exportMidi(groove, midiPath).wasOk(), "MIDI suggestion exports");
    juce::FileInputStream stream(midiPath); juce::MidiFile midi;
    require(midi.readFrom(stream) && midi.getNumTracks() == 2 && midi.getTimeFormat() == 960, "MIDI export reopens with tempo and notes");
    int notes = 0;
    for (int n = 0; n < midi.getTrack(1)->getNumEvents(); ++n)
    {
        const auto& message = midi.getTrack(1)->getEventPointer(n)->message;
        if (message.isNoteOn()) { ++notes; require(message.getChannel() == 10 && (message.getNoteNumber() == 36 || message.getNoteNumber() == 38 || message.getNoteNumber() == 42), "GM drum mapping"); }
    }
    require(notes > 0, "MIDI contains drum notes");
    audio.clear(); require(!GrooveAnalysis::analyse(audio, 48000).valid, "silent take rejected");
    require(!GrooveAnalysis::analyse(audio, 48000, 1.0f, [] { return true; }).valid, "analysis can cancel on shutdown");
    {
        PluginRack delays; juce::OwnedArray<juce::PluginDescription> delayDescriptions;
        delays.formats.getFormat(0)->findAllTypesForFile(delayDescriptions, juce::String(argv[2]));
        require(delayDescriptions.size()==1,"scan real 512-sample delay VST3");
        auto delayed = delays.formats.createPluginInstance(*delayDescriptions[0],48000,256,error);
        require(delayed != nullptr,"instantiate delay VST3");
        require(delays.install(1,0,*delayDescriptions[0],std::move(delayed),{},false,48000).wasOk(),"delay insert installation");
        require(delays.channels[1][0]->instance->getLatencySamples()==512,"prepared VST3 reports setLatencySamples value");
        PlaybackCore mix;mix.process=PluginRack::process;mix.processContext=&delays;
        for(size_t channel=0;channel<2;++channel)
        {
            auto& track=mix.tracks[channel];track.sourceRate=48000;track.gain=1;track.smoothLeft=track.smoothRight=1;
            track.left.assign(512,0);track.right.assign(512,0);
            track.left[0]=track.left[511]=channel==0?0.2f:0.4f;
            track.right[0]=track.right[511]=channel==0?0.3f:0.5f;
        }
        mix.refreshDuration();delays.rebuildCompensation(mix);mix.playbackLatencyFrames=delays.totalLatency;mix.playing=true;
        require(delays.totalLatency==512&&delays.compensation[0].samples()==512&&delays.compensation[1].samples()==0,"fast track receives exact latency difference");
        float l[512],r[512];float* outputs[]{l,r};mix.render(outputs,2,512);
        require(l[0]==0&&l[511]==0&&r[511]==0&&mix.playing,"latency warm-up remains silent with transport active");
        mix.render(outputs,2,512);
        require(near(l[0],0.6f)&&near(r[0],0.8f)&&near(l[511],0.6f)&&near(r[511],0.8f),"stereo impulses align and last delayed samples drain");
        require(!mix.playing&&std::abs(mix.seconds.load()-512.0/48000)<1e-9,"audible clock reaches source end after compensation flush");
        auto master=delays.formats.createPluginInstance(*delayDescriptions[0],48000,256,error);
        require(delays.install(128,0,*delayDescriptions[0],std::move(master),{},false,48000).wasOk(),"master delay install");
        for(size_t channel=0;channel<2;++channel) { std::fill(mix.tracks[channel].left.begin(),mix.tracks[channel].left.end(),0);std::fill(mix.tracks[channel].right.begin(),mix.tracks[channel].right.end(),0); }
        mix.metronome=true;mix.reset();delays.resetGraph();delays.rebuildCompensation(mix);mix.playbackLatencyFrames=delays.totalLatency;mix.playing=true;
        require(delays.totalLatency==1024&&delays.compensation[PluginRack::clickChannel].samples()==512,"metronome and shared master latency included");
        PlaybackCore reference;reference.tracks[0].left.assign(512,0);reference.tracks[0].right.assign(512,0);reference.refreshDuration();reference.metronome=true;reference.playing=true;
        float expectedL[512],expectedR[512];float* expected[]{expectedL,expectedR};reference.render(expected,2,512);
        mix.render(outputs,2,512);require(l[511]==0,"master delays compensated click further");mix.render(outputs,2,512);require(l[511]==0,"complete graph latency warm-up");mix.render(outputs,2,512);
        for(int n=0;n<512;++n)require(near(l[n],expectedL[n])&&near(r[n],expectedR[n]),"metronome samples align through compensation and master insert");
        delays.channels[1][0]->bypass=true;delays.channels[128][0]->bypass=true;delays.rebuildCompensation(mix);
        require(delays.totalLatency==0&&delays.compensation[0].samples()==0,"bypass rebuild removes latency and compensation");
        delays.channels[1][0]->bypass=false;delays.channels[1][0]->instance->setLatencySamples(1024);
        require(delays.latencyChanged(),"dynamic reported latency change is detected");delays.rebuildCompensation(mix);
        require(delays.totalLatency==1024&&delays.compensation[0].samples()==1024,"dynamic latency rebuild updates compensation buffers");
        delays.channels[1][0]->instance->setLatencySamples(PluginRack::maximumPathLatency+1);delays.rebuildCompensation(mix);
        require(delays.channels[1][0]->bypass&&delays.totalLatency==0,"excessive dynamic latency bypasses offending insert");
    }
    {
        AudioEngine engine;juce::String error;
        auto trackNam=engine.plugins.formats.createPluginInstance(*descriptions[0],48000,256,error);
        auto masterNam=engine.plugins.formats.createPluginInstance(*descriptions[0],48000,256,error);
        require(trackNam&&masterNam,"instantiate track and master NAM for live monitoring");
        require(engine.plugins.install(0,0,*descriptions[0],std::move(trackNam),retained,false,48000).wasOk(),"live track NAM installs");
        require(engine.plugins.install(128,0,*descriptions[0],std::move(masterNam),retained,false,48000).wasOk(),"live master NAM installs");
        float input[512],l[512],r[512];std::fill_n(input,512,0.4f);const float* inputs[]{input};float* outputs[]{l,r};
        engine.monitor.enabled=true;engine.monitor.gain=1;engine.monitor.track=0;engine.playback.tracks[0].gain=1;
        bool wet=false;
        for(int n=0;n<100&&!wet;++n){juce::MessageManager::getInstance()->runDispatchLoopUntil(30);engine.renderAudio(inputs,1,outputs,2,512);wet=near(l[511],0.1f);}
        require(wet&&near(r[511],0.1f)&&engine.playback.seconds==0,"stopped transport monitors input through both actual NAM VST3s");
        engine.playback.tracks[0].left.assign(48000,0.8f);engine.playback.tracks[0].right.assign(48000,0.8f);
        engine.playback.tracks[1].left.assign(48000,0.3f);engine.playback.tracks[1].right.assign(48000,0.3f);engine.playback.tracks[1].gain=1;
        engine.playback.refreshDuration();engine.playback.playing=true;
        for(int n=0;n<10;++n)engine.renderAudio(inputs,1,outputs,2,512);
        require(near(l[511],0.45f)&&near(r[511],0.45f),"own clip and live input share one track insert and one master pass alongside backing");
        engine.monitor.gain=0;for(int n=0;n<10;++n)engine.renderAudio(inputs,1,outputs,2,512);
        require(near(l[511],.35f),"monitor level zero silences live input while own clip and backing continue through plugins");
        engine.monitor.gain=1;
        engine.playback.tracks[0].muted=true;for(int n=0;n<10;++n)engine.renderAudio(inputs,1,outputs,2,512);
        require(near(l[511],0.15f),"monitored track mute leaves backing audio audible");
        engine.playback.tracks[0].muted=false;engine.playback.tracks[0].solo=true;for(int n=0;n<10;++n)engine.renderAudio(inputs,1,outputs,2,512);
        require(near(l[511],0.3f),"monitored track solo keeps own clip and live input but excludes backing tracks");
        engine.plugins.channels[128][0]->bypass=true; // NAM intentionally sums its input to mono; test pan without that master model.
        engine.playback.tracks[0].pan=1;for(int n=0;n<10;++n)engine.renderAudio(inputs,1,outputs,2,512);
        require(std::abs(l[511])<0.0001f&&near(r[511],0.6f),"monitored track pan follows plugin chain");
        const auto file=folder.getChildFile("DryWhileWet-"+juce::Uuid().toString()+".wav");
        require(engine.recorder.start(file,48000,1,10000).wasOk(),"dry recorder starts during wet monitoring");
        engine.renderAudio(inputs,1,outputs,2,512);engine.recorder.requestStop();require(engine.recorder.waitForFinish(10000),"dry take finalizes");
        juce::WavAudioFormat format;std::unique_ptr<juce::AudioFormatReader> reader(format.createReaderFor(new juce::FileInputStream(file),true));
        float raw[512];float* samples[]{raw};require(reader&&reader->read(samples,1,0,512),"dry take reopens");
        require(near(raw[511],0.4f),"recorded WAV stays dry while monitor output is plugin processed");
        float quiet[512] {}; const float* fourInputs[] { quiet, quiet, quiet, input };
        engine.inputSource=3;for(int n=0;n<10;++n)engine.renderAudio(fourInputs,4,outputs,2,512);
        require(near(engine.inputChannelPeaks[3],0.4f)&&engine.inputChannelPeaks[0]==0&&near(r[511],0.6f),"fourth enabled input is metered and monitored through track plugins");
        engine.monitor.enabled=false;engine.playback.playing=false;engine.renderAudio(inputs,1,outputs,2,512);
        require(l[511]==0&&r[511]==0,"monitor off stops live plugin output");
    }
    {
        AudioEngine engine; engine.playback.deviceRate=48000; engine.playback.bpm=123;
        const auto file=folder.getChildFile("CountIn-"+juce::Uuid().toString()+".wav");
        require(engine.recorder.start(file,48000,1,10000).wasOk(),"count-in recorder prepares");
        engine.countIn.start(1,48000,123); engine.playback.recording=true;
        const auto prefix=engine.countIn.total; int64_t rendered=0;
        float input[256],l[256],r[256];std::fill_n(input,256,.25f);const float* inputs[]{input};float* outputs[]{l,r};bool heard=false;
        while(rendered<prefix+256){engine.renderAudio(inputs,1,outputs,2,256);rendered+=256;for(auto sample:l)heard=heard||std::abs(sample)>.01f;}
        require(heard,"count-in sounds even when metronome is off");
        engine.recorder.requestStop();require(engine.recorder.waitForFinish(10000),"count-in take finalizes");const auto result=engine.recorder.takeResult();
        require(result.frames==static_cast<uint64_t>(rendered-prefix),"capture starts on exact sample inside callback");
        juce::WavAudioFormat format;std::unique_ptr<juce::AudioFormatReader> reader(format.createReaderFor(new juce::FileInputStream(file),true));
        float dry[256];float* samples[]{dry};require(reader&&reader->read(samples,1,0,256)&&near(dry[0],.25f)&&near(dry[255],.25f),"count-in clicks excluded from raw recording");
        engine.countIn.start(2,48000,120);engine.stopRecording(true);require(engine.countInCancelled&&engine.countIn.remaining(1)==0,"stop cancels count-in");
    }
    {
        std::vector<TimelineClip> clips{{1,0,1,.25,1}};
        require(ClipLayout::edit(clips,1,"split",1.5,2)&&clips.size()==2&&clips[1].offset==.75,"split preserves source offset");
        require(ClipLayout::edit(clips,2,"move",3,3)&&clips[1].start==3,"clip move changes timeline only");
        require(ClipLayout::edit(clips,2,"trimLeft",3.1,3)&&std::abs(clips[1].offset-.85)<1.e-9,"left trim advances source offset");
        require(!ClipLayout::edit(clips,2,"trimLeft",4,3),"invalid trim keeps clip");
        require(ClipLayout::edit(clips,1,"delete",0,3)&&clips.size()==1,"delete preserves other clips");
        AudioEngine engine;auto& track=engine.playback.tracks[0];
        track.left.assign(1024,.1f);track.right=track.left;track.sourceRate=48000;track.gain=1;track.timelineEnabled=true;track.clips={{1,0,0,0,1024.0/48000}};
        engine.playback.deviceRate=48000;engine.playback.refreshDuration();engine.playback.reset();track.smoothLeft=track.smoothRight=1;
        engine.playback.playing=true;engine.playback.recording=true;engine.planTrack=0;engine.recordPlanActive=true;engine.punchBegin=100;engine.punchEnd=500;
        const auto file=folder.getChildFile("Punch-"+juce::Uuid().toString()+".wav");require(engine.recorder.start(file,48000,1,10000).wasOk(),"punch recorder prepares");
        float input[768],l[768],r[768];std::fill_n(input,768,.25f);const float* in[]{input};float* out[]{l,r};engine.renderAudio(in,1,out,2,768);
        require(near(l[99],.1f)&&l[100]==0&&l[499]==0&&near(l[500],.1f),"punch suppresses armed backing only inside exact selection");
        require(engine.recorder.waitForFinish(10000),"punch-out automatically finalizes WAV");const auto result=engine.recorder.takeResult();require(result.frames==400,"punch captures only selected sample range");
        auto wav=decodeWav(file,10000,[]{return false;});require(wav.error.isEmpty()&&near(wav.left[0],.25f)&&near(wav.left[399],.25f),"punch take stays dry");
        engine.install(0,wav,true,100.0/48000,true,500.0/48000,true);
        require(track.clips.size()==3&&near(track.sample(99.0/48000,false),.1f)&&near(track.sample(100.0/48000,false),.25f)&&near(track.sample(499.0/48000,false),.25f)&&near(track.sample(500.0/48000,false),.1f),"punch clip preserves audio before and after selection");
        require(engine.playback.playing.load(),"punch clip install preserves continuing playback");
        // Clips from independent files share the existing track insert/fader path.
        track.clips={{1,0,.01,.001,.003},{2,1,.02,0,.004}};engine.playback.refreshDuration();
        require(track.sample(0,false)==0&&near(track.sample(.011,false),.1f)&&near(track.sample(.021,false),.25f)&&track.sample(.025,false)==0,"multi-source clips play gaps and offsets correctly");
        engine.monitor.enabled=true;engine.monitor.gain=1;engine.punchEnabled=true;engine.playback.playing=true;engine.playback.recording=false;
        engine.renderAudio(in,1,out,2,128);require(!engine.monitorActive.load(),"punch playback uses existing clips outside capture window");
        engine.playback.playing=false;engine.renderAudio(in,1,out,2,128);require(engine.monitorActive.load(),"stopped punch transport still permits live setup monitoring");
        {
            auto second=file.getSiblingFile("Second-"+juce::Uuid().toString()+".wav");require(file.copyFileTo(second),"second source fixture");
            SavedSession session;SessionTrack lane;lane.name="Edited lane";lane.audioFile=file;lane.sources={file,second};lane.timelineEnabled=true;
            lane.clips={{1,0,0,0,100.0/48000},{2,1,200.0/48000,50.0/48000,150.0/48000}};session.tracks.push_back(lane);
            const auto project=folder.getChildFile("Timeline-"+juce::Uuid().toString()+".tracksmith");require(SessionFile::write(project,SessionFile::encode(session,project)).wasOk(),"edited session saves");
            SessionWorker worker;bool finished=false;SessionJobResult loaded;
            worker.onFinished=[&](SessionJobResult result){loaded=std::move(result);finished=true;};require(worker.open(project),"multi-source session worker starts");
            for(int n=0;n<100&&!finished;++n)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
            require(finished&&loaded.error.isEmpty()&&loaded.extraAudio[0].size()==1&&loaded.extraAudio[0][0],"worker decodes every source off audio thread");
            AudioEngine restored;restored.installSession(loaded);require(restored.playback.tracks[0].clips.size()==2&&near(restored.playback.tracks[0].sample(250.0/48000,false),.25f),"session install restores independent source offsets");
            session.tracks[0].clips[0].length=10;require(SessionFile::write(project,SessionFile::encode(session,project)).wasOk(),"out-of-file bounds fixture writes structurally");
            finished=false;require(worker.open(project),"invalid source length worker starts");for(int n=0;n<100&&!finished;++n)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
            require(finished&&loaded.error.isNotEmpty(),"worker rejects clips beyond source duration before install");
        }
        auto before=track.clips;ClipLayout::edit(track.clips,1,"delete",0,3);track.clips=before;require(track.clips.size()==2,"restoring clip history leaves source samples available");
    }
    {
        MidiLane lane;lane.enabled=true;lane.notes={{1,36,10,.25,.5,.9f}};juce::MidiBuffer midi;midi.ensureSize(65536);
        lane.emit(midi,.12,120,48000,512,true);bool on=false;for(const auto event:midi)if(event.getMessage().isNoteOn()){on=true;require(event.samplePosition==240,"MIDI note starts at exact sample offset");}require(on,"scheduled MIDI note emitted");
        lane.emit(midi,.25,120,48000,256,true);on=false;for(const auto event:midi)on=on||event.getMessage().isNoteOn();require(on,"seeking into held note chases note-on");
        lane.emit(midi,.37,120,48000,512,true);bool off=false;for(const auto event:midi)if(event.getMessage().isNoteOff()){off=true;require(event.samplePosition==240,"MIDI note-off uses exact sample offset");}require(off,"scheduled MIDI note released");
        lane.emit(midi,0,120,48000,256,false);require(!midi.isEmpty(),"stop sends MIDI panic");lane.emit(midi,0,120,48000,256,false);require(midi.isEmpty(),"stopped blocks do not repeatedly cancel pad audition");

    }
    {
        // Exercise the WAV writer through an actual VST3 on the track and master.
        PluginRack exportRack; juce::OwnedArray<juce::PluginDescription> found;
        exportRack.formats.getFormat(0)->findAllTypesForFile(found,juce::String(argv[2]));
        require(found.size()==1,"scan export delay fixture");
        auto core=std::make_unique<PlaybackCore>(); core->deviceRate=48000;
        auto& track=core->tracks[0];track.left.assign(4800,.4f);track.right.assign(4800,.4f);track.gain=1;
        core->refreshDuration(); core->process=PluginRack::process;core->processContext=&exportRack;
        for(size_t channel : {size_t(0),PlaybackCore::maxTracks})
        {
            auto instance=exportRack.formats.createPluginInstance(*found[0],48000,256,error);
            require(instance!=nullptr,"create actual VST3 for export");
            require(exportRack.install(channel,0,*found[0],std::move(instance),{},false,48000).wasOk(),"install export VST3");
        }
        exportRack.rebuildCompensation(*core); core->playbackLatencyFrames=exportRack.totalLatency;exportRack.resetGraph();
        const auto output=folder.getChildFile("VST3-mix.wav");
        const auto result=writeMixWav(*core,output,{0,.1,0,24},{},{});
        require(result.error.isEmpty()&&result.frames==4800,"actual VST3 export succeeds");
        juce::WavAudioFormat wav;std::unique_ptr<juce::AudioFormatReader> reader(wav.createReaderFor(output.createInputStream().release(),true));
        juce::AudioBuffer<float> audio(2,4800);require(reader&&reader->read(&audio,0,4800,0,true,true),"reopen VST3-rendered WAV");
        require(near(audio.getSample(0,0),.4f)&&near(audio.getSample(1,4799),.4f),"real track/master VST3 latency compensated across whole export");
    }
    {
        AudioEngine engine;engine.playback.deviceRate=48000;
        auto& a=engine.playback.tracks[0];auto& b=engine.playback.tracks[1];
        a.left.assign(1024,.1f);a.right=a.left;a.sourceRate=48000;a.timelineEnabled=true;a.clips={{1,0,0,0,1024.0/48000}};
        b.left.assign(1024,.2f);b.right=b.left;b.sourceRate=48000;b.timelineEnabled=true;b.clips={{1,0,0,0,1024.0/48000}};
        engine.playback.refreshDuration();engine.playback.reset();
        engine.playback.recordTracks[0]=engine.playback.recordTracks[1]=true;
        engine.playback.recording=true;engine.playback.playing=true;engine.planTrack=0;engine.recordPlanActive=true;engine.punchBegin=100;engine.punchEnd=500;
        auto first=folder.getChildFile("Multi-A-"+juce::Uuid().toString()+".wav"),second=folder.getChildFile("Multi-B-"+juce::Uuid().toString()+".wav");
        require(engine.recorder.startGroup({{0,0,1,first},{1,1,1,second}},48000,10000).wasOk(),"start simultaneous independently routed mono tracks");
        float one[768],two[768],l[768],r[768];for(int n=0;n<768;++n){one[n]=static_cast<float>(n)/1000;two[n]=-.25f;}
        const float* in[]{one,two};float* out[]{l,r};engine.renderAudio(in,2,out,2,768);
        require(engine.recorder.waitForFinish(10000),"simultaneous punch finalizes all writers");auto takes=engine.recorder.takeResults();
        require(takes.size()==2&&takes[0].track==0&&takes[1].track==1&&takes[0].take.frames==400&&takes[1].take.frames==400,"all tracks capture identical sample-exact punch boundaries");
        auto wavA=decodeWav(first,10000,[]{return false;}),wavB=decodeWav(second,10000,[]{return false;});
        require(wavA.error.isEmpty()&&wavB.error.isEmpty()&&near(wavA.left[0],.1f)&&near(wavA.left[399],.499f)&&near(wavB.left[0],-.25f)&&near(wavB.left[399],-.25f),"each captured file has its own dry input from the same clock");
        require(l[100]==0&&l[499]==0&&l[700]>.1f,"punch suppresses both armed clips only inside selection");
        engine.install(0,wavA,true,100.0/48000,true,500.0/48000);
        engine.install(1,wavB,true,100.0/48000,true,500.0/48000);
        require(near(a.sample(99.0/48000,false),.1f)&&near(b.sample(99.0/48000,false),.2f)&&near(b.sample(100.0/48000,false),-.25f)&&near(b.sample(500.0/48000,false),.2f),"simultaneous takes install at the same timeline position and preserve surrounding clips");
        const auto stereo=folder.getChildFile("Multi-stereo-"+juce::Uuid().toString()+".wav");
        require(engine.recorder.startGroup({{0,0,2,stereo},{1,1,1,folder.getChildFile("Multi-mono-"+juce::Uuid().toString()+".wav")}},48000,256).wasOk(),"mixed stereo and mono capture");
        engine.recorder.capture(in,2,256);require(engine.recorder.waitForFinish(10000),"shared frame limit finalizes mixed capture");takes=engine.recorder.takeResults();
        auto pair=decodeWav(stereo,10000,[]{return false;});require(pair.error.isEmpty()&&near(pair.left[200],.2f)&&near(pair.right[200],-.25f)&&takes[1].take.frames==256,"stereo pair and independent mono input remain separate");
        require(engine.recorder.startGroup({{0,0,1,first},{0,1,1,second}},48000,10000).failed(),"duplicate armed destinations reject");
        std::vector<RecordRoute> routes;for(int id=0;id<8;++id)routes.push_back({id,id%2,1,folder.getChildFile("Eight-"+juce::Uuid().toString()+".wav")});
        require(engine.recorder.startGroup(routes,48000,256).wasOk(),"eight armed tracks prepare independent writers");
        engine.recorder.capture(in,2,256);require(engine.recorder.waitForFinish(10000),"eight tracks finalize");takes=engine.recorder.takeResults();
        require(takes.size()==8,"eight takes retained");for(const auto& item:takes){auto decoded=decodeWav(item.take.file,10000,[]{return false;});require(item.take.frames==256&&decoded.error.isEmpty()&&near(decoded.left[200],item.track%2?-.25f:.2f),"eight tracks retain assigned input and sample count");}
        WavLoader sequential;int imported=0;bool queued=true;
        sequential.onLoaded=[&](LoadedWav wav){require(wav.error.isEmpty()&&wav.left.size()==256,"queued take imports decode fully");++imported;if(imported<static_cast<int>(takes.size()))queued=sequential.load(takes[imported].take.file,10000);};
        require(sequential.load(takes[0].take.file,10000),"start queued take imports");
        for(int attempt=0;attempt<200&&imported<8&&queued;++attempt)juce::MessageManager::getInstance()->runDispatchLoopUntil(10);
        require(imported==8&&queued,"all eight takes import automatically in sequence");
        routes.push_back({8,0,1,folder.getChildFile("Ninth.wav")});require(engine.recorder.startGroup(routes,48000,256).failed(),"ninth armed track rejects before recording");
        require(engine.recorder.startGroup({{0,0,1,folder.getChildFile("Missing-A-"+juce::Uuid().toString()+".wav")},{1,1,1,folder.getChildFile("Missing-B-"+juce::Uuid().toString()+".wav")}},48000,10000).wasOk(),"missing-input capture prepares");
        engine.recorder.capture(in,1,128);require(!engine.recorder.isActive()&&engine.recorder.waitForFinish(10000),"missing input stops the entire recording group");takes=engine.recorder.takeResults();require(takes.size()==2&&takes[0].take.frames==128&&takes[1].take.error.isNotEmpty(),"valid partial take kept and missing channel reported");
    }
    {
        PluginRack busRack;juce::OwnedArray<juce::PluginDescription> found;busRack.formats.getFormat(0)->findAllTypesForFile(found,juce::String(argv[2]));
        require(found.size()==1,"scan aux latency VST3 fixture");auto core=std::make_unique<PlaybackCore>();core->deviceRate=48000;
        core->tracks[0].left.assign(4800,.2f);core->tracks[0].right=core->tracks[0].left;core->tracks[0].gain=1;
        MixerRoute send;send.sends[0]={2,.5f};core->setRouting(0,send);MixerRoute aux;aux.aux=true;core->setRouting(2,aux);core->tracks[2].gain=1;
        core->refreshDuration();core->process=PluginRack::process;core->processContext=&busRack;
        for(size_t channel:{size_t(2),PlaybackCore::maxTracks}){auto instance=busRack.formats.createPluginInstance(*found[0],48000,256,error);require(instance&&busRack.install(channel,0,*found[0],std::move(instance),{},false,48000).wasOk(),"install actual aux/master delay VST3s");}
        busRack.rebuildCompensation(*core);core->playbackLatencyFrames=busRack.totalLatency;busRack.resetGraph();
        require(busRack.totalLatency==1024&&busRack.directCompensation.samples()==512,"direct output aligned with bus latency plus master latency");
        const auto output=folder.getChildFile("Aux-VST3-mix.wav");const auto result=writeMixWav(*core,output,{0,.1,0,24},{},{});
        require(result.error.isEmpty()&&result.frames==4800,"aux routing exports exact duration");juce::WavAudioFormat wav;std::unique_ptr<juce::AudioFormatReader> reader(wav.createReaderFor(output.createInputStream().release(),true));juce::AudioBuffer<float> audio(2,4800);
        require(reader&&reader->read(&audio,0,4800,0,true,true)&&near(audio.getSample(0,0),.3f)&&near(audio.getSample(1,4799),.3f),"dry and aux paths align through actual VST3s including first and last exported samples");
    }
    {
        AudioEngine engine;engine.playback.deviceRate=48000;MixerRoute send;send.sends[0]={2,1};engine.playback.setRouting(0,send);MixerRoute aux;aux.aux=true;engine.playback.setRouting(2,aux);engine.playback.tracks[2].gain=1;
        engine.playback.tracks[0].gain=1;engine.playback.tracks[0].left.assign(48000,.2f);engine.playback.tracks[0].right=engine.playback.tracks[0].left;
        for(size_t channel:{size_t(2),PlaybackCore::maxTracks}){auto instance=engine.plugins.formats.createPluginInstance(*descriptions[0],48000,256,error);require(instance&&engine.plugins.install(channel,0,*descriptions[0],std::move(instance),retained,false,48000).wasOk(),"shared NAM aux and master install");}
        engine.playback.refreshDuration();engine.monitor.enabled=true;engine.monitor.gain=1;engine.monitor.track=0;engine.playback.playing=true;
        float input[512],l[512],r[512];std::fill_n(input,512,.2f);const float* in[]{input};float* out[]{l,r};bool ready=false;
        for(int n=0;n<100&&!ready;++n){juce::MessageManager::getInstance()->runDispatchLoopUntil(20);engine.renderAudio(in,1,out,2,512);ready=near(l[511],.3f);}
        require(ready&&near(r[511],.3f),"clips plus live input feed shared aux and master exactly once");
        engine.monitor.gain=0;for(int n=0;n<10;++n)engine.renderAudio(in,1,out,2,512);require(near(l[511],.15f),"zero monitor gain retains dry clip plus its aux effect");
        engine.playback.playing=false;engine.monitor.gain=1;for(int n=0;n<10;++n)engine.renderAudio(in,1,out,2,512);require(near(l[511],.15f),"stopped transport monitors live input through shared bus");
    }
    {
        AudioEngine engine;auto& track=engine.playback.tracks[0];track.left.assign(96000,.2f);track.right=track.left;track.sourceRate=48000;track.timelineEnabled=true;track.clips={{1,0,0,0,2}};
        auto before=track.clips;LoadedWav take;take.left.assign(4800,.8f);take.right=take.left;take.rate=48000;
        engine.install(0,take,true,.5,true,.6);
        require(track.clips.size()==3&&near(track.sample(.499,false),.2f)&&near(track.sample(.55,false),.8f)&&near(track.sample(.6,false),.2f),"actual recorded-take install replaces range and preserves audio around it");
        auto after=track.clips;track.clips=before;require(near(track.sample(.55,false),.2f)&&track.extra.size()==1,"undo retains original source and old arrangement");track.clips=after;
        track.gain=1;engine.playback.refreshDuration();const auto output=folder.getChildFile("Overwrite-mix.wav");auto result=writeMixWav(engine.playback,output,{0,2,0,24},{},{});require(result.error.isEmpty(),"replacement arrangement exports");juce::WavAudioFormat format;std::unique_ptr<juce::AudioFormatReader> reader(format.createReaderFor(output.createInputStream().release(),true));juce::AudioBuffer<float> samples(2,96000);require(reader&&reader->read(&samples,0,96000,0,true,true)&&near(samples.getSample(0,24000),.8f)&&near(samples.getSample(0,28800),.2f),"export plays new take only inside recorded interval");
        track.clips={{1,0,0,0,1}};require(ClipLayout::edit(track.clips,1,"fadeIn",.1,2),"integration fade applies");engine.playback.refreshDuration();reader.reset();result=writeMixWav(engine.playback,output,{0,1,0,24},{},{});reader.reset(format.createReaderFor(output.createInputStream().release(),true));samples.setSize(2,48000);require(reader&&reader->read(&samples,0,48000,0,true,true)&&near(samples.getSample(0,0),0)&&near(samples.getSample(0,2400),.1f),"WAV export applies fade envelope to real source samples");
    }
    {
        PluginRack delayedRack;juce::OwnedArray<juce::PluginDescription> found;delayedRack.formats.getFormat(0)->findAllTypesForFile(found,juce::String(argv[2]));require(found.size()==1,"automation latency fixture found");
        auto plain=std::make_unique<PlaybackCore>(),delayed=std::make_unique<PlaybackCore>();
        for(auto* core:{plain.get(),delayed.get()}){core->deviceRate=48000;auto& t=core->tracks[0];t.sourceRate=48000;t.left.assign(4800,.5f);t.right=t.left;t.gain=1;t.automationMode=1;t.volumeAutomation={{0,.2f},{.01,.2f},{.02,.8f},{.1,.8f}};t.panAutomation={{0,-.5f},{.04,-.5f},{.05,.5f},{.1,.5f}};MixerRoute source;source.output=2;core->setRouting(0,source);MixerRoute aux;aux.aux=true;core->setRouting(2,aux);auto& bus=core->tracks[2];bus.gain=1;bus.automationMode=1;bus.volumeAutomation={{0,.5f},{.03,.5f},{.04,1},{.1,1}};core->refreshDuration();}
        for(size_t id:{size_t(0),size_t(2),size_t(128)}){auto plugin=delayedRack.formats.createPluginInstance(*found[0],48000,256,error);require(plugin&&delayedRack.install(id,0,*found[0],std::move(plugin),{},false,48000).wasOk(),"install automated source/aux/master latency plugins");}
        delayed->process=PluginRack::process;delayed->processContext=&delayedRack;delayedRack.rebuildCompensation(*delayed);delayed->playbackLatencyFrames=delayedRack.totalLatency;delayedRack.resetGraph();
        const auto baseline=folder.getChildFile("Automation-no-latency.wav"),withLatency=folder.getChildFile("Automation-latency.wav");auto a=writeMixWav(*plain,baseline,{0,.1,0,24},{},{}),b=writeMixWav(*delayed,withLatency,{0,.1,0,24},{},{});require(a.error.isEmpty()&&b.error.isEmpty(),"automation latency comparisons export");juce::WavAudioFormat format;std::unique_ptr<juce::AudioFormatReader> ra(format.createReaderFor(baseline.createInputStream().release(),true)),rb(format.createReaderFor(withLatency.createInputStream().release(),true));juce::AudioBuffer<float> sa(2,4800),sb(2,4800);require(ra&&rb&&ra->read(&sa,0,4800,0,true,true)&&rb->read(&sb,0,4800,0,true,true),"read automated reference WAVs");
        float difference=0;for(int ch=0;ch<2;++ch)for(int n=0;n<4800;++n)difference=std::max(difference,std::abs(sa.getSample(ch,n)-sb.getSample(ch,n)));require(difference<.00001f,"source and aux automation align sample-for-sample through real VST3 source/aux/master latency");
    }
    std::cout << "All VST3 hosting, wet input monitoring, delay compensation, NAM, session and MIDI and WAV export tests passed.\n";
}
