#pragma once
#include <JuceHeader.h>
#include "PlaybackCore.h"
#include "SessionFile.h"
#include "RecordGroup.h"
#include "PluginRack.h"
#include "InputMonitor.h"
#include "CountIn.h"

struct LoadedWav
{
    juce::File file;
    juce::String name, error;
    double rate = 48000.0;
    std::vector<float> left, right;
    juce::Array<juce::var> waveform;
};

inline LoadedWav decodeWav(const juce::File& file, int64_t maximumFrames, const std::function<bool()>& cancelled)
{
        auto result = std::make_unique<LoadedWav>();
        result->file = file;
        result->name = file.getFileName();
        juce::AudioFormatManager formats; formats.registerFormat(new juce::WavAudioFormat(), true);
        std::unique_ptr<juce::AudioFormatReader> reader(formats.createReaderFor(file));
        if (! reader) result->error = "Could not read this WAV file.";
        else if (reader->numChannels < 1 || reader->numChannels > 2 || !std::isfinite(reader->sampleRate) || reader->sampleRate < 8000.0 || reader->sampleRate > 192000.0 || reader->lengthInSamples <= 0)
            result->error = "Use a mono or stereo WAV between 8 and 192 kHz.";
        else if (reader->lengthInSamples > maximumFrames)
            result->error = "Import exceeds the 128 MiB per-file or 512 MiB session limit. Use a shorter WAV or clear another track.";
        else
        {
            result->rate = reader->sampleRate;
            const int length = static_cast<int>(reader->lengthInSamples);
            result->left.resize(static_cast<size_t>(length)); result->right.resize(static_cast<size_t>(length));
            for (int offset = 0; offset < length && ! cancelled(); offset += 65536)
            {
                const int count = std::min(65536, length - offset);
                float* destinations[] = { result->left.data() + offset, result->right.data() + offset };
                if (! reader->read(destinations, 2, offset, count)) { result->error = "WAV decoding failed."; break; }
                if (reader->numChannels == 1) std::copy_n(destinations[0], count, destinations[1]);
                for (int ch = 0; ch < 2; ++ch)
                    for (int i = 0; i < count; ++i)
                        destinations[ch][i] = std::isfinite(destinations[ch][i]) ? juce::jlimit(-1.0f, 1.0f, destinations[ch][i]) : 0.0f;
            }
            for (int bin = 0; bin < 256 && ! cancelled(); ++bin)
            {
                float peak = 0.0f;
                const int start = static_cast<int>(static_cast<int64_t>(length) * bin / 256);
                const int end = static_cast<int>(static_cast<int64_t>(length) * (bin + 1) / 256);
                for (int i = start; i < end; ++i) peak = std::max(peak, std::max(std::abs(result->left[static_cast<size_t>(i)]), std::abs(result->right[static_cast<size_t>(i)])));
                result->waveform.add(juce::jlimit(0.0f, 1.0f, peak));
            }
        }
        return std::move(*result);
}

// File decoding, validation and waveform extraction happen on a worker thread.
class WavLoader final : private juce::Thread, private juce::AsyncUpdater
{
public:
    std::function<void(LoadedWav)> onLoaded;
    WavLoader() : Thread("WAV import") {}
    ~WavLoader() override { signalThreadShouldExit(); stopThread(-1); cancelPendingUpdate(); }
    bool load(const juce::File& file, int64_t frameBudget)
    {
        if (isThreadRunning()) return false;
        cancelPendingUpdate(); pending.reset(); requestedFile = file; maximumFrames = std::min<int64_t>(16 * 1024 * 1024, frameBudget);
        return startThread();
    }
private:
    void run() override
    {
        auto result = std::make_unique<LoadedWav>();
        try { *result = decodeWav(requestedFile, maximumFrames, [this] { return threadShouldExit(); }); }
        catch (const std::exception&) { result->error = "Not enough memory to import this WAV."; }
        if (threadShouldExit()) return;
        { const juce::ScopedLock lock(resultLock); pending = std::move(result); }
        triggerAsyncUpdate();
    }
    void handleAsyncUpdate() override
    {
        std::unique_ptr<LoadedWav> result;
        { const juce::ScopedLock lock(resultLock); result = std::move(pending); }
        // Completion may be dispatched just before run() returns; join before a queued next import.
        waitForThreadToExit(1000);
        if (result && onLoaded) onLoaded(std::move(*result));
    }
    juce::File requestedFile;
    int64_t maximumFrames = 16 * 1024 * 1024;
    juce::CriticalSection resultLock; // Worker/message thread only; never audio.
    std::unique_ptr<LoadedWav> pending;
};

struct SessionJobResult
{
    juce::File file;
    SavedSession session;
    std::array<std::unique_ptr<LoadedWav>, 128> audio;
    std::array<std::vector<std::unique_ptr<LoadedWav>>, 128> extraAudio;
    juce::String error;
    juce::StringArray missing;
    bool saving = false;
};
class SessionWorker final : private juce::Thread, private juce::AsyncUpdater
{
public:
    std::function<void(SessionJobResult)> onFinished;
    SessionWorker() : Thread("Session files") {}
    ~SessionWorker() override { signalThreadShouldExit(); stopThread(-1); cancelPendingUpdate(); }
    bool open(const juce::File& file) { return begin(file, false, {}); }
    bool save(const juce::File& file, juce::var document) { return begin(file, true, std::move(document)); }
private:
    bool begin(const juce::File& file, bool write, juce::var document)
    {
        if (isThreadRunning()) return false;
        cancelPendingUpdate(); pending.reset(); requested = file; saving = write; json = std::move(document);
        return startThread();
    }
    void run() override
    {
        auto result = std::make_unique<SessionJobResult>(); result->file = requested; result->saving = saving;
        try
        {
            if (saving)
            {
                const auto written = SessionFile::write(requested, json);
                if (written.failed()) result->error = written.getErrorMessage();
            }
            else
            {
                const auto read = SessionFile::read(requested, result->session);
                if (read.failed()) result->error = read.getErrorMessage();
                int64_t frames = 0;
                for (size_t id = 0; id < result->session.tracks.size() && result->error.isEmpty() && !threadShouldExit(); ++id)
                {
                    const auto& track=result->session.tracks[id];
                    const auto files=track.sources.empty()?std::vector<juce::File>{track.audioFile}:track.sources;
                    result->extraAudio[id].resize(files.size()-1);
                    for(size_t source=0;source<files.size() && result->error.isEmpty();++source)
                    {
                        const auto& file=files[source];if(file==juce::File())continue;
                        if(!file.existsAsFile()){result->missing.add(track.name+": "+file.getFileName());continue;}
                        auto wav=std::make_unique<LoadedWav>(decodeWav(file,std::min<int64_t>(16*1024*1024,64*1024*1024-frames),[this]{return threadShouldExit();}));
                        if(wav->error.isNotEmpty()){result->error=file.getFileName()+": "+wav->error;break;}
                        frames+=static_cast<int64_t>(wav->left.size());
                        for(const auto& clip:track.clips)if(clip.source==static_cast<int>(source) && clip.offset+clip.length>static_cast<double>(wav->left.size())/wav->rate+1.e-6){result->error="Clip exceeds source WAV: "+file.getFileName();break;}
                        for(const auto& playlist:track.playlists)for(const auto& clip:playlist.clips)if(clip.source==static_cast<int>(source)&&clip.offset+clip.length>static_cast<double>(wav->left.size())/wav->rate+1.e-6)result->error="Playlist clip exceeds source WAV: "+file.getFileName();
                        if(source==0)result->audio[id]=std::move(wav);else result->extraAudio[id][source-1]=std::move(wav);
                    }
                }
            }
        }
        catch (const std::exception&) { result->error = "Session operation failed: not enough memory or an unreadable file."; }
        if (threadShouldExit()) return;
        { const juce::ScopedLock lock(resultLock); pending = std::move(result); }
        triggerAsyncUpdate();
    }
    void handleAsyncUpdate() override
    {
        std::unique_ptr<SessionJobResult> result;
        { const juce::ScopedLock lock(resultLock); result = std::move(pending); }
        if (result && onFinished) onFinished(std::move(*result));
    }
    juce::File requested;
    juce::var json;
    bool saving = false;
    juce::CriticalSection resultLock;
    std::unique_ptr<SessionJobResult> pending;
};

class AudioEngine final : private juce::AudioIODeviceCallback
{
public:
    PlaybackCore playback;
    CountIn countIn;
    std::atomic<bool> dynamicTransport {false}, punchEnabled {false};
    std::atomic<double> playStart {0}, selectionStart {0}, selectionEnd {0};
    double takeStart=0; bool recordPlanActive=false; int planTrack=-1;
    int64_t planPosition=0, punchBegin=0, punchEnd=0;
    bool takeWasPunch=false; double takeEnd=0; bool continueAfterPunch=false;
    std::atomic<int> preRollBars { 0 }, countInBeats { 0 };
    bool countInCancelled = false;
    RecordGroup recorder;
    std::vector<RecordRoute> recordingRoutes;
    std::array<int,128> trackInputs {};
    std::array<int,128> trackInputChannels = [] { std::array<int,128> a; a.fill(1); return a; }();
    float monitorInputSmooth=0;
    std::array<const float*,2> liveSources {};int liveChannels=1;
    std::atomic<float> inputPeak { 0.0f };
    std::atomic<int> inputMeterChannels { 1 };
    std::atomic<int> inputSource { 0 };
    std::array<std::atomic<float>, 4> inputChannelPeaks {};
    InputMonitor monitor;
    std::atomic<float> monitorPeak { 0.0f };
    std::atomic<bool> monitorActive { false };
    juce::AudioDeviceManager devices;
    juce::AudioDeviceManager::LevelMeter::Ptr deviceOutputMeter = devices.getOutputLevelGetter();
    std::atomic<uint64_t> callbackCount { 0 };
    std::atomic<int> callbackOutputs { 0 }, writableOutputs { 0 };
    juce::String deviceError() const { const juce::ScopedLock lock(deviceErrorLock); return lastDeviceError; }
    PluginRack plugins;
    void detach() { devices.removeAudioCallback(this); }
    void attach()
    {
        plugins.rebuildCompensation(playback); playback.playbackLatencyFrames = plugins.totalLatency;
        devices.addAudioCallback(this);
    }
    void resetPluginGraph() { detach(); plugins.resetGraph(); attach(); }
    void refreshPluginLatency()
    {
        if (!plugins.latencyChanged()) return;
        const auto position = playback.seconds.load();
        detach(); plugins.rebuildCompensation(playback); plugins.resetGraph(); playback.seekSeconds = position; attach();
    }
    juce::String initialise()
    {
        playback.process = PluginRack::process; playback.processContext = &plugins;
        const auto settings = deviceSettingsFile();
        auto state = settings.existsAsFile() && settings.getSize() < 65536 ? juce::parseXML(settings) : nullptr;
        auto error = devices.initialise(0, 2, state.get(), true);
        attach(); return error;
    }
    static juce::File deviceSettingsFile()
    { return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory).getChildFile("Tracksmith/audio-device.xml"); }
    juce::Result saveDeviceSettings()
    {
        auto state = devices.createStateXml(); if (!state) return juce::Result::fail("Audio settings could not be saved.");
        const auto file = deviceSettingsFile(); const auto made = file.getParentDirectory().createDirectory(); if (made.failed()) return made;
        juce::TemporaryFile temporary(file);
        return temporary.getFile().replaceWithText(state->toString()) && temporary.overwriteTargetFileWithTemporary()
            ? juce::Result::ok() : juce::Result::fail("Audio settings could not be saved. Check the Tracksmith application-data folder.");
    }
    AudioEngine(){playback.process=PluginRack::process;playback.processContext=&plugins;}
    ~AudioEngine() override { devices.removeAudioCallback(this); devices.closeAudioDevice(); }
    juce::Result startRecording(size_t id, const juce::File& file, int channels)
    {
        auto* device = devices.getCurrentAudioDevice();
        if (device == nullptr || !device->isPlaying()) return juce::Result::fail("Choose an active input/output device in Audio settings.");
        if (recordingRoutes.empty() && device->getActiveInputChannels().countNumberOfSetBits() < inputSource.load() + channels) return juce::Result::fail("The selected recording input is unavailable. Choose an enabled input in the inspector or enable it in Audio settings.");
        for(const auto& route:recordingRoutes)
            if(device->getActiveInputChannels().countNumberOfSetBits()<route.input+route.channels)return juce::Result::fail("An armed track has an unavailable input or stereo pair.");
        const auto rate = device->getCurrentSampleRate();
        const auto selectedStart=selectionStart.load(),selectedEnd=selectionEnd.load();
        const bool punching=punchEnabled.load();
        if(punching && (selectedEnd<=selectedStart || selectedEnd-selectedStart<1/rate))return juce::Result::fail("Highlight a non-empty range before punch recording.");
        const auto transportStart=dynamicTransport.load()?playStart.load():selectedStart;
        if(punching && transportStart>selectedStart)return juce::Result::fail("Move the playback start marker before the punch selection.");
        if(!monitor.enabled.load())inputMeterChannels = channels;
        const auto limit = static_cast<uint64_t>(std::max<int64_t>(0,std::min<int64_t>(16 * 1024 * 1024, importBudget(id,true)/static_cast<int64_t>(std::max<size_t>(1,recordingRoutes.size())))));
        const auto pendingSeek=playback.seekSeconds.load();const auto insertion=pendingSeek>=0?pendingSeek:playback.seconds.load();
        devices.removeAudioCallback(this);
        const auto started = recordingRoutes.empty()?recorder.start(file, rate, channels, limit):recorder.startGroup(recordingRoutes,rate,limit);
        playback.recordTracks.fill(false);for(const auto& route:recordingRoutes)playback.recordTracks[route.track]=true;
        if (started.wasOk()) { playback.reset(); plugins.resetGraph(); playback.recordTrack = static_cast<int>(id); playback.recording = true; countInCancelled = false;
            playback.suppressRecordedPlayback=punching;continueAfterPunch=false;takeWasPunch=punching;takeStart=punching?selectedStart:dynamicTransport.load()?playStart.load():insertion;takeEnd=selectedEnd;
            planTrack=static_cast<int>(id);planPosition=0;recordPlanActive=true;
            const auto origin=punching?transportStart:takeStart;
            punchBegin=punching?static_cast<int64_t>(std::llround((selectedStart-origin)*rate)):0;
            punchEnd=punching?static_cast<int64_t>(std::llround((selectedEnd-origin)*rate)):std::numeric_limits<int64_t>::max();
            playback.seekSeconds=origin;
            countIn.start(preRollBars.load(), rate, playback.bpm.load()); countInBeats = countIn.beatsLeft(); playback.playing = countIn.total == 0; }
        attach(); return started;
    }
    void stopRecording(bool cancelled = false, bool keepPlaying = false)
    {
        const bool wasPlaying=playback.playing.load();
        recorder.requestStop(); // An intentional stop must not be reported as an input-device failure.
        devices.removeAudioCallback(this);
        if(keepPlaying)playback.playing=wasPlaying;
        if (cancelled && (countIn.remaining(1) > 0 || (recordPlanActive && planPosition<=punchBegin))) countInCancelled = true;
        continueAfterPunch=keepPlaying && playback.playing.load();
        countIn.total = countIn.position = 0; countInBeats = 0; recordPlanActive=false; recorder.requestStop();
        playback.recording = false; playback.recordTrack = -1;
        if(!keepPlaying){playback.playing=false;playback.seekSeconds=dynamicTransport.load()?playStart.load():0.0;}
        if(!keepPlaying)plugins.resetGraph(); attach();
    }
    int64_t importBudget(size_t replacingTrack, bool append = false) const
    {
        int64_t frames = 0;
        for (size_t id = 0; id < playback.tracks.size(); ++id)
            if (append || id != replacingTrack) frames += playback.tracks[id].residentFrames();
        return std::max<int64_t>(0, 64 * 1024 * 1024 - frames);
    }
    void install(size_t id, LoadedWav& wav, bool append = false, double insertion = -1, bool punch = false, double end = 0, bool keepPlaying = false)
    {
        devices.removeAudioCallback(this); // Waits for in-flight callback to finish.
        const auto playing=keepPlaying && playback.playing.load();const auto position=playback.seconds.load();
        auto& track = playback.tracks[id];
        const double start=insertion>=0?insertion:append?track.duration():0;
        const double length=static_cast<double>(wav.left.size())/wav.rate;
        int source=0;
        if(append) {track.extra.push_back({std::move(wav.left),std::move(wav.right),wav.rate});source=static_cast<int>(track.extra.size());}
        else {track.left=std::move(wav.left);track.right=std::move(wav.right);track.sourceRate=wav.rate;track.extra.clear();track.clips.clear();}
        track.timelineEnabled=true;int next=1;for(const auto& c:track.clips)next=std::max(next,c.id+1);
        if(punch)
        {
            const double stop=std::min(start+length,end>start?end:start+length);
            ClipLayout::replaceRange(track.clips,start,stop,{});
        }
        next=1;for(const auto& c:track.clips)next=std::max(next,c.id+1);
        track.clips.push_back({next,source,start,0,length}); playback.refreshDuration(); playback.reset(); plugins.resetGraph();
        if(keepPlaying){playback.seekSeconds=position;playback.playing=playing;}
        attach();
    }
    void clear(size_t id)
    {
        devices.removeAudioCallback(this);
        playback.tracks[id].extra.clear();playback.tracks[id].clips.clear();playback.tracks[id].timelineEnabled=true;
        std::vector<float>().swap(playback.tracks[id].left);
        std::vector<float>().swap(playback.tracks[id].right);
        playback.refreshDuration(); playback.reset(); plugins.resetGraph();
        attach();
    }
    void installSession(SessionJobResult& session)
    {
        devices.removeAudioCallback(this);
        monitor.enabled = false; monitor.track = 0; monitorPeak = 0.0f;
        for (size_t id = 0; id < playback.tracks.size(); ++id)
        {
            auto& track = playback.tracks[id];
            if (session.audio[id])
            {
                track.left = std::move(session.audio[id]->left); track.right = std::move(session.audio[id]->right);
                track.sourceRate = session.audio[id]->rate;
            }
            else { std::vector<float>().swap(track.left); std::vector<float>().swap(track.right); }
            track.volumeAutomation.clear();track.panAutomation.clear();track.automationMode=0;
            track.routing={};for(auto& level:track.sendLevels)level=0;track.extra.clear();track.clips.clear();track.timelineEnabled=true;track.midiTrack=false;track.midiSeconds=0;plugins.midiLanes[id].enabled=false;plugins.midiLanes[id].notes.clear();plugins.midiLanes[id].reset();
            for(auto& audio:session.extraAudio[id])
            { PlaybackCore::Track::Source source;if(audio){source.left=std::move(audio->left);source.right=std::move(audio->right);source.rate=audio->rate;}track.extra.push_back(std::move(source)); }
            if (id < session.session.tracks.size())
            {
                const auto& saved = session.session.tracks[id];
                playback.setRouting(id,saved.routing);track.midiTrack=saved.midiTrack;plugins.midiLanes[id].enabled=saved.midiTrack;plugins.midiLanes[id].notes=saved.notes;if(saved.midiTrack)track.midiSeconds=plugins.midiLanes[id].endBeat()*60/session.session.bpm+1;
                track.clips=saved.clips;if(!saved.timelineEnabled && !track.left.empty())track.clips.push_back({1,0,0,0,track.sourceDuration(0)});
                track.volumeAutomation=saved.volumeAutomation;track.panAutomation=saved.panAutomation;track.automationMode=saved.automationMode;
                track.gain = saved.gain; track.pan = saved.pan; track.muted = saved.muted; track.solo = saved.solo;
            }
            else { track.gain = 0.75f; track.pan = 0.0f; track.muted = false; track.solo = false; }
        }
        playback.bpm = session.session.bpm; playback.loop = session.session.loop;
        playback.masterGain = session.session.master; playback.metronome = session.session.metronome;
        playback.metronomeGain = session.session.metronomeGain; preRollBars = session.session.preRollBars;
        playback.refreshDuration(); playback.reset(); plugins.resetGraph(); attach();
    }
    // Also used by offline integration tests; caller owns the audio thread.
    void renderAudio(const float* const* inputs, int inputChannels, float* const* outputs, int channels, int count)
    {
        const int prefix = countIn.remaining(count);
        if (prefix > 0)
        {
            renderNormal(inputs, inputChannels, outputs, channels, prefix, false, true);
            countInBeats = countIn.beatsLeft();
            if (countIn.remaining(1) == 0) playback.playing = true;
            if (prefix == count) return;
            // JUCE selector permits four input and two output channels. Fixed stack views.
            std::array<const float*, 4> tailInput {}; std::array<float*, 2> tailOutput {};
            for (int ch = 0; ch < std::min(inputChannels, 4); ++ch) tailInput[ch] = inputs[ch] ? inputs[ch]+prefix : nullptr;
            for (int ch = 0; ch < std::min(channels, 2); ++ch) tailOutput[ch] = outputs[ch] ? outputs[ch]+prefix : nullptr;
            renderTimeline(tailInput.data(), std::min(inputChannels,4), tailOutput.data(), std::min(channels,2), count-prefix);
            return;
        }
        renderTimeline(inputs, inputChannels, outputs, channels, count);
    }
    void renderTimeline(const float* const* inputs,int inputChannels,float* const* outputs,int channels,int count)
    {
        if(!recordPlanActive){renderNormal(inputs,inputChannels,outputs,channels,count,true);return;}
        int offset=0;
        while(offset<count)
        {
            const bool capture=planPosition>=punchBegin && planPosition<punchEnd;
            const auto boundary=planPosition<punchBegin?punchBegin:punchEnd;
            const int frames=static_cast<int>(std::min<int64_t>(count-offset,boundary-planPosition));
            if(frames<=0)break;
            std::array<const float*,4> in {};std::array<float*,2> out {};
            for(int ch=0;ch<std::min(inputChannels,4);++ch)in[ch]=inputs[ch]?inputs[ch]+offset:nullptr;
            for(int ch=0;ch<std::min(channels,2);++ch)out[ch]=outputs[ch]?outputs[ch]+offset:nullptr;
            playback.recordTrack=capture?planTrack:-1;
            renderNormal(in.data(),std::min(inputChannels,4),out.data(),std::min(channels,2),frames,capture);
            offset+=frames;planPosition+=frames;
            if(planPosition>=punchEnd)
            {
                recorder.requestStop();recordPlanActive=false;playback.recording=false;playback.recordTrack=-1;
                // Keep playback running after punch-out; the finalized clip installs once stopped by the take loader.
                break;
            }
        }
        if(offset<count)
        {
            std::array<const float*,4> in {};std::array<float*,2> out {};
            for(int ch=0;ch<std::min(inputChannels,4);++ch)in[ch]=inputs[ch]?inputs[ch]+offset:nullptr;
            for(int ch=0;ch<std::min(channels,2);++ch)out[ch]=outputs[ch]?outputs[ch]+offset:nullptr;
            renderNormal(in.data(),std::min(inputChannels,4),out.data(),std::min(channels,2),count-offset,false);
        }
    }
    void renderNormal(const float* const* inputs, int inputChannels, float* const* outputs, int channels, int count, bool capture, bool countClick = false)
    {
        callbackCount.fetch_add(1, std::memory_order_relaxed); callbackOutputs = channels;
        int writable = 0; for (int channel = 0; channel < channels; ++channel) if (outputs[channel]) ++writable;
        writableOutputs = writable;
        const int captureChannels = inputMeterChannels.load(std::memory_order_relaxed);
        const int first = inputSource.load(std::memory_order_relaxed);
        const auto selected = InputRouting::select(inputs, inputChannels, first, captureChannels);
        float peak = 0.0f;
        for (int channel = 0; channel < 4; ++channel)
        {
            const auto source = InputRouting::select(inputs, inputChannels, channel, 1);
            float channelPeak = 0;
            for (int frame = 0; frame < count; ++frame) channelPeak = std::max(channelPeak, std::abs(InputRouting::sample(source[0], frame)));
            inputChannelPeaks[static_cast<size_t>(channel)].store(channelPeak, std::memory_order_relaxed);
        }
        for (int channel = 0; channel < captureChannels; ++channel)
            for (int frame = 0; frame < count; ++frame) peak = std::max(peak, std::abs(InputRouting::sample(selected[static_cast<size_t>(channel)], frame)));
        inputPeak.store(peak, std::memory_order_relaxed);
        if (capture) recorder.capture(inputs, inputChannels, count, first);
        const int liveTrack = monitor.track.load(std::memory_order_relaxed);
        const bool live = monitor.enabled.load(std::memory_order_relaxed)
            && (!punchEnabled.load() || !playback.playing.load() || (capture && recorder.isActive())) && liveTrack >= 0 && liveTrack < static_cast<int>(PlaybackCore::maxTracks)
            && selected[0] && (captureChannels == 1 || selected[1]);
        monitorActive=live;liveSources=selected;liveChannels=captureChannels;
        playback.inputMonitorTrack=live?liveTrack:-1;playback.deferMasterProcessing=false;plugins.monitorChannel=live?liveTrack:-1;
        playback.liveContext=this;playback.liveInput=[](void* context,float* left,float* right,int frames,int offset)
        {
            auto& e=*static_cast<AudioEngine*>(context);const float smooth=static_cast<float>(1-std::exp(-1.0/(e.playback.deviceRate*.005)));
            for(int n=0;n<frames;++n){e.monitorInputSmooth+=smooth*(e.monitor.gain.load()-e.monitorInputSmooth);left[n]+=InputRouting::sample(e.liveSources[0],offset+n)*e.monitorInputSmooth;right[n]+=InputRouting::sample(e.liveSources[e.liveChannels==2?1:0],offset+n)*e.monitorInputSmooth;}
        };
        playback.clickContext=this;playback.extraClick=countClick?+[](void* context)->float{auto& e=*static_cast<AudioEngine*>(context);return e.countIn.next()*e.playback.metronomeGain.load();}:nullptr;
        if(!live)monitorInputSmooth=0;
        playback.render(outputs,channels,count);
        monitorPeak=live?playback.tracks[static_cast<size_t>(liveTrack)].peak.load():0;
    }

private:
    void audioDeviceIOCallbackWithContext(const float* const* inputs, int inputChannels, float* const* outputs, int channels, int count, const juce::AudioIODeviceCallbackContext&) override
    { renderAudio(inputs, inputChannels, outputs, channels, count); }
    void audioDeviceAboutToStart(juce::AudioIODevice* device) override
    {
        { const juce::ScopedLock lock(deviceErrorLock); lastDeviceError.clear(); }
        playback.deviceRate = device->getCurrentSampleRate();
        if (inputSource.load() >= device->getActiveInputChannels().countNumberOfSetBits()) inputSource = 0;
        monitor.reset();
        if (plugins.clock.rate.load() != playback.deviceRate) plugins.prepare(playback.deviceRate);
        plugins.rebuildCompensation(playback); playback.playbackLatencyFrames = plugins.totalLatency;
    }
    void audioDeviceStopped() override { playback.playing.store(false, std::memory_order_relaxed); recorder.inputStopped(); inputPeak = 0.0f; for (auto& peak : inputChannelPeaks) peak = 0.0f; }
    void audioDeviceError(const juce::String& message) override
    {
        { const juce::ScopedLock lock(deviceErrorLock); lastDeviceError = message; }
        playback.playing = false; recorder.inputStopped(); inputPeak = 0.0f; for (auto& peak : inputChannelPeaks) peak = 0.0f;
    }
    mutable juce::CriticalSection deviceErrorLock;
    juce::String lastDeviceError;
};
