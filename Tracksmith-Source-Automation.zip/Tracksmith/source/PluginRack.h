#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PlaybackCore.h"
#include "CompensationDelay.h"
#include "MidiLane.h"

// Ownership and editor operations run on the message thread with audio detached.
// Only process() runs in the device callback. Instances are never replaced there.
class PluginRack
{
public:
    static constexpr int slotsPerChannel = 5;
    static constexpr int maximumPathLatency = 65536;
    static constexpr size_t clickChannel = PlaybackCore::maxTracks + 1;
    std::array<CompensationDelay, PlaybackCore::maxTracks + 2> compensation;
    std::array<int, PlaybackCore::maxTracks + 1> pathLatencies {};
    int mixLatency = 0, auxLatency = 0, totalLatency = 0;
    CompensationDelay directCompensation;
    std::array<MidiLane,PlaybackCore::maxTracks> midiLanes;
    int monitorChannel = -1; // Callback-owned; live input skips added playback delay.
    struct Clock final : juce::AudioPlayHead
    {
        std::atomic<double> seconds { 0.0 }, bpm { 120.0 }, rate { 48000.0 };
        std::atomic<bool> playing { false };
        juce::Optional<PositionInfo> getPosition() const override
        {
            const double time = seconds.load(std::memory_order_relaxed), tempo = bpm.load(std::memory_order_relaxed), sampleRate = rate.load(std::memory_order_relaxed);
            PositionInfo p; p.setTimeInSeconds(time); p.setTimeInSamples(static_cast<int64_t>(time * sampleRate));
            p.setBpm(tempo); p.setTimeSignature(TimeSignature { 4, 4 }); p.setPpqPosition(time * tempo / 60.0);
            p.setPpqPositionOfLastBarStart(std::floor(time * tempo / 240.0) * 4.0); p.setIsPlaying(playing.load(std::memory_order_relaxed));
            return p;
        }
    };
    class EditorWindow final : public juce::DocumentWindow
    {
    public:
        EditorWindow(juce::AudioPluginInstance& instance)
            : DocumentWindow(instance.getName(), juce::Colour(0xff191c24), closeButton)
        {
            setUsingNativeTitleBar(true);
            auto* editor = instance.createEditorIfNeeded();
            if (!editor) editor = new juce::GenericAudioProcessorEditor(instance);
            setContentOwned(editor, true); setResizable(editor->isResizable(), false);
            centreWithSize(editor->getWidth(), editor->getHeight()); setVisible(true);
        }
        void closeButtonPressed() override { setVisible(false); }
    };
    struct Slot : juce::AudioProcessorListener
    {
        juce::PluginDescription description;
        juce::MemoryBlock retainedState;
        std::unique_ptr<juce::AudioPluginInstance> instance;
        std::unique_ptr<EditorWindow> window;
        juce::AudioBuffer<float> buffer { 2, PlaybackCore::processBlockSize };
        juce::MidiBuffer midi;
        Slot(){midi.ensureSize(65536);}
        std::atomic<bool> bypass { false };
        int channels = 2;
        bool occupied = false;
        std::atomic<bool> changed { false };
        void audioProcessorParameterChanged(juce::AudioProcessor*, int, float) override { changed = true; }
        void audioProcessorChanged(juce::AudioProcessor*, const ChangeDetails&) override { changed = true; }
        ~Slot() { window.reset(); if (instance) { instance->removeListener(this); instance->releaseResources(); } }
    };
    std::array<std::array<std::unique_ptr<Slot>, slotsPerChannel>, PlaybackCore::maxTracks + 1> channels;
    juce::AudioPluginFormatManager formats;
    Clock clock;
    PluginRack() { formats.addFormat(new juce::VST3PluginFormat()); }
    ~PluginRack() { clear(); }
    void clear() { for (auto& channel : channels) for (auto& slot : channel) slot.reset(); }
    std::array<int, PlaybackCore::maxTracks + 1> reportedLatencies() const
    {
        std::array<int, PlaybackCore::maxTracks + 1> result {};
        for (size_t channel = 0; channel < channels.size(); ++channel) for (const auto& slot : channels[channel])
            if (slot && slot->instance && !slot->bypass.load())
                result[channel] = static_cast<int>(std::min<int64_t>(static_cast<int64_t>(result[channel]) + std::max(0, slot->instance->getLatencySamples()), INT_MAX));
        return result;
    }
    bool latencyChanged() const { return pathLatencies != reportedLatencies(); }
    void rebuildCompensation(PlaybackCore& playback)
    {
        for (auto& channel : channels)
        {
            int64_t sum = 0;
            for (auto& slot : channel)
                if (slot && slot->instance && !slot->bypass.load())
                {
                    const auto latency = std::max(0, slot->instance->getLatencySamples());
                    if (sum + latency > maximumPathLatency) { slot->bypass = true; slot->changed = true; }
                    else sum += latency;
                }
        }
        pathLatencies=reportedLatencies();mixLatency=auxLatency=0;
        const auto excluded=[&](size_t id){return playback.recording.load()&&playback.suppressRecordedPlayback&&playback.recordingTrack(id);};
        for(size_t id=0;id<PlaybackCore::maxTracks;++id)
        {
            if(playback.tracks[id].routing.aux)auxLatency=std::max(auxLatency,pathLatencies[id]);
            else if(playback.tracks[id].loaded()&&!excluded(id))mixLatency=std::max(mixLatency,pathLatencies[id]);
        }
        for(size_t id=0;id<PlaybackCore::maxTracks;++id)
            compensation[id].configure(playback.tracks[id].routing.aux?auxLatency-pathLatencies[id]:playback.tracks[id].loaded()&&!excluded(id)?mixLatency-pathLatencies[id]:0);
        compensation[clickChannel].configure(mixLatency);directCompensation.configure(auxLatency);
        totalLatency=mixLatency+auxLatency+pathLatencies[PlaybackCore::maxTracks];
        playback.automationSourceLatencyFrames=mixLatency;playback.automationAuxLatencyFrames=mixLatency+auxLatency;
    }
    void resetGraph()
    {
        for (auto& delay : compensation) delay.reset();directCompensation.reset();
        for(auto& lane:midiLanes)lane.reset();
        for (auto& channel : channels) for (auto& slot : channel) if (slot && slot->instance)
        {
            if(slot->description.isInstrument){slot->buffer.clear();slot->midi.clear();for(int ch=1;ch<=16;++ch)slot->midi.addEvent(juce::MidiMessage::allSoundOff(ch),0);float* data[]{slot->buffer.getWritePointer(0),slot->buffer.getWritePointer(1)};juce::AudioBuffer<float> view(data,slot->channels,PlaybackCore::processBlockSize);slot->instance->processBlock(view,slot->midi);}
            slot->instance->reset();
        }
    }
    static bool configure(juce::AudioPluginInstance& instance, int& count)
    {
        const bool instrument=instance.getPluginDescription().isInstrument;
        auto layout = instance.getBusesLayout();
        if ((!instrument && layout.inputBuses.isEmpty()) || layout.outputBuses.isEmpty()) return false;
        for (int ch : { 2, 1 })
        {
            for (auto& bus : layout.inputBuses) bus = juce::AudioChannelSet::disabled();
            for (auto& bus : layout.outputBuses) bus = juce::AudioChannelSet::disabled();
            if(!instrument)layout.inputBuses.getReference(0)=juce::AudioChannelSet::canonicalChannelSet(ch);
            layout.outputBuses.getReference(0)=juce::AudioChannelSet::canonicalChannelSet(ch);
            if (instance.setBusesLayout(layout)) { count = ch; return true; }
        }
        return false;
    }
    void prepare(double rate)
    {
        clock.rate = rate;
        for (auto& channel : channels) for (auto& slot : channel)
            if (slot && slot->instance)
            {
                slot->instance->releaseResources(); slot->instance->setRateAndBufferSizeDetails(rate, PlaybackCore::processBlockSize);
                slot->instance->prepareToPlay(rate, PlaybackCore::processBlockSize);
            }
    }
    juce::Result install(size_t channel, int index, const juce::PluginDescription& description,
                         std::unique_ptr<juce::AudioPluginInstance> instance, const juce::MemoryBlock& state, bool bypassed, double rate)
    {
        if(description.isInstrument && (channel>=PlaybackCore::maxTracks || !midiLanes[channel].enabled || index!=0))return juce::Result::fail("Load instruments in insert A of a MIDI track.");
        auto slot = std::make_unique<Slot>(); slot->description = description; slot->retainedState = state;
        slot->occupied = true; slot->bypass = bypassed;
        if (instance)
        {
            int64_t path = bypassed ? 0 : std::max(0, instance->getLatencySamples());
            for (int other = 0; other < slotsPerChannel; ++other)
                if (other != index)
                {
                    const auto& previous = channels[channel][static_cast<size_t>(other)];
                    if (previous && previous->instance && !previous->bypass.load()) path += std::max(0, previous->instance->getLatencySamples());
                }
            if (path > maximumPathLatency) return juce::Result::fail("Insert chain exceeds 65,536 samples of supported playback latency.");
            if (!configure(*instance, slot->channels)) return juce::Result::fail("Use a mono/stereo effect or an instrument with a disabled input and mono/stereo output.");
            instance->setPlayHead(&clock);
            instance->setRateAndBufferSizeDetails(rate, PlaybackCore::processBlockSize);
            if (state.getSize()) instance->setStateInformation(state.getData(), static_cast<int>(state.getSize()));
            instance->prepareToPlay(rate, PlaybackCore::processBlockSize);
            slot->instance = std::move(instance);
            slot->instance->addListener(slot.get());
        }
        channels[channel][static_cast<size_t>(index)] = std::move(slot);
        return juce::Result::ok();
    }
    void editor(size_t channel, int index)
    {
        auto& slot = channels[channel][static_cast<size_t>(index)];
        if (!slot || !slot->instance) return;
        if (!slot->window) slot->window = std::make_unique<EditorWindow>(*slot->instance);
        slot->window->setVisible(true); slot->window->toFront(true);
    }
    bool consumeChanges()
    {
        bool changed = false;
        for (auto& channel : channels) for (auto& slot : channel)
            if (slot) changed = slot->changed.exchange(false) || changed;
        return changed;
    }
    juce::Array<juce::var> snapshot(int trackCount) const
    {
        juce::Array<juce::var> result;
        for (size_t channel = 0; channel < channels.size(); ++channel)
        {
            if (channel >= static_cast<size_t>(trackCount) && channel != PlaybackCore::maxTracks) continue;
            for (int index = 0; index < slotsPerChannel; ++index)
            {
                const auto& slot = channels[channel][static_cast<size_t>(index)]; if (!slot) continue;
                auto* item = new juce::DynamicObject(); item->setProperty("channel", static_cast<int>(channel)); item->setProperty("slot", index);
                item->setProperty("name", slot->description.name); item->setProperty("bypass", slot->bypass.load()); item->setProperty("missing", slot->instance == nullptr);
                item->setProperty("latency", slot->instance ? slot->instance->getLatencySamples() : 0);
                item->setProperty("compensation", compensation[channel].samples());
                result.add(juce::var(item));
            }
        }
        return result;
    }
    juce::Array<juce::var> save()
    {
        juce::Array<juce::var> result;
        for (size_t channel = 0; channel < channels.size(); ++channel) for (int index = 0; index < slotsPerChannel; ++index)
        {
            auto& slot = channels[channel][static_cast<size_t>(index)]; if (!slot) continue;
            if (slot->instance) slot->instance->getStateInformation(slot->retainedState);
            auto* item = new juce::DynamicObject(); item->setProperty("channel", static_cast<int>(channel)); item->setProperty("slot", index);
            item->setProperty("description", slot->description.createXml()->toString()); item->setProperty("state", slot->retainedState.toBase64Encoding());
            item->setProperty("bypass", slot->bypass.load()); result.add(juce::var(item));
        }
        return result;
    }
    static void process(void* context, size_t channel, float* left, float* right, int frames, double seconds, double bpm, bool playing)
    {
        auto& rack = *static_cast<PluginRack*>(context); rack.clock.seconds = seconds; rack.clock.bpm = bpm; rack.clock.playing = playing;
        if(channel==PlaybackCore::maxTracks+2){rack.directCompensation.process(left,right,frames);return;}
        if (channel == clickChannel) { rack.compensation[channel].process(left, right, frames); return; }
        for (auto& slot : rack.channels[channel])
        {
            if (!slot || !slot->instance || slot->bypass.load(std::memory_order_relaxed)) continue;
            float* data[] { slot->buffer.getWritePointer(0), slot->buffer.getWritePointer(1) };
            if (slot->channels == 1)
                for (int n = 0; n < frames; ++n) data[0][n] = (left[n] + right[n]) * 0.5f;
            else { std::copy_n(left, frames, data[0]); std::copy_n(right, frames, data[1]); }
            // This wrapper points to preallocated storage; MIDI output is discarded.
            juce::AudioBuffer<float> view(data, slot->channels, frames);
            slot->midi.clear();
            if(slot->description.isInstrument && channel<PlaybackCore::maxTracks)rack.midiLanes[channel].emit(slot->midi,seconds,bpm,rack.clock.rate.load(),frames,playing);
            slot->instance->processBlock(view, slot->midi);
            for (int n = 0; n < frames; ++n)
            {
                left[n] = std::isfinite(data[0][n]) ? data[0][n] : 0.0f;
                right[n] = std::isfinite(data[slot->channels - 1][n]) ? data[slot->channels - 1][n] : 0.0f;
            }
        }
        if (channel < PlaybackCore::maxTracks && static_cast<int>(channel) != rack.monitorChannel) rack.compensation[channel].process(left, right, frames);
    }
};
