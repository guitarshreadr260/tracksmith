# Tracksmith

Latest Windows Release: retakes, fades and playlists update, October 14, 2026.

## Run

Extract the whole application ZIP, keep **Stock Plugins** beside **Tracksmith.exe**, then launch it. Save your session and close an older instance before starting this build. Windows x64 and Microsoft Edge WebView2 Runtime are required.

## This build

- Recorded-range replacement with Undo and bounded earlier-playlist backups.
- Audio/MIDI playlists with new, duplicate, rename, switch and selected-range comp copying.
- Linear fades and handle-based crossfades in playback and export.

- Stereo aux/bus tracks with inserts and faders, per-source output routing and two post-fader sends.
- Saved routing and shared effects in playback, live monitoring and WAV export.

- Existing audio files play while input monitoring is active, including clips on the monitored track. Live input and clips share one track effects pass and one master effects pass.
- Each audio track has a saved input assignment and mono/stereo capture mode.
- Up to eight armed audio tracks record together into separate dry WAVs, using a shared timeline, count-in and punch range.
- Stereo WAV export, general MIDI/instrument lanes, clip editing, mixer controls, session Save/Open and AVRX NAM are retained.

See TAKES-PLAYLISTS-GUIDE.md, MIXER-ROUTING-GUIDE.md, RECORDING-GUIDE.md, EXPORT-GUIDE.md and TIMELINE-GUIDE.md for workflows and limits. AVRX Drums is excluded. AVRX Groove v0.17 is saved separately for later work. Custom UI design remains deferred.

Automatic hardware recording-latency alignment, hardware MIDI recording, deeper bus routing, loop playlists and automation remain future work. Hardware listening and the user's own interface/plugin combinations need local testing.

## Source project

The existing React/TypeScript UI is hosted by JUCE 8.0.10 WebBrowserComponent. Native C++ owns recording, playback, devices, MIDI scheduling and VST3 processing. Browser messages carry controls and metering only. The UI bundle is supplied in ui/dist. Enable TRACKSMITH_BUILD_TESTS for the native tests. AVRX NAM remains a separate stock VST3; its third-party sources and notices are included under plugins/AvrxNam.


Current automation build: see AUTOMATION-GUIDE.md for track volume/pan Off/Read/Write, editable curves, automation undo and WAV export. New saves use session version 7 and can open versions 1–7. Plugin scanner improvements are deferred.
