#include "PluginProcessor.h"
#include <iostream>
#include <cstdlib>
static void require(bool ok,const char* m){if(!ok){std::cerr<<"FAIL: "<<m<<'\n';std::exit(1);}}
struct Head:juce::AudioPlayHead{double bpm=120,ppq=0;bool running=true;juce::Optional<PositionInfo> getPosition()const override{PositionInfo p;p.setBpm(bpm);p.setPpqPosition(ppq);p.setIsPlaying(running);return p;}};
static void parameter(AvrxGrooveProcessor& p,const char* id,float value){auto* v=p.parameters.getParameter(id);require(v!=nullptr,"parameter exists");v->setValueNotifyingHost(v->convertTo0to1(value));}
int main()
{
    juce::ScopedJuceInitialiser_GUI gui;auto p=std::make_unique<AvrxGrooveProcessor>();p->prepareToPlay(48000,256);p->setAmbience(0,0);p->setHumanFeel(0,0);
    for(int drum=0;drum<9;++drum)for(int step=0;step<p->getKit()->stepCount();++step)p->setStepVelocity(drum,step,0);
    p->setStepVelocity(0,0,.8f);p->setStepVelocity(0,4,.7f);Head host;p->setPlayHead(&host);parameter(*p,"run",1);juce::AudioBuffer<float> audio(2,256);
    const auto render=[&](int blocks){std::vector<int> notes;for(int b=0;b<blocks;++b){audio.clear();juce::MidiBuffer midi;p->processBlock(audio,midi);for(const auto metadata:midi)if(metadata.getMessage().isNoteOn())notes.push_back(b*256+metadata.samplePosition);for(int ch=0;ch<2;++ch)for(int n=0;n<256;++n)require(std::isfinite(audio.getSample(ch,n)),"clock audio finite");if(host.running)host.ppq+=256*host.bpm/(60*48000);}return notes;};
    auto notes=render(100);require(notes==std::vector<int>({0,24000}),"host 120 BPM exact MIDI onset offsets");
    host.running=false;notes=render(8);require(notes.empty(),"host Stop gates sequencer even while Run stays enabled");
    host.ppq=1;host.running=true;notes=render(1);require(notes==std::vector<int>({0}),"host seek locates beat-one pattern hit at sample zero");
    host.ppq=0;notes=render(1);require(notes==std::vector<int>({0}),"loop return restarts pattern at host grid");
    p->reset();host.ppq=0;host.bpm=90;notes=render(130);require(notes==std::vector<int>({0,32000}),"host tempo change to 90 BPM updates note spacing");
    parameter(*p,"hostSync",0);parameter(*p,"tempo",120);host.running=false;p->reset();notes=render(100);require(notes==std::vector<int>({0,24000}),"manual preview works when Follow DAW is disabled");
    parameter(*p,"run",0);p->reset();audio.clear();juce::MidiBuffer external;external.addEvent(juce::MidiMessage::noteOn(10,36,.9f),32);p->processBlock(audio,external);require(audio.getMagnitude(0,256)>.001f,"incoming MIDI plays instrument with internal sequencer off");
    p->setPadGain(0,.321f);p->setPadPan(0,-.37f);p->grooveTitle="Host state groove";juce::MemoryBlock state;p->getStateInformation(state);auto q=std::make_unique<AvrxGrooveProcessor>();q->prepareToPlay(48000,256);q->setStateInformation(state.getData(),static_cast<int>(state.getSize()));require(q->getKit()->pattern==p->getKit()->pattern&&std::abs(q->getKit()->gains[0]-.321f)<.00001f&&std::abs(q->getKit()->pan[0]+.37f)<.00001f&&q->grooveTitle=="Host state groove","full processor host state retains kit, groove, mix and parameters");q->setPadGain(0,.5f);require(std::abs(p->getKit()->gains[0]-.321f)<.00001f,"multiple instances retain separate state");
    auto* editor=q->createEditor();require(editor!=nullptr,"renamed editor constructs after recall");delete editor;
    std::cout<<"PASS: sample-offset DAW sync, stop, seek, loop return, tempo change, manual preview, MIDI input and full isolated state recall.\n";
}
