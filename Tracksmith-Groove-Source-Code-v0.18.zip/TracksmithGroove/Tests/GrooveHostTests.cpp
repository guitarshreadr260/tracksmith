#include "PluginRack.h"
#include "SessionFile.h"
#include "MixExport.h"
#include <iostream>
#include <cstdlib>
static void require(bool ok,const char* message){if(!ok){std::cerr<<"FAIL: "<<message<<'\n';std::exit(1);}}
static std::unique_ptr<juce::XmlElement> componentState(const juce::MemoryBlock& vstState){auto wrapper=juce::AudioProcessor::getXmlFromBinary(vstState.getData(),static_cast<int>(vstState.getSize()));require(wrapper!=nullptr,"VST3 state XML wrapper");auto* component=wrapper->getChildByName("IComponent");require(component!=nullptr,"VST3 component state");juce::MemoryBlock data;require(data.fromBase64Encoding(component->getAllSubText()),"VST3 component base64");return juce::AudioProcessor::getXmlFromBinary(data.getData(),static_cast<int>(data.getSize()));}
int main(int argc,char** argv)
{
    juce::ScopedJuceInitialiser_GUI gui;require(argc==3,"provide bundle and test folder");const auto folder=juce::File(argv[2]);require(folder.createDirectory().wasOk(),"host test folder");
    PluginRack rack;juce::OwnedArray<juce::PluginDescription> found;rack.formats.getFormat(0)->findAllTypesForFile(found,juce::String(argv[1]));require(found.size()==1&&found[0]->name=="Tracksmith Groove"&&found[0]->isInstrument,"Tracksmith Groove scans as named VST3 instrument");
    juce::String error;auto plugin=rack.formats.createPluginInstance(*found[0],48000,256,error);if(!plugin)std::cerr<<error<<'\n';require(plugin!=nullptr,"create actual VST3 instrument");
    rack.midiLanes[0].enabled=true;require(rack.install(0,0,*found[0],std::move(plugin),{},false,48000).wasOk(),"install actual instrument in Tracksmith insert A with input disabled");
    auto& slot=rack.channels[0][0];require(slot->instance->getTotalNumInputChannels()==0&&slot->instance->getTotalNumOutputChannels()==2,"DAW instrument bus layout");
    juce::MemoryBlock initial;slot->instance->getStateInformation(initial);auto state=componentState(initial);require(state&&state->hasTagName("AVRX_PRESET")&&state->getChildByName("Kit"),"host state contains full kit");
    require(state->getChildByName("Kit")->getStringAttribute("packName").containsIgnoreCase("Luke"),"bundled sampled kit loaded without standalone");
    auto core=std::make_unique<PlaybackCore>();core->deviceRate=48000;core->tracks[0].midiTrack=true;core->tracks[0].midiSeconds=16;core->tracks[0].gain=1;core->process=PluginRack::process;core->processContext=&rack;core->bpm=120;rack.rebuildCompensation(*core);core->refreshDuration();
    float left[256]{},right[256]{};float* output[]{left,right};
    core->render(output,2,256);require(std::all_of(std::begin(left),std::end(left),[](float x){return std::abs(x)<1.e-7f;}),"host stopped has no sequencer notes");
    core->playing=true;float peak=0;for(int block=0;block<400;++block){core->render(output,2,256);for(float sample:left){require(std::isfinite(sample),"finite real plugin audio");peak=std::max(peak,std::abs(sample));}}require(peak>.001f,"Tracksmith transport drives sampled drum output without MIDI notes or editor");
    // Save a changed kit and pattern in the same VST3 state used by Tracksmith sessions.
    auto* pad=state->getChildByName("Kit")->getChildByName("Pad");require(pad!=nullptr,"kit pad exists");pad->setAttribute("gain",.321);pad->setAttribute("pan",-.37);state->setAttribute("grooveTitle","Host recall test");
    auto* hit=pad->createNewChildElement("Hit");hit->setAttribute("step",3);hit->setAttribute("velocity",.456);
    juce::MemoryBlock payload;juce::AudioProcessor::copyXmlToBinary(*state,payload);juce::XmlElement wrapper("VST3PluginState");wrapper.createNewChildElement("IComponent")->addTextElement(payload.toBase64Encoding());juce::MemoryBlock changed;juce::AudioProcessor::copyXmlToBinary(wrapper,changed);slot->instance->setStateInformation(changed.getData(),static_cast<int>(changed.getSize()));
    juce::MemoryBlock after;slot->instance->getStateInformation(after);auto actual=componentState(after);require(actual&&actual->getStringAttribute("grooveTitle")=="Host recall test"&&std::abs(actual->getChildByName("Kit")->getChildByName("Pad")->getDoubleAttribute("gain")-.321)<1.e-5,"full host state restore includes groove title and kit mix");
    auto second=rack.formats.createPluginInstance(*found[0],48000,256,error);rack.midiLanes[1].enabled=true;require(second&&rack.install(1,0,*found[0],std::move(second),after,false,48000).wasOk(),"independent second VST3 restores saved kit state");juce::MemoryBlock secondState;rack.channels[1][0]->instance->getStateInformation(secondState);auto secondXml=componentState(secondState);require(secondXml->getStringAttribute("grooveTitle")=="Host recall test","independent instance state survives");rack.channels[1][0].reset();
    slot->instance->setStateInformation(initial.getData(),static_cast<int>(initial.getSize()));
    core->playing=false;rack.resetGraph();const auto wave=folder.getChildFile("Tracksmith-Groove-Demo.wav");auto rendered=writeMixWav(*core,wave,{0,2,0,24},{},{});require(rendered.error.isEmpty()&&rendered.frames==96000,"Tracksmith offline WAV export renders Groove");juce::WavAudioFormat format;std::unique_ptr<juce::AudioFormatReader> reader(format.createReaderFor(wave.createInputStream().release(),true));juce::AudioBuffer<float> audio(2,96000);require(reader&&reader->read(&audio,0,96000,0,true,true)&&audio.getMagnitude(0,96000)>.001f,"exported plugin drum audio audible");
    // Opening the editor is not required for assets, clock or host state, but verify it can render.
    auto* editor=slot->instance->createEditorIfNeeded();require(editor!=nullptr,"actual VST3 editor opens");auto image=editor->createComponentSnapshot(editor->getLocalBounds());juce::PNGImageFormat png;auto imageFile=folder.getChildFile("Tracksmith-Groove-Editor.png");auto stream=imageFile.createOutputStream();require(stream&&png.writeImageToStream(image,*stream),"plugin editor snapshot");stream.reset();
    SavedSession demo;demo.bpm=120;demo.loop=true;SessionTrack track;track.name="Tracksmith Groove";track.midiTrack=true;track.timelineEnabled=true;track.gain=.75f;track.notes={{1,127,1,29.75,.25,.01f}};demo.tracks.push_back(track);auto session=folder.getChildFile("Tracksmith-Groove-Demo.tracksmith");require(SessionFile::write(session,SessionFile::encode(demo,session)).wasOk(),"portable eight-bar host demo session writes");
    demo.inserts=rack.save();auto ready=folder.getChildFile("Tracksmith-Groove-Ready-To-Play.tracksmith");require(SessionFile::write(ready,SessionFile::encode(demo,ready)).wasOk(),"ready-to-play local host session writes");
    std::cout<<"PASS: actual Tracksmith rack scan, instrument bus configuration, host transport, bundled kit, independent full-state recall, WAV export, editor and demo session.\n";
}
