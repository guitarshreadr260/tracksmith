#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "Tone3000Panel.h"
#include <iostream>
#include <chrono>

static void require (bool condition, const char* message) { if (! condition) throw std::runtime_error (message); }
static void waitSample (AvrxGrooveProcessor& p)
{
    for (int i = 0; i < 1000 && p.isLoadingSample(); ++i) std::this_thread::sleep_for (std::chrono::milliseconds (10));
    require (! p.isLoadingSample(), "Sample load timed out");
}
static void waitRecorder (MultitrackEngine& recorder)
{
    for (int n = 0; n < 1000 && recorder.loading.load(); ++n) std::this_thread::sleep_for (std::chrono::milliseconds (10));
    require (! recorder.loading.load(), "Multitrack loading timed out");
}
static void saveWav (const juce::File& file, const juce::AudioBuffer<float>& buffer, double rate)
{
    std::unique_ptr<juce::OutputStream> stream = file.createOutputStream(); juce::WavAudioFormat wav;
#if JUCE_MAJOR_VERSION >= 9
    auto writer = wav.createWriterFor (stream, juce::AudioFormatWriterOptions().withSampleRate (rate).withNumChannels (buffer.getNumChannels()).withBitsPerSample (24));
#else
    std::unique_ptr<juce::AudioFormatWriter> writer (wav.createWriterFor (stream.release(), rate, static_cast<unsigned int> (buffer.getNumChannels()), 24, {}, 0));
#endif
    require (writer && writer->writeFromAudioSampleBuffer (buffer, 0, buffer.getNumSamples()), "WAV fixture failed");
}
static void snapshot (juce::Component& editor, const juce::File& file)
{
    juce::Timer::callPendingTimersSynchronously();
    for (int n = 0; n < editor.getNumChildComponents(); ++n)
    {
        if (auto* mixer = dynamic_cast<MixerPanel*> (editor.getChildComponent (n))) mixer->refresh();
        if (auto* strip = dynamic_cast<ChannelStripPanel*> (editor.getChildComponent (n))) strip->refresh();
        if (auto* audio = dynamic_cast<AudioPanel*> (editor.getChildComponent (n))) audio->refresh();
        if (auto* recorder = dynamic_cast<MultitrackPanel*> (editor.getChildComponent (n))) recorder->refresh();
        if (auto* guitar = dynamic_cast<GuitarPanel*> (editor.getChildComponent (n))) guitar->refresh();
    }
    auto output = file.createOutputStream(); require (output != nullptr, "Preview output failed"); output->setPosition (0); output->truncate();
    juce::PNGImageFormat png; require (png.writeImageToStream (editor.createComponentSnapshot (editor.getLocalBounds()), *output), "Preview failed");
}

int main (int argc, char** argv)
{
    std::cout << std::unitbuf;
    juce::ScopedJuceInitialiser_GUI initialise;
    try
    {
        const auto folder = argc > 1 ? juce::File (argv[1]) : juce::File::getSpecialLocation (juce::File::tempDirectory).getNonexistentChildFile ("avrx-v05-tests", "", false);
        require (folder.createDirectory().wasOk(), "Test folder failed");
        DrumChannelStrip bypass; bypass.prepare (48000);
        require (bypass.render ({ 0.3f, -0.2f }) == std::array<float, 2> { 0.3f, -0.2f }, "Default strip is not transparent");
        auto steady = [] (float mix, float ratio)
        {
            DrumChannelStrip strip; strip.prepare (48000); DrumShaping settings;
            settings.compressorOn = true; settings.compressorMix = mix; settings.ratio = ratio; strip.update (settings);
            std::array<float, 2> result {};
            for (int n = 0; n < 48000; ++n) result = strip.render ({ 0.5f, 0.25f });
            require (std::abs (result[0] - 2 * result[1]) < 1e-6f, "Compressor is not stereo linked");
            return result[0];
        };
        const float dry = steady (0, 4), wet = steady (1, 4), parallel = steady (0.5f, 4);
        require (std::abs (dry - 0.5f) < 1e-6f && std::abs (wet - 0.1777f) < 0.002f, "Compressor static curve failed");
        require (std::abs (parallel - (dry + wet) * 0.5f) < 1e-5f && steady (1, 20) < wet, "Parallel mix or ratio failed");
        DrumChannelStrip eq; eq.prepare (48000); DrumShaping boost; boost.eqOn = true; boost.frequency[1] = 1000; boost.gainDb[1] = 6; eq.update (boost);
        double inputEnergy = 0, outputEnergy = 0;
        for (int n = 0; n < 48000; ++n)
        {
            const float value = static_cast<float> (0.1 * std::sin (n * juce::MathConstants<double>::twoPi * 1000 / 48000));
            const auto processed = eq.render ({ value, value });
            if (n > 24000) { inputEnergy += value * value; outputEnergy += processed[0] * processed[0]; }
        }
        require (std::abs (std::sqrt (outputEnergy / inputEnergy) - std::pow (10.0, 6.0 / 20)) < 0.01, "EQ centre gain failed");
        std::cout << "Channel-strip bypass, EQ gain, stereo compression, ratio and parallel mix passed\n";
        DrumChannelStrip hp; hp.prepare (48000); DrumShaping cut; cut.eqOn = cut.highPassOn = true; cut.highPassHz = 120; hp.update (cut);
        double lowIn = 0, lowOut = 0;
        for (int n = 0; n < 48000; ++n)
        {
            const float v = static_cast<float> (0.1 * std::sin (n * juce::MathConstants<double>::twoPi * 20 / 48000)); const auto r = hp.render ({ v, v });
            if (n > 24000) { lowIn += v * v; lowOut += r[0] * r[0]; }
        }
        require (std::sqrt (lowOut / lowIn) < 0.04, "High-pass did not remove sub-bass");
        for (const double rate : { 22050.0, 48000.0, 192000.0 })
        {
            DrumChannelStrip extreme; extreme.prepare (rate); DrumShaping settings; settings.eqOn = settings.compressorOn = settings.highPassOn = true;
            settings.gainDb = { 15, -15, 15, -15 }; settings.frequency = { 20, 20000, 20, 20000 }; settings.q = { 4, 4, 4, 4 }; settings.inputDb = 24; settings.ratio = 20;
            extreme.update (settings);
            for (int n = 0; n < 24000; ++n) { const auto r = extreme.render ({ n % 2 == 0 ? 0.1f : -0.1f, 0.03f }); require (std::isfinite (r[0]) && std::isfinite (r[1]), "Extreme strip settings unstable"); }
        }
        AvrxGrooveProcessor dryPad, compressedPad; dryPad.prepareToPlay (48000, 512); compressedPad.prepareToPlay (48000, 512);
        DrumShaping padComp; padComp.compressorOn = true; padComp.compressorMix = 1; padComp.thresholdDb = -40; padComp.ratio = 20; compressedPad.setDrumShaping (0, padComp);
        dryPad.auditionPad (0); compressedPad.auditionPad (0); double dryPower = 0, compPower = 0;
        juce::AudioBuffer<float> dryBuffer (2, 512), compBuffer (2, 512); juce::MidiBuffer padMidi;
        for (int block = 0; block < 12; ++block)
        {
            dryBuffer.clear(); compBuffer.clear(); dryPad.processBlock (dryBuffer, padMidi); padMidi.clear(); compressedPad.processBlock (compBuffer, padMidi); padMidi.clear();
            for (int n = 0; n < 512; ++n) { dryPower += std::pow (dryBuffer.getSample (0, n), 2); compPower += std::pow (compBuffer.getSample (0, n), 2); }
        }
        require (dryPower > 0.01 && compPower < dryPower * 0.4, "Processor did not apply selected pad compression");
        std::cout << "High-pass, sample-rate extremes and pad audio integration passed\n";
        auto padPower = [] (float pan, bool soloOther, bool muted)
        {
            AvrxGrooveProcessor engine; engine.prepareToPlay (48000, 512); engine.setPadPan (0, pan); engine.setPadSolo (1, soloOther); engine.setPadMuted (0, muted); engine.auditionPad (0);
            juce::AudioBuffer<float> buffer (2, 512); juce::MidiBuffer messages; std::array<double, 2> power {};
            for (int block = 0; block < 8; ++block) { buffer.clear(); messages.clear(); engine.processBlock (buffer, messages); for (int n = 0; n < 512; ++n) for (size_t c = 0; c < 2; ++c) power[c] += std::pow (buffer.getSample (static_cast<int> (c), n), 2); }
            return power;
        };
        const auto centred = padPower (0, false, false), left = padPower (-1, false, false), right = padPower (1, false, false), excluded = padPower (0, true, false), mutedPower = padPower (0, false, true);
        require (centred[0] > 0.1 && std::abs (centred[0] - centred[1]) < 1e-7 && left[1] == 0 && right[0] == 0 && left[0] > 0 && right[1] > 0, "Drum mixer pan routing failed");
        require (excluded[0] == 0 && excluded[1] == 0 && mutedPower[0] == 0 && mutedPower[1] == 0, "Drum mixer mute/solo failed");
        AvrxGrooveProcessor soloMidi; soloMidi.setPadSolo (0, true); const auto soloFile = soloMidi.createMidiDragFile(); auto soloInput = soloFile.createInputStream(); juce::MidiFile soloRead; require (soloInput && soloRead.readFrom (*soloInput), "Solo MIDI unreadable"); bool soloKick = false;
        for (int track = 0; track < soloRead.getNumTracks(); ++track) for (int n = 0; n < soloRead.getTrack (track)->getNumEvents(); ++n) { const auto m = soloRead.getTrack (track)->getEventPointer (n)->message; if (m.isNoteOn()) { require (m.getNoteNumber() == 36, "Solo did not filter MIDI drag"); soloKick = true; } }
        require (soloKick, "Solo removed all MIDI hits");
        std::cout << "Mixer pan, mute, solo and MIDI filtering passed\n";
        const auto takeFolder = folder.getChildFile ("Automatic Takes"); require (takeFolder.createDirectory().wasOk(), "Take folder failed");
        RecordingLocation destination; require (destination.set (takeFolder), "Recording folder selection failed");
        const auto preferenceFile = folder.getChildFile ("prefs/recording-folder.txt"); require (destination.save (preferenceFile), "Recording folder save failed");
        RecordingLocation restored; require (restored.restore (preferenceFile) && restored.get() == takeFolder, "Recording folder did not persist");
        const auto firstPath = destination.nextTake ("Guitar"); require (firstPath.getParentDirectory() == takeFolder && firstPath.replaceWithText ("keep original"), "Automatic take path invalid");
        const auto secondPath = destination.nextTake ("Guitar"); require (secondPath != firstPath && firstPath.loadFileAsString() == "keep original", "Automatic take would overwrite previous take");
        const auto midiLibrary = folder.getChildFile ("Groove Library"); require (midiLibrary.createDirectory().wasOk(), "MIDI library fixture folder failed");
        auto makeGrooveFile = [&] (const juce::File& file, int numerator, int denominator, bool triplet, int type = 1, bool smpte = false, bool tempoChange = false)
        {
            juce::MidiFile fixture; if (smpte) fixture.setSmpteTimeFormat (25, 40); else fixture.setTicksPerQuarterNote (480);
            juce::MidiMessageSequence metadata, notes;
            metadata.addEvent (juce::MidiMessage::tempoMetaEvent (416667)); metadata.addEvent (juce::MidiMessage::timeSignatureMetaEvent (numerator, denominator));
            if (tempoChange) metadata.addEvent (juce::MidiMessage::tempoMetaEvent (500000), 480);
            const double end = triplet ? 1920 : 3360;
            notes.addEvent (juce::MidiMessage::noteOn (10, 35, static_cast<juce::uint8> (100)), 0);
            notes.addEvent (juce::MidiMessage::noteOff (10, 35), 40);
            notes.addEvent (juce::MidiMessage::noteOn (10, 44, static_cast<juce::uint8> (80)), triplet ? 160 : 120);
            notes.addEvent (juce::MidiMessage::noteOff (10, 44), triplet ? 200 : 160);
            notes.addEvent (juce::MidiMessage::noteOn (10, 38, static_cast<juce::uint8> (110)), triplet ? 320 : 480);
            notes.addEvent (juce::MidiMessage::noteOff (10, 38), triplet ? 360 : 520);
            if (! triplet) { notes.addEvent (juce::MidiMessage::noteOn (10, 36, static_cast<juce::uint8> (95)), 1680); notes.addEvent (juce::MidiMessage::noteOff (10, 36), 1720); notes.addEvent (juce::MidiMessage::noteOn (1, 60, static_cast<juce::uint8> (100)), 240); }
            metadata.addEvent (juce::MidiMessage::endOfTrack(), end); notes.addEvent (juce::MidiMessage::endOfTrack(), end); fixture.addTrack (metadata); fixture.addTrack (notes);
            require (file.getParentDirectory().createDirectory().wasOk(), "MIDI fixture directory failed"); auto stream = file.createOutputStream(); require (stream != nullptr, "MIDI fixture stream failed"); stream->setPosition (0); stream->truncate(); require (fixture.writeTo (*stream, type), "MIDI fixture failed");
        };
        const auto grooveFile = midiLibrary.getChildFile ("Seven-Eight.mid"); makeGrooveFile (grooveFile, 7, 8, false);
        const auto tripletFile = midiLibrary.getChildFile ("Triplets/Shuffle.midi"); makeGrooveFile (tripletFile, 4, 4, true);
        DrumKit midiKit; const auto loadedGroove = MidiGroove::read (grooveFile, midiKit, 120), loadedTriplet = MidiGroove::read (tripletFile, midiKit, 120);
        require (loadedGroove.valid && loadedGroove.bars == 2 && loadedGroove.numerator == 7 && loadedGroove.denominator == 8 && loadedGroove.division == 4 && std::abs (loadedGroove.bpm - 144) < .01 && loadedGroove.mapped == 4 && loadedGroove.ignored == 1, "MIDI groove metadata/mapping failed");
        require (loadedGroove.pattern[0][0] > .7f && loadedGroove.pattern[0][14] > .7f && loadedGroove.pattern[2][1] > .5f && loadedTriplet.valid && loadedTriplet.division == 3, "GM aliases or triplet grid failed");
        const auto badType = folder.getChildFile ("Format2.mid"), badClock = folder.getChildFile ("SMPTE.mid"), changing = folder.getChildFile ("ChangingTempo.mid");
        makeGrooveFile (badType, 7, 8, false, 2); makeGrooveFile (badClock, 7, 8, false, 1, true); makeGrooveFile (changing, 7, 8, false, 1, false, true);
        require (! MidiGroove::read (badType, midiKit, 120).valid && ! MidiGroove::read (badClock, midiKit, 120).valid && ! MidiGroove::read (changing, midiKit, 120).valid, "Unsupported MIDI accepted");
        auto groovePlayerStorage = std::make_unique<AvrxGrooveProcessor>(); auto& groovePlayer = *groovePlayerStorage; groovePlayer.prepareToPlay (48000, 512); groovePlayer.setPadGain (0, .73f); require (groovePlayer.applyGroove (loadedGroove) && groovePlayer.getKit()->gains[0] == .73f, "Groove import changed drum mix");
        const auto kitBeforeBad = groovePlayer.getKit(); require (! groovePlayer.applyGroove ({}) && groovePlayer.getKit() == kitBeforeBad, "Invalid groove changed current pattern");
        groovePlayer.playGroove(); juce::AudioBuffer<float> grooveAudio (2, 512); juce::MidiBuffer grooveMidi; std::vector<int> kickTimes; float groovePeak = 0;
        for (int block = 0; block < 548; ++block) { grooveAudio.clear(); grooveMidi.clear(); groovePlayer.processBlock (grooveAudio, grooveMidi); groovePeak = juce::jmax (groovePeak, grooveAudio.getMagnitude (0, 512)); for (const auto event : grooveMidi) if (event.getMessage().isNoteOn() && event.getMessage().getNoteNumber() == 36) kickTimes.push_back (block * 512 + event.samplePosition); }
        std::cout << "Imported groove peak=" << groovePeak << " tempo=" << groovePlayer.parameters.getRawParameterValue ("tempo")->load() << " kicks:"; for (const auto t : kickTimes) std::cout << " " << t; std::cout << "\n";
        require (groovePeak > .05f && kickTimes.size() >= 4 && std::abs (kickTimes[0]) <= 1 && std::abs (kickTimes[1] - 70000) <= 1 && std::abs (kickTimes[2] - 140000) <= 1 && std::abs (kickTimes[3] - 210000) <= 1, "MIDI groove loop playback timing failed");
        groovePlayer.stopTogether();
        std::cout << "Recording destination persistence/unique names and MIDI groove import/loop checks passed\n";
        for (const double bpm : { 90.0, 120.0, 150.0 })
        {
            constexpr double rate = 22050;
            juce::AudioBuffer<float> beat (1, static_cast<int> (rate * 12)); beat.clear();
            for (double hit = 0.25; hit < 11.8; hit += 60 / bpm)
                for (int n = 0; n < 2400; ++n)
                    if (static_cast<int> (hit * rate) + n < beat.getNumSamples())
                        beat.addSample (0, static_cast<int> (hit * rate) + n, static_cast<float> (0.8 * std::sin (n * 80 * juce::MathConstants<double>::twoPi / rate) * std::exp (-n / 500.0)));
            const auto analysis = GrooveAnalysis::analyse (beat, rate);
            juce::AudioBuffer<float> stereo (2, beat.getNumSamples()); stereo.copyFrom (0, 0, beat, 0, 0, beat.getNumSamples()); stereo.copyFrom (1, 0, beat, 0, 0, beat.getNumSamples()); stereo.applyGain (1, 0, beat.getNumSamples(), -1);
            const auto opposite = GrooveAnalysis::analyse (stereo, rate);
            require (opposite.valid && opposite.pattern == analysis.pattern && std::abs (opposite.bpm - analysis.bpm) < 0.01, "Stereo phase cancellation changed analysis");
            require (analysis.hitStrengths.size() == analysis.onsets.size() && analysis.timingOffsetsMs.size() == analysis.onsets.size(), "Onset metadata incomplete");
            require (analysis.valid && std::abs (analysis.bpm - bpm) <= 2, "Tempo estimate failed");
        }
        juce::AudioBuffer<float> dynamics (1, 22050 * 8); dynamics.clear();
        for (int hit = 0; hit < 32; ++hit)
        {
            const int start = 2000 + static_cast<int> (hit * 22050 * 0.25);
            for (int n = 0; n < 2400 && start + n < dynamics.getNumSamples(); ++n)
                dynamics.setSample (0, start + n, static_cast<float> ((hit % 2 == 0 ? 0.7 : 0.07) * std::sin (n * 0.023) * std::exp (-n / 500.0)));
        }
        const auto strict = GrooveAnalysis::analyse (dynamics, 22050, 0.5f);
        const auto sensitive = GrooveAnalysis::analyse (dynamics, 22050, 3.0f);
        require (sensitive.onsetCount > strict.onsetCount && ! sensitive.onsets.empty(), "Detection strength did not reveal softer attacks");
        juce::AudioBuffer<float> silence (1, 48000 * 5); silence.clear();
        require (! GrooveAnalysis::analyse (silence, 48000).valid, "Silence accepted");

        AvrxGrooveProcessor p; p.prepareToPlay (48000, 512);
        require (p.getKit()->stepCount() == 64, "Default sequence is not four bars");
        require (p.setSequence (8, 7, 8, 4) && p.getKit()->stepCount() == 112, "7/8 length is wrong");
        p.setStepVelocity (6, 100, 0.9f); require (p.getKit()->pattern[6][100] == 0.9f, "Long sequence edit failed");
        require (p.setSequence (8, 7, 8, 8) && p.getKit()->pattern[6][200] == 0.9f, "Resolution change did not preserve timing");
        require (! p.setSequence (8, 7, 8, 3), "Fractional triplet meter accepted");
        require (p.setSequence (4, 6, 8, 6) && p.getKit()->stepCount() == 72, "6/8 triplet sequence failed");
        require (p.setSequence (4, 4, 4, 4), "Default signature reset failed"); p.useDefaultGroove();

        auto sample = std::make_shared<DrumSample>(); sample->sampleRate = 48000; sample->audio.setSize (1, 4800); sample->audio.clear(); sample->name = "Test tone";
        for (int n = 0; n < 4800; ++n) sample->audio.setSample (0, n, static_cast<float> (0.25 * std::sin (n * 0.1)));
        DrumKit kit; kit.setLayer (0, 0, sample); kit.setLayer (0, 1, sample);
        LayeredDrumVoice one, two; kit.layerGains[0][1] = 0; one.start (0, 1, kit); kit.layerGains[0][1] = 1; two.start (0, 1, kit);
        for (int n = 0; n < 100; ++n) require (std::abs (two.render (0, 48000, 1)[0] - 2 * one.render (0, 48000, 1)[0]) < 0.00001f, "Sample layers did not sum");
        DrumVoice tuned; tuned.start (sample, 1); for (int n = 0; n < 100; ++n) tuned.render (0, 48000, 2);
        require (std::abs (tuned.cursor - 200) < 0.001, "Octave tuning did not double playback rate");
        const auto sampleFile = folder.getNonexistentChildFile ("OneShot", ".wav", false); saveWav (sampleFile, sample->audio, sample->sampleRate);
        p.loadSample (0, sampleFile, 0); waitSample (p); p.loadSample (0, sampleFile, 1); waitSample (p);
        require (p.getKit()->layer (0, 0) && p.getKit()->layer (0, 1), "WAV stacking load failed");
        p.setLayerGain (0, 1, 0.4f); p.setRootNote (0, 0); p.matchSongKey (0, 7);
        require (p.getKit()->tuning[0] == -5, "Nearest song-key tuning failed");
        p.setTuning (0, 0, 0); p.setAmbience (0.2f, 0.3f);
        p.parameters.getParameter ("run")->setValueNotifyingHost (1); juce::AudioBuffer<float> audio (2, 512); juce::MidiBuffer midi;
        float peak = 0;
        for (int block = 0; block < 120; ++block) { audio.clear(); midi.clear(); p.processBlock (audio, midi); peak = juce::jmax (peak, audio.getMagnitude (0, 512)); }
        require (peak > 0.05f, "Layered groove is silent"); p.stopTogether();
        require (p.setSequence (2, 7, 8, 4), "MIDI test signature failed"); p.setStepVelocity (6, 26, 0.85f); p.setMidiNote (6, 43);
        const auto midiFile = p.createMidiDragFile(); auto input = midiFile.createInputStream(); juce::MidiFile read;
        require (input && read.readFrom (*input) && read.getNumTracks() == 2 && read.getTimeFormat() == 960, "MIDI drag file invalid");
        bool signatureFound = false, customNoteFound = false;
        for (int track = 0; track < read.getNumTracks(); ++track)
            for (int event = 0; event < read.getTrack (track)->getNumEvents(); ++event)
            {
                const auto& m = read.getTrack (track)->getEventPointer (event)->message;
                if (m.isTimeSignatureMetaEvent()) { int n = 0, d = 0; m.getTimeSignatureInfo (n, d); signatureFound = n == 7 && d == 8; }
                if (m.isNoteOn() && m.getNoteNumber() == 43 && m.getTimeStamp() > 6000) customNoteFound = true;
            }
        require (signatureFound && customNoteFound && std::abs (read.getLastTimestamp() - 6720) < 1, "MIDI signature/length/long step is wrong");
        require (p.setSequence (1, 7, 8, 2), "Odd-step signature failed"); p.useDefaultGroove();
        auto* tempo = p.parameters.getParameter ("tempo"); tempo->setValueNotifyingHost (tempo->convertTo0to1 (120));
        auto* swing = p.parameters.getParameter ("swing"); swing->setValueNotifyingHost (swing->convertTo0to1 (0.3f));
        p.parameters.getParameter ("run")->setValueNotifyingHost (1);
        bool correctLoop = false;
        for (int block = 0; block < 170; ++block)
        {
            audio.clear(); midi.clear(); p.processBlock (audio, midi);
            for (const auto event : midi)
                if (event.getMessage().isNoteOn() && event.getMessage().getNoteNumber() == 36)
                    if (std::abs (block * 512 + event.samplePosition - 84000) <= 1) correctLoop = true;
        }
        require (correctLoop, "Swing changed the duration of an odd-step bar");
        p.stopTogether(); swing->setValueNotifyingHost (0);

        // Render input offline into a real 60-second WAV; no sound is sent to a device.
        GuitarEngine guitar; guitar.prepare (48000, 512); guitar.inputChannel.store (1);
        require (! guitar.startRecording (folder.getChildFile ("ShouldNotRecordWet.wav"), true), "Processed recording accepted without NAM");
        const auto take = folder.getNonexistentChildFile ("Guitar_60sec", ".wav", false);
        require (guitar.startRecording (take, false), "Guitar recording start failed");
        juce::AudioBuffer<float> in (2, 512);
        for (int block = 0; block < 5626; ++block)
        {
            in.clear(); for (int n = 0; n < 512; ++n) in.setSample (1, n, static_cast<float> (0.1 * std::sin ((block * 512 + n) * 0.025)));
            guitar.processInput (in, 2);
        }
        require (! guitar.isRecording() && std::abs (guitar.recordedSeconds() - 60) < 0.0001, "Recording did not auto-stop exactly at 60 seconds");
        guitar.finishRecordingIfNeeded(); juce::WavAudioFormat wav;
        auto takeStream = juce::File (guitar.recordingPath()).createInputStream();
        std::unique_ptr<juce::AudioFormatReader> takeReader (wav.createReaderFor (takeStream.release(), true));
        require (takeReader && takeReader->lengthInSamples == 2880000 && takeReader->numChannels == 1 && takeReader->bitsPerSample == 24, "60-second guitar WAV invalid");
        juce::AudioBuffer<float> recorded (1, 512); takeReader->read (&recorded, 0, 512, 0, true, false);
        require (recorded.getMagnitude (0, 512) > 0.08f, "Recording routed the wrong input channel");
        const bool namOk = guitar.loadNamPlugin (juce::File ("C:/Program Files/Common Files/VST3/NeuralAmpModeler.vst3"));
        std::cout << "Installed NAM host test: " << (namOk ? "PASS" : guitar.status().toStdString()) << '\n';
        if (namOk)
        {
            guitar.monitor.store (true); guitar.processInput (in, 2);
            for (int n = 0; n < 512; ++n) require (std::isfinite (guitar.outputAt (n)), "NAM output invalid");
        }

        // Streaming display, onset-following and click timing without opening a device.
        require (guitar.takeWave.snapshot (false).peaks.size() == 6000, "Recorded waveform does not span 60 seconds");
        require (guitar.liveWave.snapshot (true).peaks.size() == 800, "Live waveform does not retain eight seconds");
        AvrxGrooveProcessor follower; follower.prepareToPlay (48000, 512);
        auto* followTempo = follower.parameters.getParameter ("tempo"); followTempo->setValueNotifyingHost (followTempo->convertTo0to1 (120));
        follower.setLiveFollow (true);
        juce::AudioBuffer<float> played (2, 512); juce::MidiBuffer followMidi;
        for (int block = 0; block < 400; ++block)
        {
            played.clear();
            for (int n = 0; n < 512; ++n)
            {
                const int position = (block * 512 + n) % 24000;
                if (position < 5000) played.setSample (0, n, static_cast<float> (0.4 * std::sin (position * 0.028) * std::exp (-position / 1000.0)));
            }
            followMidi.clear(); follower.processBlock (played, followMidi); follower.applyLiveGroove();
        }
        require (follower.liveRhythm.hits.load() >= 7 && follower.getKit()->pattern[0][0] > 0 && follower.getKit()->pattern[1][4] > 0,
                 "Live guitar accents did not create automatic accompaniment");
        require (std::abs (follower.parameters.getRawParameterValue ("tempo")->load() - 120) < 0.01, "Live follow changed selected tempo");
        follower.setLiveFollow (false); follower.stopTogether();
        ClickTrack clickTest; int pulses = 0, lastPulse = -12000; double lastMagnitude = 0;
        for (int n = 0; n < 48000 * 7; ++n)
        {
            const double magnitude = std::abs (clickTest.render (true, 48000, 120, 7, 8, 0.2f));
            if (magnitude > 0.05 && lastMagnitude <= 0.05 && n - lastPulse > 6000) { ++pulses; require (std::abs (n - (pulses - 1) * 12000) < 10, "Metronome timing drifted"); lastPulse = n; }
            lastMagnitude = magnitude;
        }
        require (pulses == 28, "Metronome lost 7/8 eighth-note clicks");
        AvrxGrooveProcessor countIn; countIn.prepareToPlay (48000, 512);
        countIn.parameters.getParameter ("tempo")->setValueNotifyingHost (countIn.parameters.getParameter ("tempo")->convertTo0to1 (120));
        const auto countFile = folder.getNonexistentChildFile ("Preroll", ".wav", false);
        require (countIn.startGuitarTake (countFile, false, 1), "Pre-roll recording did not arm");
        float clickPeak = 0;
        for (int block = 0; block < 190; ++block)
        {
            played.clear();
            for (int n = 0; n < 512; ++n) played.setSample (0, n, block * 512 + n < 96000 ? 0.6f : 0.1f);
            followMidi.clear(); countIn.processBlock (played, followMidi); clickPeak = juce::jmax (clickPeak, played.getMagnitude (0, 512));
        }
        countIn.guitar.stopRecording();
        auto countStream = juce::File (countIn.guitar.recordingPath()).createInputStream();
        std::unique_ptr<juce::AudioFormatReader> countReader (wav.createReaderFor (countStream.release(), true));
        require (countReader && countReader->lengthInSamples == 1280 && clickPeak > 0.1f, "Pre-roll length or forced metronome is wrong");
        juce::AudioBuffer<float> afterCount (1, 1280); countReader->read (&afterCount, 0, 1280, 0, true, false);
        for (int n = 0; n < 1280; ++n) require (std::abs (afterCount.getSample (0, n) - 0.1f) < 0.00001f, "Count-in input or metronome leaked into take");
        require (! countIn.guitar.startRecording (folder.getChildFile ("Off.wav"), true), "Processed validation regressed");
        require (countIn.setSequence (1, 7, 8, 4), "Pre-roll meter setup failed");
        require (countIn.startGuitarTake (folder.getChildFile ("OddMeterCount.wav"), false, 2) && std::abs (countIn.guitar.preRollSeconds() - 3.5) < 0.00001,
                 "Two-bar 7/8 pre-roll duration is wrong");
        countIn.guitar.stopRecording();
        LiveRhythm noSound; noSound.prepare (48000); noSound.enabled.store (true);
        for (int n = 0; n < 48000; ++n) noSound.process (0, 0, n == 0);
        require (noSound.hits.load() == 0, "Silent guitar input created attacks");


        // Crash and ride voices, editable layers and their General MIDI notes.
        require (GrooveGenerator::drumCount == 9 && p.getKit()->notes[7] == 49 && p.getKit()->notes[8] == 51 && p.getKit()->gains[8] == 1,
                 "Cymbal lanes/mapping/default gain incorrect");
        for (int cymbal : { 7, 8 })
        {
            LayeredDrumVoice voice; voice.start (cymbal, 1, *p.getKit()); float cymbalPeak = 0, tail = 0;
            for (int n = 0; n < 24000; ++n) { const auto v = voice.render (cymbal, 48000, 1)[0]; require (std::isfinite (v), "Cymbal synthesis invalid"); cymbalPeak = juce::jmax (cymbalPeak, std::abs (v)); if (n > 18000) tail = juce::jmax (tail, std::abs (v)); }
            require (cymbalPeak > 0.05f && tail > 0.01f, "Crash/ride voice is silent or lacks a tail");
        }
        p.loadSample (8, sampleFile, 3); waitSample (p); require (p.getKit()->layer (8, 3) != nullptr, "Ride sample stacking failed");
        p.setStepVelocity (7, 1, 0.9f); p.setStepVelocity (8, 2, 0.8f);
        const auto cymbalMidi = p.createMidiDragFile(); auto cymbalStream = cymbalMidi.createInputStream(); juce::MidiFile cymbalRead;
        require (cymbalRead.readFrom (*cymbalStream), "Cymbal MIDI invalid"); bool crashNote = false, rideNote = false;
        for (int t = 0; t < cymbalRead.getNumTracks(); ++t)
            for (int n = 0; n < cymbalRead.getTrack (t)->getNumEvents(); ++n)
            { const auto& m = cymbalRead.getTrack (t)->getEventPointer (n)->message; if (m.isNoteOn()) { crashNote |= m.getNoteNumber() == 49; rideNote |= m.getNoteNumber() == 51; } }
        require (crashNote && rideNote, "Crash or ride missing from MIDI drag");

        // Record the actual hosted NAM output and confirm direct file playback.
        if (namOk)
        {
            guitar.outputGain.store (1); guitar.monitor.store (true);
            require (guitar.startRecording (folder.getNonexistentChildFile ("NamPrinted", ".wav", false), true), "NAM-sound recording failed");
            guitar.processInput (in, 2); std::array<float, 512> expected {};
            for (int n = 0; n < 512; ++n) expected[static_cast<size_t> (n)] = guitar.outputAt (n);
            guitar.stopRecording(); auto wetStream = juce::File (guitar.recordingPath()).createInputStream();
            std::unique_ptr<juce::AudioFormatReader> wetReader (wav.createReaderFor (wetStream.release(), true)); juce::AudioBuffer<float> printed (1, 512);
            require (wetReader && wetReader->read (&printed, 0, 512, 0, true, false), "Printed NAM file unreadable");
            for (int n = 0; n < 512; ++n) require (std::abs (printed.getSample (0, n) - expected[static_cast<size_t> (n)]) < 0.000001f, "Recorded NAM sound differs from processed output");
            MultitrackEngine listenBack; listenBack.prepare (48000); require (listenBack.loadFile (-1, juce::File (guitar.recordingPath()), true), "Take playback load failed"); waitRecorder (listenBack);
            listenBack.togglePreview(); listenBack.beginBlock();
            for (int n = 0; n < 512; ++n) require (std::abs (listenBack.render (false)[0] - expected[static_cast<size_t> (n)] * 0.7f) < 0.000001f, "NAM take was changed or reprocessed on playback");
        }
        juce::AudioBuffer<float> constant (1, 96000); constant.clear(); for (int n = 0; n < constant.getNumSamples(); ++n) constant.setSample (0, n, 0.1f);
        const auto constantFile = folder.getNonexistentChildFile ("LaneTest", ".wav", false); saveWav (constantFile, constant, 48000);
        MultitrackEngine mix; mix.prepare (48000);
        for (int n = 0; n < 4; ++n) { require (mix.loadFile (n, constantFile), "Audio lane load rejected"); waitRecorder (mix); mix.strips[static_cast<size_t> (n)].gain.store ((n + 1) * 0.25f); }
        mix.strips[3].start.store (0.05); mix.playing.store (true); mix.beginBlock();
        for (int n = 0; n < 2500; ++n) { const auto v = mix.render (false); require (std::abs (v[0] - (n < 2400 ? 0.15f : 0.25f)) < 0.00001f, "Lane offsets or summed gain are wrong"); }
        mix.strips[1].solo.store (true); mix.strips[1].pan.store (1); mix.beginBlock(); const auto solo = mix.render (false);
        require (std::abs (solo[0]) < 0.00001f && std::abs (solo[1] - 0.05f) < 0.00001f, "Solo/pan mix is wrong");
        mix.strips[1].mute.store (true); mix.beginBlock(); require (std::abs (mix.render (false)[1]) < 0.00001f, "Mute did not silence solo lane");
        const auto beforePause = mix.position.load(); mix.render (true); mix.endBlock(); require (mix.position.load() > beforePause, "Transport position was not published");
        const auto paused = mix.position.load(); mix.beginBlock(); mix.render (true); mix.endBlock(); require (mix.position.load() == paused, "Count-in advanced existing lanes");

        // Overdub after a sample-exact count-in, with backing audio excluded from the WAV.
        require (countIn.setSequence (1, 4, 4, 4), "Overdub meter reset failed");
        for (int d = 0; d < 9; ++d) for (int c = 0; c < 16; ++c) countIn.setStepVelocity (d, c, 0);
        require (countIn.recorder.loadFile (0, constantFile), "Overdub backing load failed"); waitRecorder (countIn.recorder); countIn.recorder.strips[0].gain.store (1);
        countIn.recorder.seek (0.5);
        require (countIn.startMultitrackTake (1, folder.getNonexistentChildFile ("Overdub", ".wav", false), false, 1), "Overdub did not start");
        for (int block = 0; block < 190; ++block)
        {
            for (int n = 0; n < 512; ++n) { played.setSample (0, n, 0.2f); played.setSample (1, n, 0); }
            followMidi.clear(); countIn.processBlock (played, followMidi);
            if (block == 189) require (std::abs (played.getSample (0, 300) - 0.1f) < 0.00001f, "Backing lane did not resume after count-in");
        }
        countIn.toggleTransport (4); waitRecorder (countIn.recorder);
        require (! countIn.guitar.isRecording() && ! countIn.recorder.playing.load(), "Space transport did not stop overdub");
        const auto overdub = countIn.recorder.getClip (1);
        require (overdub && overdub->audio.getNumSamples() == 1280 && countIn.recorder.strips[1].start.load() == 0.5, "Overdub duration/alignment is wrong");
        for (int n = 0; n < 1280; ++n) require (std::abs (overdub->audio.getSample (0, n) - 0.2f) < 0.00001f, "Backing/click leaked into overdub");
        countIn.recorder.seek (0.8);
        require (countIn.startMultitrackTake (1, folder.getNonexistentChildFile ("CancelledCountIn", ".wav", false), false, 1), "Cancelled count-in setup failed"); countIn.stopRecording();
        require (countIn.recorder.recordingLane.load() == -1 && countIn.recorder.getClip (1) == overdub && countIn.recorder.strips[1].start.load() == 0.5,
                 "Cancelling count-in destroyed/muted the prior lane");

        // Drum transport seeks to the same musical timestamp as audio lanes, with swing.
        follower.prepareToPlay (48000, 512); require (follower.setSequence (1, 4, 4, 4), "Transport seek meter failed");
        for (int d = 0; d < 9; ++d) for (int c = 0; c < 16; ++c) follower.setStepVelocity (d, c, 0);
        follower.setStepVelocity (7, 1, 0.9f);
        follower.parameters.getParameter ("swing")->setValueNotifyingHost (follower.parameters.getParameter ("swing")->convertTo0to1 (0.3f));
        follower.seekMultitrack (0.1625); follower.toggleMultitrack(); played.clear(); followMidi.clear(); follower.processBlock (played, followMidi);
        bool alignedSwingHit = false;
        for (const auto e : followMidi) if (e.getMessage().isNoteOn() && e.getMessage().getNoteNumber() == 49 && e.samplePosition == 0) alignedSwingHit = true;
        require (alignedSwingHit, "Audio timeline seek did not align the swung drum hit"); follower.stopTogether();

        // Exercise snapped piano-roll creation, drag, velocity and deletion handlers.
        DrumSequencer roll (p); const auto rowMap = DrumSequencer::lanes (*p.getKit());
        const int cymbalRow = static_cast<int> (std::find (rowMap.begin(), rowMap.end(), 7) - rowMap.begin());
        auto event = [&] (float x, float y, int flags, float downX, float downY)
        { return juce::MouseEvent (juce::Desktop::getInstance().getMainMouseSource(), { x, y }, juce::ModifierKeys (flags), 1, 0, 0, 0, 0, &roll, &roll, juce::Time::getCurrentTime(), { downX, downY }, juce::Time::getCurrentTime(), 1, false); };
        const float y = static_cast<float> (DrumSequencer::top + cymbalRow * DrumSequencer::rowHeight + 5);
        roll.mouseDown (event (3 * DrumSequencer::cellWidth + 5.0f, y, juce::ModifierKeys::leftButtonModifier, 89, y));
        roll.mouseDrag (event (4 * DrumSequencer::cellWidth + 5.0f, y, juce::ModifierKeys::leftButtonModifier, 89, y));
        require (p.getKit()->pattern[7][3] == 0 && p.getKit()->pattern[7][4] > 0, "Piano-roll drag did not move the note");
        roll.mouseDrag (event (4 * DrumSequencer::cellWidth + 5.0f, y - 20, juce::ModifierKeys::leftButtonModifier | juce::ModifierKeys::shiftModifier, 89, y));
        require (p.getKit()->pattern[7][4] > 0.8f, "Piano-roll velocity drag failed");
        roll.mouseDown (event (4 * DrumSequencer::cellWidth + 5.0f, y, juce::ModifierKeys::rightButtonModifier, 117, y));
        require (p.getKit()->pattern[7][4] == 0, "Piano-roll right-click deletion failed");

        require (p.setSequence (4, 4, 4, 4), "Preview reset failed"); p.useDefaultGroove(); p.setStepVelocity (4, 30, 0.85f); p.setStepVelocity (5, 46, 0.75f); p.setStepVelocity (6, 62, 0.9f); p.setStepVelocity (7, 0, 0.9f); for (int c = 0; c < 64; c += 4) p.setStepVelocity (8, c, 0.65f);
        juce::AudioDeviceManager devices;
        bool asioFound = false;
        for (const auto* type : devices.getAvailableDeviceTypes()) if (type->getTypeName().containsIgnoreCase ("ASIO")) asioFound = true;
        require (asioFound, "ASIO backend missing");
        p.setDeviceManager (&devices);
        std::unique_ptr<juce::AudioProcessorEditor> editor (p.createEditor()); snapshot (*editor, folder.getChildFile ("Drums.png"));
        for (int child = 0; child < editor->getNumChildComponents(); ++child)
            if (auto* button = dynamic_cast<juce::TextButton*> (editor->getChildComponent (child)))
                if (button->getButtonText() == "Guitar") button->onClick();
        auto* workstation = dynamic_cast<AvrxGrooveEditor*> (editor.get());
        require (workstation && workstation->isInterestedInFileDrag ({ sampleFile.getFullPathName() }), "Audio drop handler rejected a WAV");
        juce::AudioBuffer<float> reference (1, 48000 * 8); reference.clear();
        for (int start = 12000; start < reference.getNumSamples(); start += 24000)
            for (int n = 0; n < 8000 && start + n < reference.getNumSamples(); ++n)
                reference.setSample (0, start + n, static_cast<float> (0.65 * std::sin (n * 0.012) * std::exp (-n / 1300.0)));
        const auto referenceFile = folder.getNonexistentChildFile ("Reference_120BPM", ".wav", false); saveWav (referenceFile, reference, 48000);
        workstation->filesDropped ({ referenceFile.getFullPathName() }, 50, 250);
        for (int i = 0; i < 1000 && p.isAnalysing(); ++i) std::this_thread::sleep_for (std::chrono::milliseconds (10));
        require (! p.isAnalysing() && p.hasTrack() && ! p.isLoadingSample(), "Hidden drum pads captured a reference drop on Guitar tab");
        require (p.getWaveform() && ! p.getWaveform()->peaks.empty(), "Decoded audio has no visible waveform");
        snapshot (*editor, folder.getChildFile ("Audio.png"));
        auto clickTab = [&] (const juce::String& text)
        {
            for (int n = 0; n < editor->getNumChildComponents(); ++n)
                if (auto* button = dynamic_cast<juce::TextButton*> (editor->getChildComponent (n)))
                    if (button->getButtonText() == text) { button->onClick(); return; }
            throw std::runtime_error ("Missing navigation tab");
        };
        clickTab ("Samples");
        const auto referenceBeforeSampleDrop = p.getWaveform();
        const auto primaryBeforeSampleDrop = p.getKit()->layer (0, 0);
        bool layerChosen = false; WaveformPanel* sampleDisplay = nullptr; WaveformPanel* referenceDisplay = nullptr;
        for (int n = 0; n < editor->getNumChildComponents(); ++n)
        {
            auto* component = editor->getChildComponent (n);
            if (auto* box = dynamic_cast<juce::ComboBox*> (component))
                if (box->getNumItems() == 4 && box->getItemText (0) == "Layer 1") { box->setSelectedId (2, juce::sendNotificationSync); layerChosen = true; }
            if (auto* wave = dynamic_cast<WaveformPanel*> (component))
            { if (wave->getName() == "Sample waveform") sampleDisplay = wave; if (wave->getName() == "Reference waveform") referenceDisplay = wave; }
        }
        require (layerChosen && sampleDisplay && referenceDisplay && sampleDisplay->isVisible() && ! referenceDisplay->isVisible(), "Samples page/waveform navigation failed");
        sampleDisplay->filesDropped ({ referenceFile.getFullPathName() }, 30, 30); waitSample (p);
        require (p.getKit()->layer (0, 1) && p.getKit()->layer (0, 0) == primaryBeforeSampleDrop && p.getWaveform() == referenceBeforeSampleDrop,
                 "Dropping a sample changed reference audio or another layer");
        require (sampleDisplay->waveform() && ! sampleDisplay->waveform()->peaks.empty() && std::abs (sampleDisplay->waveform()->seconds - 8) < 0.001,
                 "Selected sample waveform was not built");
        DrumShaping screenshotStrip; screenshotStrip.eqOn = screenshotStrip.compressorOn = true; screenshotStrip.gainDb = { 2, -3, 1, 2 }; p.setDrumShaping (0, screenshotStrip);
        require (! p.getKit()->shaping[1].eqOn, "Drum shaping leaked to another pad");
        snapshot (*editor, folder.getChildFile ("Samples.png"));
        clickTab ("Drums");
        const auto layerBeforeHomeDrop = p.getKit()->layer (0, 1);
        workstation->filesDropped ({ referenceFile.getFullPathName() }, 50, 200);
        for (int n = 0; n < 1000 && p.isAnalysing(); ++n) std::this_thread::sleep_for (std::chrono::milliseconds (10));
        require (! p.isAnalysing() && referenceDisplay->isVisible() && ! sampleDisplay->isVisible() && p.getKit()->layer (0, 1) == layerBeforeHomeDrop,
                 "Home reference drop switched pages or hit hidden sample controls");
        for (int n = 0; n < editor->getNumChildComponents(); ++n)
            if (auto* pad = dynamic_cast<DrumPad*> (editor->getChildComponent (n))) require (! pad->isVisible(), "Drum sample pad still clutters home page");
        snapshot (*editor, folder.getChildFile ("Drums.png"));

        p.seekTrack (0.03); p.setTrackPlaying (true); audio.clear(); midi.clear(); p.processBlock (audio, midi);
        require (p.trackPositionSeconds() > 0.03 && p.trackPositionSeconds() < 0.05, "Waveform seek failed"); p.stopTogether();
        // Fill the visible guitar display with an offline take before rendering.
        p.guitar.startRecording (folder.getNonexistentChildFile ("PreviewTake", ".wav", false), false);
        for (int block = 0; block < 700; ++block)
        {
            in.clear(); for (int n = 0; n < 512; ++n) in.setSample (0, n, static_cast<float> (0.3 * std::sin ((block * 512 + n) * 0.03) * (0.2 + 0.8 * std::exp (-((block * 512 + n) % 24000) / 4000.0))));
            p.guitar.processInput (in, 2);
        }
        p.guitar.stopRecording();
        for (int child = 0; child < editor->getNumChildComponents(); ++child)
            if (auto* button = dynamic_cast<juce::TextButton*> (editor->getChildComponent (child)))
                if (button->getButtonText() == "Guitar") button->onClick();
        p.serviceRecording(); waitRecorder (p.recorder);
        snapshot (*editor, folder.getChildFile ("Guitar.png"));
        require (workstation->keyPressed (juce::KeyPress (juce::KeyPress::spaceKey), editor.get()) && p.recorder.previewPlaying.load(), "Space did not play latest take");
        workstation->keyPressed (juce::KeyPress (juce::KeyPress::spaceKey), editor.get()); require (p.recorder.previewPlaying.load(), "Held space toggled transport twice");
        workstation->keyStateChanged (false, editor.get()); workstation->keyPressed (juce::KeyPress (juce::KeyPress::spaceKey), editor.get()); require (! p.recorder.previewPlaying.load(), "Second space did not stop take playback");
        workstation->keyStateChanged (false, editor.get());
        for (int lane = 0; lane < 3; ++lane) { p.recorder.loadFile (lane, lane == 0 ? referenceFile : juce::File (p.guitar.recordingPath())); waitRecorder (p.recorder); p.recorder.strips[static_cast<size_t> (lane)].start.store (lane * 8.0); }
        for (int child = 0; child < editor->getNumChildComponents(); ++child)
            if (auto* button = dynamic_cast<juce::TextButton*> (editor->getChildComponent (child)))
                if (button->getButtonText() == "Recorder") button->onClick();
        workstation->filesDropped ({ constantFile.getFullPathName() }, 600, 700); waitRecorder (p.recorder);
        require (p.recorder.getClip (3) != nullptr, "Recorder audio drop did not reach selected lane");
        snapshot (*editor, folder.getChildFile ("Recorder.png"));
        for (int child = 0; child < editor->getNumChildComponents(); ++child)
            if (auto* button = dynamic_cast<juce::TextButton*> (editor->getChildComponent (child)))
                if (button->getButtonText() == "Settings") button->onClick();
        snapshot (*editor, folder.getChildFile ("Settings.png"));
        for (int child = 0; child < editor->getNumChildComponents(); ++child)
            if (auto* button = dynamic_cast<juce::TextButton*> (editor->getChildComponent (child))) if (button->getButtonText() == "Mixer") button->onClick();
        MixerPanel* mixerView = nullptr;
        for (int child = 0; child < editor->getNumChildComponents(); ++child) if (auto* panel = dynamic_cast<MixerPanel*> (editor->getChildComponent (child))) mixerView = panel;
        require (mixerView && mixerView->isVisible(), "Mixer navigation failed");
        bool levelEdited = false;
        for (int child = 0; child < mixerView->getNumChildComponents(); ++child) if (auto* slider = dynamic_cast<juce::Slider*> (mixerView->getChildComponent (child))) if (slider->getTooltip() == "Drum level" && ! levelEdited) { slider->setValue (0.42, juce::sendNotificationSync); levelEdited = true; }
        require (levelEdited && std::abs (p.getKit()->gains[0] - 0.42f) < 1e-5f, "Mixer fader did not update drum level");
        p.stopTogether(); p.recorder.playing.store (false); p.toggleTransport (6);
        require (p.recorder.playing.load() && p.parameters.getRawParameterValue ("run")->load() > 0.5f, "Mixer transport did not start lanes and drums");
        p.toggleTransport (6); require (! p.recorder.playing.load(), "Mixer transport did not stop");
        bool consoleEqEdited = false;
        for (int child = 0; child < mixerView->getNumChildComponents(); ++child) if (auto* slider = dynamic_cast<juce::Slider*> (mixerView->getChildComponent (child))) if (slider->getTooltip() == "Low EQ gain" && ! consoleEqEdited) { slider->setValue (4.5, juce::sendNotificationSync); consoleEqEdited = true; }
        require (consoleEqEdited && std::abs (p.getKit()->shaping[0].gainDb[0] - 4.5f) < 1e-5f, "Console EQ did not update processing settings");
        snapshot (*editor, folder.getChildFile ("Mixer.png"));
        for (int child = 0; child < mixerView->getNumChildComponents(); ++child) if (auto* button = dynamic_cast<juce::TextButton*> (mixerView->getChildComponent (child))) if (button->getButtonText() == "Recorder & buses") button->onClick();
        snapshot (*editor, folder.getChildFile ("MixerBuses.png"));
        clickTab ("Drums"); StudioKitView* kitView = nullptr;
        for (int child = 0; child < editor->getNumChildComponents(); ++child) if (auto* v = dynamic_cast<StudioKitView*> (editor->getChildComponent (child))) kitView = v;
        require (kitView && kitView->isVisible(), "Interactive drum artwork missing");
        const juce::Point<float> kitPoint { kitView->getWidth() * 0.5f, kitView->getHeight() * 0.7f };
        const juce::MouseEvent kitEvent (juce::Desktop::getInstance().getMainMouseSource(), kitPoint, juce::ModifierKeys (juce::ModifierKeys::leftButtonModifier), 1, 0, 0, 0, 0, kitView, kitView, juce::Time::getCurrentTime(), kitPoint, juce::Time::getCurrentTime(), 2, false);
        kitView->mouseDown (kitEvent); kitView->mouseDoubleClick (kitEvent);
        require (sampleDisplay->isVisible() && ! kitView->isVisible(), "Kit double-click did not open selected sound lab");
        clickTab ("Grooves"); GroovePanel* grooveView = nullptr;
        for (int child = 0; child < editor->getNumChildComponents(); ++child) if (auto* panel = dynamic_cast<GroovePanel*> (editor->getChildComponent (child))) grooveView = panel;
        require (grooveView && grooveView->isVisible(), "Groove player navigation failed");
        grooveView->loadFolder (midiLibrary); grooveView->loadFile (grooveFile); require (p.getKit()->numerator == 7 && p.getKit()->bars == 2, "Groove player did not apply MIDI file");
        p.toggleTransport (7); require (p.parameters.getRawParameterValue ("run")->load() > .5f && ! p.recorder.playing.load() && ! p.isTrackPlaying(), "Groove-only playback routing failed"); p.toggleTransport (7);
        snapshot (*editor, folder.getChildFile ("Grooves.png"));
        auto alternateMeter = loadedGroove; alternateMeter.numerator = 2; alternateMeter.denominator = 4; alternateMeter.bars = 4;
        require (p.applyGroove (alternateMeter), "Alternate imported meter rejected"); clickTab ("Drums"); bool shownMeter = false;
        for (int child = 0; child < editor->getNumChildComponents(); ++child) if (auto* box = dynamic_cast<juce::ComboBox*> (editor->getChildComponent (child))) if (box->getText() == "2/4") shownMeter = true;
        require (shownMeter, "Imported non-preset meter was displayed incorrectly");
        clickTab ("Grooves"); grooveView->loadFile (grooveFile);
        auto shortcutStorage = std::make_unique<AvrxGrooveProcessor>(); auto& shortcuts = *shortcutStorage; shortcuts.prepareToPlay (48000, 512); require (shortcuts.setRecordingFolder (takeFolder), "Shortcut recording destination failed");
        std::unique_ptr<juce::AudioProcessorEditor> shortcutEditor (shortcuts.createEditor()); auto* shortcutKeys = dynamic_cast<AvrxGrooveEditor*> (shortcutEditor.get());
        GuitarPanel* guitarUi = nullptr; MultitrackPanel* recorderUi = nullptr;
        for (int n = 0; n < shortcutEditor->getNumChildComponents(); ++n)
        {
            auto* c = shortcutEditor->getChildComponent (n); if (auto* gp = dynamic_cast<GuitarPanel*> (c)) guitarUi = gp; if (auto* rp = dynamic_cast<MultitrackPanel*> (c)) recorderUi = rp;
            if (auto* b = dynamic_cast<juce::TextButton*> (c)) if (b->getButtonText() == "Guitar") b->onClick();
        }
        require (shortcutKeys && guitarUi && recorderUi, "Shortcut UI missing");
        for (int n = 0; n < guitarUi->getNumChildComponents(); ++n) if (auto* box = dynamic_cast<juce::ComboBox*> (guitarUi->getChildComponent (n))) { if (box->getItemText (0) == "Dry DI recording") box->setSelectedId (1); if (box->getItemText (0) == "Pre-roll: Off") box->setSelectedId (1); }
        require (! shortcutKeys->keyPressed (juce::KeyPress ('3'), shortcutEditor.get()) && ! shortcuts.guitar.isRecording(), "Top-row 3 started recording");
        require (shortcutKeys->keyPressed (juce::KeyPress (juce::KeyPress::numberPad3), shortcutEditor.get()) && shortcuts.guitar.isRecording(), "Numpad 3 did not start guitar recording immediately");
        const auto firstShortcut = juce::File (shortcuts.guitar.recordingPath()); require (firstShortcut.getParentDirectory() == takeFolder && firstShortcut.getFileName().startsWith ("Guitar_"), "Shortcut saved to wrong folder");
        shortcutKeys->keyPressed (juce::KeyPress (juce::KeyPress::numberPad3), shortcutEditor.get()); require (shortcuts.guitar.recordingPath() == firstShortcut.getFullPathName(), "Held record key restarted take");
        juce::AudioBuffer<float> shortcutInput (2, 512); shortcutInput.clear(); for (int n = 0; n < 512; ++n) shortcutInput.setSample (0, n, .23f); juce::MidiBuffer shortcutMidi; shortcuts.processBlock (shortcutInput, shortcutMidi);
        shortcutKeys->keyPressed (juce::KeyPress (juce::KeyPress::spaceKey), shortcutEditor.get()); require (! shortcuts.guitar.isRecording() && firstShortcut.existsAsFile(), "Space did not stop/save recording");
        shortcutKeys->keyPressed (juce::KeyPress (juce::KeyPress::numberPad3), shortcutEditor.get()); require (! shortcuts.guitar.isRecording(), "Still-held record key started another take after Space");
        waitRecorder (shortcuts.recorder); shortcutKeys->keyStateChanged (false, shortcutEditor.get());
        for (int n = 0; n < shortcutEditor->getNumChildComponents(); ++n) if (auto* b = dynamic_cast<juce::TextButton*> (shortcutEditor->getChildComponent (n))) if (b->getButtonText() == "Recorder") b->onClick();
        for (int n = 0; n < recorderUi->getNumChildComponents(); ++n)
        {
            auto* c = recorderUi->getChildComponent (n); if (auto* box = dynamic_cast<juce::ComboBox*> (c)) { if (box->getItemText (1) == "Dry DI") box->setSelectedId (2); if (box->getItemText (0) == "Count-in: Off") box->setSelectedId (1); }
            if (auto* arm = dynamic_cast<juce::ToggleButton*> (c)) if (arm->getButtonText() == "Arm 3") arm->onClick();
        }
        shortcutKeys->keyPressed (juce::KeyPress (juce::KeyPress::numberPad3), shortcutEditor.get()); require (shortcuts.guitar.isRecording() && shortcuts.recorder.recordingLane.load() == 2, "Numpad did not record the armed lane");
        const auto laneShortcut = juce::File (shortcuts.guitar.recordingPath()); require (laneShortcut.getParentDirectory() == takeFolder && laneShortcut != firstShortcut && laneShortcut.getFileName().startsWith ("Track3_"), "Recorder take naming/destination failed");
        shortcutInput.clear(); for (int n = 0; n < 512; ++n) shortcutInput.setSample (0, n, .31f); shortcutMidi.clear(); shortcuts.processBlock (shortcutInput, shortcutMidi);
        shortcutKeys->keyPressed (juce::KeyPress (juce::KeyPress::spaceKey), shortcutEditor.get()); waitRecorder (shortcuts.recorder); require (! shortcuts.guitar.isRecording() && shortcuts.recorder.getClip (2) != nullptr, "Space failed to stop/import armed lane take");
        std::cout << "Numpad recording, held-key suppression, Space stop, armed-lane routing and groove player UI passed\n";

        auto presetOriginal = std::make_unique<AvrxGrooveProcessor>();
        require (presetOriginal->setSequence (7, 7, 8, 8), "Preset sequence fixture failed");
        for (int drum = 0; drum < GrooveGenerator::drumCount; ++drum)
        {
            presetOriginal->setPadGain (drum, .35f + .08f * drum); presetOriginal->setPadPan (drum, -.8f + .18f * drum);
            presetOriginal->setPadMuted (drum, drum == 4); presetOriginal->setPadSolo (drum, drum == 8);
            presetOriginal->setMidiNote (drum, 51 + drum); presetOriginal->setRootNote (drum, drum); presetOriginal->setTuning (drum, static_cast<float> (-6 + drum), static_cast<float> (13 + drum));
            DrumShaping shape; shape.eqOn = shape.compressorOn = shape.highPassOn = shape.lowBell = shape.highBell = true;
            shape.gainDb = { 3, -4, 5, -2 }; shape.frequency = { 65, 750, 1900, 9500 }; shape.q = { .8f, 1.2f, 2, .9f };
            shape.compressorMix = .73f; shape.attackMs = .4f; shape.releaseMs = 250; shape.ratio = 12;
            presetOriginal->setDrumShaping (drum, shape); presetOriginal->setStepVelocity (drum, 89 + drum, .66f);
        }
        for (int slot = 0; slot < 4; ++slot) { presetOriginal->loadSample (0, sampleFile, slot); waitSample (*presetOriginal); presetOriginal->setLayerGain (0, slot, .4f + .2f * slot); }
        presetOriginal->setAmbience (.37f, .63f); presetOriginal->setMidiChannel (10);
        presetOriginal->parameters.getParameter ("tempo")->setValueNotifyingHost (presetOriginal->parameters.getParameter ("tempo")->convertTo0to1 (143));
        presetOriginal->parameters.getParameter ("swing")->setValueNotifyingHost (.4f);
        presetOriginal->parameters.getParameter ("run")->setValueNotifyingHost (1);
        presetOriginal->guitar.inputChannel.store (1); presetOriginal->guitar.inputGain.store (1.23f); presetOriginal->guitar.outputGain.store (.84f);
        presetOriginal->setDetectionStrength (2.2f); presetOriginal->metronome.store (true);
        for (int track = 0; track < 4; ++track)
        {
            presetOriginal->recorder.loadFile (track, firstShortcut, true); presetOriginal->recorder.waitForLoad();
            auto& strip = presetOriginal->recorder.strips[static_cast<size_t> (track)]; strip.start.store (track * 1.25); strip.gain.store (.5f + .1f * track); strip.pan.store (.15f * track); strip.solo.store (track == 2); strip.mute.store (track == 1);
        }
        presetOriginal->loadAndAnalyse (sampleFile, false); presetOriginal->waitForBackgroundWork();
        presetOriginal->recorder.loadFile (-1, firstShortcut, true); presetOriginal->recorder.waitForLoad();
        presetOriginal->guitarRecordMode.store (1); presetOriginal->guitarCountIn.store (2); presetOriginal->armedTrack.store (3);
        const auto presetFile = folder.getChildFile ("presets/Complete.avrxpreset");
        require (presetOriginal->savePreset (presetFile), "Preset save failed");
        auto presetReload = std::make_unique<AvrxGrooveProcessor>(); require (presetReload->loadPreset (presetFile), "Preset restore failed");
        require (presetReload->hasTrack() && presetReload->recorder.getPreview() && presetReload->recorder.getPreview()->namPrinted && presetReload->guitarRecordMode.load() == 1 && presetReload->guitarCountIn.load() == 2 && presetReload->armedTrack.load() == 3, "Reference / last take / record settings lost");
        const auto originalKit = presetOriginal->getKit(), restoredKit = presetReload->getKit();
        require (originalKit->pattern == restoredKit->pattern && originalKit->shaping == restoredKit->shaping && originalKit->gains == restoredKit->gains && originalKit->pan == restoredKit->pan && originalKit->muted == restoredKit->muted && originalKit->solo == restoredKit->solo, "Kit pattern / mixer / shaping did not round trip");
        require (originalKit->layerGains == restoredKit->layerGains && originalKit->tuning == restoredKit->tuning && originalKit->fineTuning == restoredKit->fineTuning && originalKit->rootNotes == restoredKit->rootNotes && originalKit->notes == restoredKit->notes, "Layer / tuning / mapping did not round trip");
        require (restoredKit->bars == 7 && restoredKit->numerator == 7 && restoredKit->denominator == 8 && restoredKit->division == 8 && restoredKit->midiChannel == 10 && restoredKit->roomLevel == .37f && restoredKit->overheadLevel == .63f, "Meter / bus state lost");
        for (int slot = 0; slot < 4; ++slot) require (restoredKit->layer (0, slot) && restoredKit->layer (0, slot)->sourceFile == sampleFile && restoredKit->layer (0, slot)->audio.getSample (0, 2) == originalKit->layer (0, slot)->audio.getSample (0, 2), "Sample layer audio was not restored");
        for (int track = 0; track < 4; ++track)
        {
            const auto& strip = presetReload->recorder.strips[static_cast<size_t> (track)];
            require (presetReload->recorder.getClip (track) && presetReload->recorder.getClip (track)->file == firstShortcut && presetReload->recorder.getClip (track)->namPrinted && strip.start.load() == track * 1.25 && strip.gain.load() == .5f + .1f * track && strip.pan.load() == .15f * track && strip.solo.load() == (track == 2) && strip.mute.load() == (track == 1), "Recorder lane / offset / mixer state was not restored");
        }
        require (presetReload->parameters.getRawParameterValue ("tempo")->load() == 143 && presetReload->parameters.getRawParameterValue ("run")->load() == 0 && ! presetReload->guitar.monitor.load() && ! presetReload->recorder.playing.load(), "Preset tempo / stopped startup failed");
        require (presetReload->guitar.inputChannel.load() == 1 && presetReload->guitar.inputGain.load() == 1.23f && presetReload->metronome.load() && presetReload->detectionStrength.load() == 2.2f, "Input / analysis controls were not restored");
        auto malformed = folder.getChildFile ("Invalid.avrxpreset"); malformed.replaceWithText ("<AVRX_PRESET version='999'><Kit/></AVRX_PRESET>");
        require (! presetReload->loadPreset (malformed) && presetReload->getKit() == restoredKit, "Invalid preset changed the current kit");
        auto missingXml = juce::XmlDocument::parse (presetFile); auto* missingLayer = missingXml->getChildByName ("Kit")->getChildByName ("Pad")->getChildByName ("Layer");
        const auto missingPath = folder.getChildFile ("MissingSample.wav"); missingLayer->setAttribute ("file", missingPath.getFullPathName()); missingXml->writeTo (malformed);
        require (presetReload->loadPreset (malformed) && ! presetReload->getKit()->layer (0, 0) && presetReload->getKit()->layer (0, 1) && presetReload->presetStatus.contains ("1 missing"), "Missing sample handling failed");
        require (presetReload->savePreset (folder.getChildFile ("last-session.avrxpreset")), "Last session save failed");
        auto lastSession = std::make_unique<AvrxGrooveProcessor>(); require (lastSession->loadPreset (folder.getChildFile ("last-session.avrxpreset")) && lastSession->getKit()->layerFiles[0][0] == missingPath, "Missing file reference was lost on autosave");
        std::unique_ptr<juce::AudioProcessorEditor> presetEditor (lastSession->createEditor());
        int presetButtons = 0; for (int n = 0; n < presetEditor->getNumChildComponents(); ++n) if (auto* button = dynamic_cast<juce::TextButton*> (presetEditor->getChildComponent (n))) if (button->getButtonText().contains ("preset")) { require (button->isVisible() && button->getY() == 10 && button->getRight() <= 1280, "Preset header button layout failed"); ++presetButtons; }
        require (presetButtons == 2, "Save / Load preset buttons missing");
        std::cout << "Preset full-kit / layered-WAV / shaping / sequence / track round trip, invalid/missing files, last-session restore and header controls passed\n";

        const auto packsRoot = juce::File::getCurrentWorkingDirectory().getChildFile ("outputs/AVRX_GROOVE/Drum Packs");
        auto packProcessor = std::make_unique<AvrxGrooveProcessor>(); packProcessor->packFolder = packsRoot;
        require (packProcessor->loadDrumPack (packsRoot.getChildFile ("Chango Luke Holland/kit.avrxpack")), "Pack load did not start"); packProcessor->waitForBackgroundWork();
        auto loadedPack = packProcessor->getKit(); require (loadedPack->packName == "Chango Luke Holland", "Luke Holland pack failed to load");
        require (loadedPack->velocityGroups[0].size() == 3 && loadedPack->velocityGroups[1].size() == 4 && loadedPack->velocityGroups[0][0].takes.size() == 4 && loadedPack->tuning[5] == -5, "Luke velocity groups / alternates / second tom mapping failed");
        LayeredDrumVoice dynamicVoice; dynamicVoice.start (0, .2f, *loadedPack); const auto soft = dynamicVoice.layers[0].sample;
        require (soft->name.contains ("Soft"), "Quiet hit selected hard sample"); dynamicVoice.start (0, .6f, *loadedPack); require (dynamicVoice.layers[0].sample->name.contains ("Med"), "Medium hit selected wrong layer");
        dynamicVoice.start (0, .95f, *loadedPack); require (dynamicVoice.layers[0].sample->name.contains ("Hard"), "Accent selected wrong layer");
        dynamicVoice.start (0, .2f, *loadedPack); require (dynamicVoice.layers[0].sample != soft, "Round-robin repeated the first take");
        packProcessor->setHumanFeel (.7f, 18); const auto packPreset = folder.getChildFile ("PortablePack.avrxpreset"); require (packProcessor->savePreset (packPreset), "Pack preset save failed");
        require (packPreset.loadFileAsString().contains ("@pack/") && ! packPreset.loadFileAsString().contains (packsRoot.getFullPathName()), "Pack preset contains absolute bundle paths");
        const auto relocated = folder.getChildFile ("RelocatedDrumPacks");
        for (const auto& groups : loadedPack->velocityGroups) for (const auto& group : groups) for (const auto& take : group.takes)
        { const auto target = relocated.getChildFile (take->sourceFile.getRelativePathFrom (packsRoot)); require (target.getParentDirectory().createDirectory().wasOk(), "Relocated fixture folder failed"); if (! target.existsAsFile()) require (take->sourceFile.copyFileTo (target), "Relocated sample copy failed"); }
        auto relocatedProcessor = std::make_unique<AvrxGrooveProcessor>(); relocatedProcessor->packFolder = relocated;
        require (relocatedProcessor->loadPreset (packPreset) && relocatedProcessor->getKit()->velocityGroups[0].size() == 3 && relocatedProcessor->getKit()->velocityGroups[0][0].takes[0]->sourceFile.isAChildOf (relocated) && relocatedProcessor->getKit()->humanAmount == .7f && relocatedProcessor->getKit()->humanTimingMs == 18, "Relocated pack / human-feel preset restore failed");
        require (packProcessor->loadDrumPack (packsRoot.getChildFile ("Time Traveller/kit.avrxpack")), "Second pack load did not start"); packProcessor->waitForBackgroundWork();
        require (packProcessor->getKit()->packName == "Time Traveller" && packProcessor->getKit()->velocityGroups[0].size() == 4 && packProcessor->getKit()->velocityGroups[6].size() == 4 && packProcessor->getKit()->velocityGroups[8][0].takes.size() == 4, "Time Traveller mappings failed");
        const auto beforeBadPack = packProcessor->getKit(); auto badPack = folder.getChildFile ("Bad.avrxpack"); badPack.replaceWithText ("<AVRX_PACK version='1'><Pad index='0'><Velocity upper='1'><Take file='Missing.wav'/></Velocity></Pad></AVRX_PACK>");
        require (packProcessor->loadDrumPack (badPack), "Bad pack fixture did not start"); packProcessor->waitForBackgroundWork(); require (packProcessor->getKit() == beforeBadPack, "Failed pack partially overwrote the kit");
        packProcessor->prepareToPlay (48000, 256); packProcessor->setSequence (1, 4, 4, 4);
        for (int d = 0; d < 9; ++d) for (int cell = 0; cell < 16; ++cell) packProcessor->setStepVelocity (d, cell, 0);
        packProcessor->setStepVelocity (0, 0, .8f); packProcessor->setHumanFeel (.7f, 18);
        packProcessor->parameters.getParameter ("tempo")->setValueNotifyingHost (packProcessor->parameters.getParameter ("tempo")->convertTo0to1 (120));
        const auto expectedFeel = HumanFeel::hit (.8f, 0, 0, 16, 4, .7f, 18, 137, 120, 0);
        const int expectedFrame = static_cast<int> (std::llround (expectedFeel.delaySeconds * 48000));
        packProcessor->parameters.getParameter ("run")->setValueNotifyingHost (1); int firstFeelFrame = -1; float firstFeelVelocity = 0;
        for (int offset = 0; offset < 2048; offset += 256)
        { juce::AudioBuffer<float> block (2, 256); block.clear(); juce::MidiBuffer midi; packProcessor->processBlock (block, midi); for (const auto metadata : midi) if (metadata.getMessage().isNoteOn() && firstFeelFrame < 0) { firstFeelFrame = offset + metadata.samplePosition; firstFeelVelocity = metadata.getMessage().getFloatVelocity(); } }
        require (firstFeelFrame == expectedFrame && std::abs (firstFeelVelocity - expectedFeel.velocity) < .01f, "Live human timing / velocity differs from model");
        const auto feelMidi = folder.getNonexistentChildFile ("HumanFeel", ".mid", false); MidiDrag::write (*packProcessor->getKit(), 120, 0, feelMidi);
        juce::MidiFile humanMidi; auto humanStream = feelMidi.createInputStream(); require (humanStream && humanMidi.readFrom (*humanStream), "Human MIDI export failed"); bool foundFeel = false;
        for (int event = 0; event < humanMidi.getTrack (1)->getNumEvents(); ++event) { const auto& message = humanMidi.getTrack (1)->getEventPointer (event)->message; if (message.isNoteOn()) { require (std::abs (message.getTimeStamp() - expectedFeel.delaySeconds * 2 * 960) < 1.1 && std::abs (message.getFloatVelocity() - expectedFeel.velocity) < .01f, "MIDI drag-out does not retain human feel"); foundFeel = true; } }
        require (foundFeel, "Human MIDI had no note");
        const auto straight = HumanFeel::hit (.8f, 0, 0, 16, 4, 0, 25, 137, 300, .45); require (straight.velocity == .8f && straight.delaySeconds == 0, "Zero feel changed exact groove");
        float mean = 0, squares = 0; for (int cell = 0; cell < 2000; ++cell) { const auto h = HumanFeel::hit (.7f, 2, cell, 16, 8, 1, 25, 137, 300, .45); require (h.velocity >= .02f && h.velocity <= 1 && h.delaySeconds >= 0 && h.delaySeconds <= (60.0 / 300 / 8 * .55 * .3), "Human variation exceeded bounds"); mean += h.velocity; squares += h.velocity * h.velocity; }
        mean /= 2000; require (mean > .6f && mean < .8f && squares / 2000 - mean * mean > .0005f, "Human variation distribution is degenerate");
        packProcessor->loadDrumPack (packsRoot.getChildFile ("Time Traveller/kit.avrxpack")); packProcessor->waitForBackgroundWork();
        std::unique_ptr<juce::AudioProcessorEditor> packEditor (packProcessor->createEditor()); bool packMenuFound = false;
        for (int n = 0; n < packEditor->getNumChildComponents(); ++n) if (auto* combo = dynamic_cast<juce::ComboBox*> (packEditor->getChildComponent (n))) if (combo->getItemText (0) == "Built-in drums") { require (combo->getNumItems() == 3, "Bundled pack selector items missing"); packMenuFound = true; }
        require (packMenuFound, "Pack selector missing");
        for (int n = 0; n < packEditor->getNumChildComponents(); ++n) if (auto* button = dynamic_cast<juce::TextButton*> (packEditor->getChildComponent (n))) if (button->getButtonText() == "Samples") button->onClick();
        snapshot (*packEditor, folder.getChildFile ("DrumPacks.png"));
        for (int n = 0; n < packEditor->getNumChildComponents(); ++n) if (auto* button = dynamic_cast<juce::TextButton*> (packEditor->getChildComponent (n))) if (button->getButtonText() == "Grooves") button->onClick();
        snapshot (*packEditor, folder.getChildFile ("HumanFeel.png"));
        packProcessor->useBuiltInKit(); require (packProcessor->getKit()->velocityGroups[0].empty() && ! packProcessor->getKit()->samples[0] && packProcessor->getKit()->humanAmount == .7f, "Built-in kit switch failed / changed feel");
        std::cout << "Both real packs, dynamic layer selection, round robin, portable bank presets, failed-pack rollback, bounded human feel, exact live/MIDI offsets and pack UI passed\n";

        const auto nativeFixture = folder.getChildFile ("Test Capture ü.nam");
        nativeFixture.replaceWithText (R"({"version":"0.5.4","architecture":"Linear","sample_rate":48000,"config":{"receptive_field":1,"bias":false},"weights":[0.5]})");
        auto nativeProcessor = std::make_unique<AvrxGrooveProcessor>(); nativeProcessor->prepareToPlay (48000, 512);
        require (nativeProcessor->guitar.loadCapture (nativeFixture) && nativeProcessor->guitar.hasAmp() && nativeProcessor->guitar.getNam() == nullptr && nativeProcessor->guitar.captureFile() == nativeFixture, "Direct capture load failed / needed VST3");
        nativeProcessor->guitar.monitor.store (true); nativeProcessor->guitar.outputGain.store (1);
        juce::AudioBuffer<float> nativeInput (2, 512); nativeInput.clear(); for (int n = 0; n < 512; ++n) nativeInput.setSample (0, n, .4f);
        nativeProcessor->guitar.processInput (nativeInput, 2); require (std::abs (nativeProcessor->guitar.outputAt (100) - .2f) < .00001f, "Direct NAM did not process input correctly");
        nativeProcessor->guitar.bypassNam.store (true); nativeProcessor->guitar.processInput (nativeInput, 2); require (std::abs (nativeProcessor->guitar.outputAt (100) - .4f) < .00001f, "Direct NAM bypass failed");
        nativeProcessor->guitar.bypassNam.store (false); auto badCapture = folder.getChildFile ("Invalid.nam"); badCapture.replaceWithText ("{invalid");
        require (! nativeProcessor->guitar.loadCapture (badCapture) && nativeProcessor->guitar.captureFile() == nativeFixture && nativeProcessor->guitar.hasAmp(), "Invalid capture replaced working amp");
        const auto neuralExamples = juce::File::getCurrentWorkingDirectory().getChildFile ("outputs/AVRX_GROOVE/ThirdParty/NAMCore/example_models");
        for (const auto* name : { "lstm.nam", "wavenet.nam", "slimmable_wavenet.nam", "A2.nam" })
        {
            require (nativeProcessor->guitar.loadCapture (neuralExamples.getChildFile (name)), "Neural architecture example failed to load");
            nativeProcessor->guitar.processInput (nativeInput, 2); for (int n = 0; n < 512; ++n) require (std::isfinite (nativeProcessor->guitar.outputAt (n)), "Neural example produced invalid audio");
        }
        nativeProcessor->prepareToPlay (44100, 512); require (! nativeProcessor->guitar.hasAmp(), "Rate change kept fixed-rate neural amp enabled");
        require (! nativeProcessor->guitar.startRecording (folder.getChildFile ("WrongRate.wav"), true), "Wrong-rate NAM allowed processed recording");
        require (! nativeProcessor->guitar.loadCapture (neuralExamples.getChildFile ("wavenet.nam")), "Mismatched-rate capture was accepted");
        nativeProcessor->prepareToPlay (48000, 512); require (nativeProcessor->guitar.hasAmp(), "Matching rate did not re-enable capture");
        require (nativeProcessor->guitar.loadCapture (nativeFixture), "Linear capture reload failed"); nativeProcessor->guitar.monitor.store (false);
        const auto nativeTake = folder.getNonexistentChildFile ("DirectNAMTake", ".wav", false);
        require (nativeProcessor->startGuitarTake (nativeTake, true, 0), "Direct NAM processed recording failed to start");
        require (! nativeProcessor->guitar.loadCapture (badCapture), "Capture changed during recording");
        juce::MidiBuffer nativeMidi; nativeProcessor->processBlock (nativeInput, nativeMidi); nativeProcessor->stopRecording(); nativeProcessor->recorder.waitForLoad();
        const auto printed = nativeProcessor->recorder.getPreview(); require (printed && printed->namPrinted && printed->audio.getNumSamples() == 512 && std::abs (printed->audio.getSample (0, 100) - .2f) < .00001f, "Direct NAM take did not print wet audio without monitoring");
        nativeProcessor->guitar.clearCapture(); require (! nativeProcessor->guitar.hasAmp() && printed->audio.getSample (0, 100) > .19f, "Printed playback lost NAM sound after unloading capture");
        require (nativeProcessor->guitar.loadCapture (nativeFixture), "Preset capture fixture reload failed");
        const auto nativePreset = folder.getChildFile ("NativeAmp.avrxpreset"); require (nativeProcessor->savePreset (nativePreset), "Native amp preset save failed");
        auto recalledAmp = std::make_unique<AvrxGrooveProcessor>(); recalledAmp->prepareToPlay (48000, 512); require (recalledAmp->loadPreset (nativePreset) && recalledAmp->guitar.hasAmp() && recalledAmp->guitar.captureFile() == nativeFixture && ! recalledAmp->guitar.monitor.load(), "Capture preset / stopped recall failed");
        std::unique_ptr<juce::AudioProcessorEditor> nativeEditor (recalledAmp->createEditor()); auto* nativeKeys = dynamic_cast<AvrxGrooveEditor*> (nativeEditor.get());
        nativeKeys->filesDropped ({ nativeFixture.getFullPathName() }, 0, 0); require (recalledAmp->guitar.captureFile() == nativeFixture, "Capture drag-drop failed"); snapshot (*nativeEditor, folder.getChildFile ("DirectNAM.png"));
        std::cout << "Direct NAM Linear/LSTM/WaveNet/slimmable examples, Unicode paths, bypass, invalid capture retention, device-rate guarding/recovery, wet recording without monitor, printed playback, preset recall and drag-drop passed\n";

        const auto capturesRoot = juce::File::getCurrentWorkingDirectory().getChildFile ("outputs/AVRX_GROOVE/Captures");
        const auto mesaCapture = capturesRoot.getChildFile ("90sDualRec-FullRig-Red-Modn-SweetSpot+808.nam");
        auto mesaProcessor = std::make_unique<AvrxGrooveProcessor>(); mesaProcessor->captureFolder = capturesRoot; mesaProcessor->prepareToPlay (44100, 512);
        require (mesaProcessor->guitar.loadCapture (mesaCapture, true) && mesaProcessor->guitar.captureFile() == mesaCapture && ! mesaProcessor->guitar.hasAmp(), "Default Mesa rate-pending selection failed");
        mesaProcessor->prepareToPlay (48000, 512); mesaProcessor->guitar.monitor.store (true); mesaProcessor->guitar.outputGain.store (1);
        require (mesaProcessor->guitar.hasAmp() && mesaProcessor->guitar.status().contains ("Ready at 48000"), "Mesa capture did not recover at 48k");
        juce::AudioBuffer<float> mesaInput (2, 512); float mesaPeak = 0;
        const auto benchmarkStart = juce::Time::getMillisecondCounterHiRes();
        for (int block = 0; block < 24; ++block) { mesaInput.clear(); for (int n = 0; n < 512; ++n) mesaInput.setSample (0, n, .02f * std::sin (juce::MathConstants<float>::twoPi * 110 * (n + block * 512) / 48000)); mesaProcessor->guitar.processInput (mesaInput, 2); for (int n = 0; n < 512; ++n) { const float sampleValue = mesaProcessor->guitar.outputAt (n); require (std::isfinite (sampleValue), "Mesa model returned non-finite audio"); mesaPeak = juce::jmax (mesaPeak, std::abs (sampleValue)); } }
        const double meanMesaMs = (juce::Time::getMillisecondCounterHiRes() - benchmarkStart) / 24;
        require (mesaPeak > .001f, "Mesa model output was silent");
        const auto mesaPreset = folder.getChildFile ("DefaultMesa.avrxpreset"); require (mesaProcessor->savePreset (mesaPreset) && mesaPreset.loadFileAsString().contains ("@capture/90sDualRec"), "Default capture portable preset path failed");
        const auto movedCaptures = folder.getChildFile ("RelocatedCaptures"); require (movedCaptures.createDirectory().wasOk(), "Capture relocation fixture directory failed"); const auto movedMesa = movedCaptures.getChildFile (mesaCapture.getFileName()); if (! movedMesa.existsAsFile()) require (mesaCapture.copyFileTo (movedMesa), "Capture relocation copy failed");
        auto mesaRecall = std::make_unique<AvrxGrooveProcessor>(); mesaRecall->captureFolder = movedCaptures; mesaRecall->prepareToPlay (48000, 512);
        require (mesaRecall->loadPreset (mesaPreset) && mesaRecall->guitar.captureFile() == movedMesa && mesaRecall->guitar.hasAmp() && ! mesaRecall->guitar.monitor.load(), "Portable Mesa preset recall failed");
        std::unique_ptr<juce::AudioProcessorEditor> mesaEditor (mesaRecall->createEditor()); auto* mesaKeys = dynamic_cast<AvrxGrooveEditor*> (mesaEditor.get()); mesaKeys->filesDropped ({ movedMesa.getFullPathName() }, 0, 0); snapshot (*mesaEditor, folder.getChildFile ("DefaultMesa.png"));
        std::cout << "Supplied Mesa SweetSpot+808 default processed audio; peak=" << mesaPeak << "; mean 512-frame block=" << meanMesaMs << " ms (budget 10.67 ms). Pending-rate selection/recovery and portable capture recall passed\n";

        auto controlsProcessor = std::make_unique<AvrxGrooveProcessor>(); controlsProcessor->prepareToPlay (48000, 512); require (controlsProcessor->guitar.loadCapture (nativeFixture), "Amp control fixture failed");
        auto& controlsGuitar = controlsProcessor->guitar; controlsGuitar.monitor.store (true); controlsGuitar.outputGain.store (1); controlsGuitar.ampDriveDb.store (6.0206f);
        juce::AudioBuffer<float> controlInput (2, 512); controlInput.clear(); for (int n = 0; n < 512; ++n) controlInput.setSample (0, n, .2f);
        for (int block = 0; block < 20; ++block) controlsGuitar.processInput (controlInput, 2);
        require (std::abs (controlsGuitar.outputAt (400) - .2f) < .0001f, "Amp Drive failed to change input to capture");
        controlsGuitar.ampOutputDb.store (-6.0206f); for (int block = 0; block < 20; ++block) controlsGuitar.processInput (controlInput, 2);
        require (std::abs (controlsGuitar.outputAt (400) - .1f) < .0001f, "Amp Output failed to affect processed signal");
        controlsGuitar.ampDriveDb.store (0); controlsGuitar.ampOutputDb.store (0); controlsGuitar.bassDb.store (6); float bassMagnitude = 0;
        for (int block = 0; block < 50; ++block) { for (int n = 0; n < 512; ++n) controlInput.setSample (0, n, .1f * std::sin (juce::MathConstants<float>::twoPi * 40 * (n + block * 512) / 48000)); controlsGuitar.processInput (controlInput, 2); if (block > 40) for (int n = 0; n < 512; ++n) bassMagnitude = juce::jmax (bassMagnitude, std::abs (controlsGuitar.outputAt (n))); }
        require (bassMagnitude > .08f, "Bass shelf did not boost low frequency"); controlsGuitar.bassDb.store (0);
        controlsGuitar.gateOn.store (true); controlsGuitar.gateThresholdDb.store (-40); controlsGuitar.gateReleaseMs.store (50);
        for (int n = 0; n < 512; ++n) controlInput.setSample (0, n, .001f); for (int block = 0; block < 80; ++block) controlsGuitar.processInput (controlInput, 2);
        require (controlsGuitar.gateGainDisplay.load() < .001f && std::abs (controlsGuitar.outputAt (400)) < .000001f && std::abs (controlsGuitar.dryAt (400) - .001f) < .000001f, "Gate did not mute quiet NAM / altered Dry DI");
        for (int n = 0; n < 512; ++n) controlInput.setSample (0, n, .1f); for (int block = 0; block < 5; ++block) controlsGuitar.processInput (controlInput, 2); require (controlsGuitar.gateGainDisplay.load() > .99f && controlsGuitar.outputAt (400) > .049f, "Gate did not reopen for played notes");
        controlsGuitar.gateOn.store (false);
        controlsGuitar.ampDriveDb.store (6.0206f); controlsGuitar.ampOutputDb.store (-6.0206f); for (int block = 0; block < 30; ++block) controlsGuitar.processInput (controlInput, 2);
        controlsGuitar.monitor.store (false); const auto controlledTake = folder.getNonexistentChildFile ("ControlledNAM", ".wav", false);
        require (controlsGuitar.startRecording (controlledTake, true), "Controlled amp recording failed"); controlsGuitar.processInput (controlInput, 2); controlsGuitar.stopRecording();
        juce::WavAudioFormat controlledFormat; auto controlledStream = controlledTake.createInputStream(); std::unique_ptr<juce::AudioFormatReader> controlledReader (controlledStream ? controlledFormat.createReaderFor (controlledStream.release(), true) : nullptr); juce::AudioBuffer<float> controlledAudio (1, 512);
        require (controlledReader && controlledReader->read (&controlledAudio, 0, 512, 0, true, false) && std::abs (controlledAudio.getSample (0, 400) - .05f) < .00002f, "Drive / output controls were not printed into NAM recording");
        controlsGuitar.ampDriveDb.store (0); controlsGuitar.ampOutputDb.store (0);

        for (int profile = 1; profile <= 3; ++profile)
        {
            controlsGuitar.setPickupConfiguration (profile); for (int n = 0; n < 512; ++n) controlInput.setSample (0, n, .04f);
            for (int block = 0; block < 470; ++block) controlsGuitar.processInput (controlInput, 2); controlsGuitar.serviceInputCalibration();
            require (! controlsGuitar.calibrating.load() && std::abs (controlsGuitar.inputGain.load() - .0630957f / .04f) < .001f, "Automatic measured input gain failed");
        }
        controlsGuitar.calibrateInput(); controlsGuitar.setManualInputGain (.75f); for (int block = 0; block < 4; ++block) controlsGuitar.processInput (controlInput, 2); require (! controlsGuitar.calibrating.load() && controlsGuitar.pickupConfiguration.load() == 0 && controlsGuitar.inputGain.load() == .75f, "Manual trim did not override automatic mode");
        controlsGuitar.setPickupConfiguration (1); controlInput.clear(); for (int block = 0; block < 470; ++block) controlsGuitar.processInput (controlInput, 2); controlsGuitar.serviceInputCalibration(); require (controlsGuitar.inputGain.load() == .75f && controlsGuitar.status().contains ("Not enough"), "Silent calibration changed gain");
        controlsGuitar.ampDriveDb.store (4); controlsGuitar.ampOutputDb.store (-3); controlsGuitar.bassDb.store (2); controlsGuitar.midDb.store (-5); controlsGuitar.trebleDb.store (3); controlsGuitar.gateOn.store (true); controlsGuitar.gateThresholdDb.store (-51); controlsGuitar.gateReleaseMs.store (135);
        const auto controlsPreset = folder.getChildFile ("AmpControls.avrxpreset"); require (controlsProcessor->savePreset (controlsPreset), "Control preset save failed");
        auto controlsRecall = std::make_unique<AvrxGrooveProcessor>(); controlsRecall->prepareToPlay (48000, 512); require (controlsRecall->loadPreset (controlsPreset) && controlsRecall->guitar.ampDriveDb.load() == 4 && controlsRecall->guitar.ampOutputDb.load() == -3 && controlsRecall->guitar.bassDb.load() == 2 && controlsRecall->guitar.midDb.load() == -5 && controlsRecall->guitar.trebleDb.load() == 3 && controlsRecall->guitar.gateOn.load() && controlsRecall->guitar.gateThresholdDb.load() == -51 && controlsRecall->guitar.gateReleaseMs.load() == 135 && controlsRecall->guitar.pickupConfiguration.load() == 1 && controlsRecall->guitar.inputGain.load() == .75f && ! controlsRecall->guitar.calibrating.load(), "Gate / tone / drive / pickup preset restore failed");
        std::unique_ptr<juce::AudioProcessorEditor> controlsEditor (controlsRecall->createEditor()); auto* controlKeys = dynamic_cast<AvrxGrooveEditor*> (controlsEditor.get()); controlKeys->filesDropped ({ mesaCapture.getFullPathName() }, 0, 0); snapshot (*controlsEditor, folder.getChildFile ("AmpControls.png"));
        std::cout << "Capture drive/output/tone, gate close/reopen with dry preservation, measured pickup calibration, silent rejection, manual override and full control preset recall passed\n";
        for (const double rate : { 22050.0, 48000.0, 192000.0 })
        {
            RigEffect echo; echo.prepare (rate); RigBlock delayBlock; delayBlock.type = RigType::delay; delayBlock.params = { 100, .5f, 1 };
            const int spacing = static_cast<int> (rate * .1); float first = 0, second = 0;
            for (int n = 0; n <= spacing * 2; ++n) { const float x = echo.process (n == 0 ? .4f : 0, delayBlock); if (n == spacing) first = x; if (n == spacing * 2) second = x; require (std::isfinite (x) && std::abs (x) <= .4f, "Delay unstable"); }
            require (std::abs (first - .4f) < .0001f && std::abs (second - .2f) < .0001f, "Delay time / feedback impulse response failed");
            echo.reset(); delayBlock.params[2] = 0; require (echo.process (.3f, delayBlock) == .3f, "Delay zero mix not dry");
            RigEffect reverb; reverb.prepare (rate); RigBlock plateBlock; plateBlock.type = RigType::plate; plateBlock.params = { 1, .4f, 1 }; double tail = 0, end = 0;
            for (int n = 0; n < static_cast<int> (rate * 4); ++n) { const float x = reverb.process (n == 0 ? .5f : 0, plateBlock); require (std::isfinite (x) && std::abs (x) < 1, "Plate reverb unstable"); if (n > rate * .1 && n < rate) tail += x*x; if (n > rate * 3) end += x*x; }
            require (tail > .00001 && end < tail * .01, "Plate reverb decay failed");
        }
        auto rigProcessor = std::make_unique<AvrxGrooveProcessor>(); rigProcessor->prepareToPlay (48000, 512); auto& rigGuitar = rigProcessor->guitar;
        require (rigGuitar.loadCapture (nativeFixture), "Rig NAM fixture failed"); rigGuitar.monitor.store (true); rigGuitar.outputGain.store (1);
        require (rigGuitar.editBlock (4, RigType::delay), "Enable delay failed"); rigGuitar.setBlockParameter (4, 0, 10); rigGuitar.setBlockParameter (4, 1, 0); rigGuitar.setBlockParameter (4, 2, 1);
        juce::AudioBuffer<float> rigInput (2, 512); rigInput.clear(); rigInput.setSample (0, 0, .2f); rigGuitar.processInput (rigInput, 2);
        require (std::abs (rigGuitar.outputAt (0)) < .00001f && std::abs (rigGuitar.outputAt (480) - .1f) < .00001f && rigGuitar.dryAt (0) == .2f, "Serial NAM / Delay chain failed");
        rigGuitar.enableBlock (4, false); rigGuitar.processInput (rigInput, 2); require (std::abs (rigGuitar.outputAt (0) - .1f) < .00001f, "Delay bypass failed");
        rigGuitar.enableBlock (4, true); rigGuitar.monitor.store (false); const auto rigTake = folder.getNonexistentChildFile ("RigDelay", ".wav", false); require (rigGuitar.startRecording (rigTake, true), "FX printed take failed"); rigGuitar.processInput (rigInput, 2); rigGuitar.stopRecording();
        juce::WavAudioFormat rigFormat; auto rigStream = rigTake.createInputStream(); std::unique_ptr<juce::AudioFormatReader> rigReader (rigStream ? rigFormat.createReaderFor (rigStream.release(), true) : nullptr); juce::AudioBuffer<float> rigAudio (1, 512);
        require (rigReader && rigReader->read (&rigAudio, 0, 512, 0, true, false) && std::abs (rigAudio.getSample (0, 0)) < .00001f && std::abs (rigAudio.getSample (0, 480) - .1f) < .00001f, "Rig effects not printed with monitoring off");
        require (rigGuitar.duplicateBlock (4), "Effect duplication failed"); rigGuitar.setBlockParameter (6, 0, 250); require (rigGuitar.getRig()->blocks[4].params[0] == 10 && rigGuitar.getRig()->blocks[6].params[0] == 250, "Duplicate parameter independence failed");
        require (rigGuitar.moveBlock (6, 0) && rigGuitar.getRig()->blocks[0].type == RigType::delay, "Block move failed");
        require (! rigGuitar.editBlock (0, RigType::capture), "Duplicate capture allowed");
        const auto rigPreset = folder.getChildFile ("BlockRig.avrxpreset"); require (rigProcessor->savePreset (rigPreset), "Rig preset save failed");
        auto rigRecall = std::make_unique<AvrxGrooveProcessor>(); rigRecall->prepareToPlay (48000, 512); require (rigRecall->loadPreset (rigPreset), "Rig preset load failed");
        for (size_t n = 0; n < RigLayout::slots; ++n) { const auto a = rigGuitar.getRig()->blocks[n], b = rigRecall->guitar.getRig()->blocks[n]; require (a.id == b.id && a.type == b.type && a.enabled == b.enabled && a.params == b.params, "Rig preset didn't retain position / parameters / bypass"); }
        auto invalidRig = juce::XmlDocument::parse (rigPreset); invalidRig->getChildByName ("GuitarRig")->getChildElement (0)->setAttribute ("p0", -123); const auto invalidRigFile = folder.getChildFile ("InvalidRig.avrxpreset"); require (invalidRig->writeTo (invalidRigFile) && ! rigRecall->loadPreset (invalidRigFile) && rigRecall->guitar.getRig()->blocks[0].params[0] == 250, "Invalid rig was published");
        require (rigRecall->guitar.editBlock (0, RigType::empty) && rigRecall->guitar.getRig()->blocks[0].type == RigType::empty, "Remove block failed");
        // Core reorder retains the expected gain through a linear test capture.
        rigGuitar.setRig (RigLayout()); rigGuitar.monitor.store (true); rigGuitar.ampDriveDb.store (6.0206f); rigInput.clear(); for (int n = 0; n < 512; ++n) rigInput.setSample (0, n, .2f);
        for (int n = 0; n < 20; ++n) rigGuitar.processInput (rigInput, 2); const float drivenBefore = rigGuitar.outputAt (400);
        require (rigGuitar.moveBlock (1, 2), "Reorder core blocks failed"); for (int n = 0; n < 20; ++n) rigGuitar.processInput (rigInput, 2); require (std::abs (rigGuitar.outputAt (400) - drivenBefore) < .0001f, "Linear fixture reorder changed gain incorrectly");
        // A custom two-block rig processes Delay then Drive.
        RigLayout orderRig; for (auto& b : orderRig.blocks) { b.type = RigType::empty; b.enabled = true; } orderRig.blocks[0].type = RigType::delay; orderRig.blocks[0].params = { 10, 0, 1 }; orderRig.blocks[1].type = RigType::drive;
        require (rigGuitar.setRig (orderRig), "Custom serial rig failed"); rigGuitar.ampDriveDb.store (6.0206f); rigGuitar.processInput (rigInput, 2); require (std::abs (rigGuitar.outputAt (500) - .4f) < .0001f, "Custom rig signal path failed");
        rigGuitar.bypassNam.store (true); rigGuitar.processInput (rigInput, 2); require (rigGuitar.outputAt (0) == .2f, "Whole rig bypass failed"); rigGuitar.bypassNam.store (false); rigGuitar.setRig (RigLayout()); rigGuitar.loadCapture (mesaCapture);
        std::unique_ptr<juce::AudioProcessorEditor> rigEditor (rigProcessor->createEditor());
        for (int n = 0; n < rigEditor->getNumChildComponents(); ++n) if (auto* button = dynamic_cast<juce::TextButton*> (rigEditor->getChildComponent (n))) if (button->getButtonText() == "Guitar") button->onClick();
        snapshot (*rigEditor, folder.getChildFile ("BlockRig.png"));
        for (int n = 0; n < rigEditor->getNumChildComponents(); ++n) if (auto* panel = dynamic_cast<GuitarPanel*> (rigEditor->getChildComponent (n)))
        {
            int tiles = 0; for (int child = 0; child < panel->getNumChildComponents(); ++child) if (auto* tile = dynamic_cast<RigTile*> (panel->getChildComponent (child))) { ++tiles; if (tile->type == RigType::delay) tile->onClick(); }
            require (tiles == 16, "Rig does not have sixteen visible tiles"); panel->refresh();
        }
        snapshot (*rigEditor, folder.getChildFile ("BlockDelay.png"));
        std::cout << "Stock delay impulse / feedback / mix and plate decay passed at 22050 / 48000 / 192000 Hz. Serial rig, bypass, duplicate independence, move/remove, processed WAV with FX, full preset restore and invalid-preset rejection passed\n";
        RigLayout gateOrder; for (auto& b : gateOrder.blocks) { b.type = RigType::empty; b.enabled = true; } gateOrder.blocks[0].type = RigType::gate; gateOrder.blocks[1].type = RigType::drive;
        require (rigGuitar.setRig (gateOrder), "Gate order fixture failed"); rigGuitar.monitor.store (true); rigGuitar.gateOn.store (true); rigGuitar.gateThresholdDb.store (-40); rigGuitar.gateReleaseMs.store (10); rigGuitar.ampDriveDb.store (12);
        for (int n = 0; n < 512; ++n) rigInput.setSample (0, n, .004f); for (int n = 0; n < 100; ++n) rigGuitar.processInput (rigInput, 2); require (std::abs (rigGuitar.outputAt (400)) < .000001f, "Pre-drive gate didn't close");
        require (rigGuitar.moveBlock (0, 1), "Gate reorder failed"); for (int n = 0; n < 10; ++n) rigGuitar.processInput (rigInput, 2); require (rigGuitar.outputAt (400) > .015f, "Reorder didn't change actual processing order");


        // v0.17: actual signal checks for the new effects and per-block gain.
        for (const double fxRate : { 22050.0, 48000.0, 192000.0 })
        {
            RigOctave pitch; pitch.prepare (fxRate); double fundamental = 0, octaveEnergy = 0;
            for (int n = 0; n < static_cast<int> (fxRate); ++n)
            {
                const float y = pitch.process (.1f * std::sin (static_cast<float> (juce::MathConstants<double>::twoPi * 440 * n / fxRate)));
                if (n > fxRate * .2) { fundamental += y * std::sin (juce::MathConstants<double>::twoPi * 440 * n / fxRate); octaveEnergy += y * std::sin (juce::MathConstants<double>::twoPi * 880 * n / fxRate); }
            }
            require (std::abs (octaveEnergy) > std::abs (fundamental) * 10 && std::abs (octaveEnergy) > fxRate * .005, "Shimmer octave shift is not an octave up");
            for (const auto type : { RigType::scream808, RigType::shimmer, RigType::bloomDelay })
            {
                RigEffect fx; fx.prepare (fxRate); RigBlock b; b.type = type; b.params = rigDefaults (type); b.params[2] = 1;
                if (type == RigType::bloomDelay) { b.params[0] = 10; b.params[1] = .85f; b.params[5] = 1; }
                if (type == RigType::shimmer) { b.params[0] = 8; b.params[4] = 1; }
                if (type == RigType::scream808) b.params[0] = 1;
                double energy = 0;
                for (int n = 0; n < static_cast<int> (fxRate * 2); ++n) { const float y = fx.process (n < fxRate * .2 ? .2f * std::sin (static_cast<float> (n * .12)) : 0, b); require (std::isfinite (y) && std::abs (y) < 2, "New effect unstable at supported sample rate"); if (n > fxRate * .2) energy += y * y; }
                if (type != RigType::scream808) require (energy > .0001, "Ambient effect has no tail");
                b.params[2] = 0; require (fx.process (.123f, b) == .123f, "New effect dry mix changed input");
                b.params[3] = 6.0206f; float boosted = 0; for (int n = 0; n < fxRate * .1; ++n) boosted = fx.makeup (.1f, b); require (std::abs (boosted - .2f) < .00001f, "Make-up boost wrong");
                b.params[3] = -6.0206f; for (int n = 0; n < fxRate * .1; ++n) boosted = fx.makeup (.1f, b); require (std::abs (boosted - .05f) < .00001f, "Make-up attenuation wrong");
            }
        }
        RigLayout expandedRig; for (auto& b : expandedRig.blocks) { b.type = RigType::empty; b.enabled = true; }
        expandedRig.blocks[0].type = RigType::scream808; expandedRig.blocks[0].params = rigDefaults (RigType::scream808);
        expandedRig.blocks[8].type = RigType::shimmer; expandedRig.blocks[8].params = rigDefaults (RigType::shimmer); expandedRig.blocks[8].params[3] = -4;
        expandedRig.blocks[15].type = RigType::bloomDelay; expandedRig.blocks[15].params = rigDefaults (RigType::bloomDelay); expandedRig.blocks[15].params[4] = 1200;
        require (rigGuitar.setRig (expandedRig) && rigGuitar.moveBlock (0, 15) && rigGuitar.duplicateBlock (8), "Sixteen-slot swap / new effect duplicate failed");
        rigGuitar.setBlockParameter (1, 4, .8f); require (rigGuitar.getRig()->blocks[8].params[4] == .5f, "Duplicate shimmer settings linked incorrectly");
        const auto expandedFile = folder.getChildFile ("ExpandedRig.avrxpreset"); require (rigProcessor->savePreset (expandedFile) && rigRecall->loadPreset (expandedFile), "New effect preset failed");
        for (size_t n = 0; n < RigLayout::slots; ++n) require (rigGuitar.getRig()->blocks[n].params == rigRecall->guitar.getRig()->blocks[n].params && rigGuitar.getRig()->blocks[n].type == rigRecall->guitar.getRig()->blocks[n].type, "New effects / output gains did not restore");
        auto legacyRig = juce::XmlDocument::parse (rigPreset); auto* legacyBlocks = legacyRig->getChildByName ("GuitarRig"); while (legacyBlocks->getNumChildElements() > 8) legacyBlocks->removeChildElement (legacyBlocks->getChildElement (8), true); for (auto* b : legacyBlocks->getChildIterator()) for (int n = 3; n < 6; ++n) b->removeAttribute ("p" + juce::String (n));
        const auto legacyFile = folder.getChildFile ("LegacyEightBlocks.avrxpreset"); require (legacyRig->writeTo (legacyFile) && rigRecall->loadPreset (legacyFile) && rigRecall->guitar.getRig()->blocks[15].type == RigType::empty && rigRecall->guitar.getRig()->blocks[0].params[3] == 0, "Eight-slot preset migration failed");
        rigGuitar.setRig (expandedRig);
        for (int n = 0; n < rigEditor->getNumChildComponents(); ++n) if (auto* panel = dynamic_cast<GuitarPanel*> (rigEditor->getChildComponent (n)))
        {
            bool profilesFound = false; int position = 0; for (int child = 0; child < panel->getNumChildComponents(); ++child) { auto* c = panel->getChildComponent (child); if (auto* link = dynamic_cast<juce::TextButton*> (c)) profilesFound |= link->getButtonText() == "Browse TONE3000"; if (auto* tile = dynamic_cast<RigTile*> (c)) { if (position++ == 15) tile->onClick(); } }
            require (profilesFound, "Integrated TONE3000 entry missing"); panel->refresh();
        }
        snapshot (*rigEditor, folder.getChildFile ("AmbientRig.png"));
        // Repeat record / stop / record on the SAME lane, then verify both WAVs,
        // timeline positions, pan/level, take preview, monitoring and preset reload.
        auto timelineProcessor = std::make_unique<AvrxGrooveProcessor>(); auto& timeline = *timelineProcessor; timeline.prepareToPlay (48000, 512); timeline.guitar.monitor.store (false);
        for (int d = 0; d < GrooveGenerator::drumCount; ++d) for (int c = 0; c < 16; ++c) timeline.setStepVelocity (d, c, 0);
        juce::AudioBuffer<float> timelineInput (2, 512); juce::MidiBuffer timelineMidi;
        auto recordRegion = [&] (float amplitude, double at, bool fromGuitar)
        {
            timeline.recorder.seek (at); const auto file = folder.getNonexistentChildFile ("RetainedTake", ".wav", false);
            require (fromGuitar ? timeline.startGuitarTake (file, false, 0) : timeline.startMultitrackTake (0, file, false, 0), "Repeated recording did not start");
            for (int block = 0; block < 4; ++block) { timelineInput.clear(); for (int n = 0; n < 512; ++n) timelineInput.setSample (0, n, amplitude); timelineMidi.clear(); timeline.processBlock (timelineInput, timelineMidi); }
            timeline.stopRecording(); timeline.recorder.waitForLoad(); return file;
        };
        const auto retainedFirst = recordRegion (.1f, .5, false); const auto retainedSecond = recordRegion (.2f, 1.5, false); const auto retainedThird = recordRegion (.3f, 2.5, true);
        require (retainedFirst.existsAsFile() && retainedSecond.existsAsFile() && retainedThird.existsAsFile() && timeline.recorder.getClip (0)->file == retainedFirst && timeline.recorder.getExtra (0) && timeline.recorder.getExtra (0)->size() == 2, "New recording replaced previous audio");
        auto& timelineStrip = timeline.recorder.strips[0]; timelineStrip.gain.store (.5f); timelineStrip.pan.store (-1); timeline.recorder.seek (.5); timeline.recorder.playing.store (true); timeline.recorder.beginBlock(); auto playback = timeline.recorder.render (false);
        require (std::abs (playback[0] - .05f) < .00001f && playback[1] == 0, "Track volume / left pan does not affect first take");
        timeline.recorder.seek (1.5); timelineStrip.pan.store (1); timeline.recorder.beginBlock(); playback = timeline.recorder.render (false); require (playback[0] == 0 && std::abs (playback[1] - .1f) < .00001f, "Right pan / retained second take playback wrong");
        timeline.recorder.playing.store (false); timeline.recorder.togglePreview(); timeline.recorder.beginBlock(); playback = timeline.recorder.render (false); require (playback[0] == 0 && std::abs (playback[1] - .15f) < .00001f, "Latest take preview bypasses track pan / volume");
        timelineStrip.gain.store (0); timeline.recorder.beginBlock(); playback = timeline.recorder.render (false); require (playback[0] == 0 && playback[1] == 0, "Track volume zero does not silence preview");
        timelineStrip.gain.store (.5f); timelineStrip.pan.store (-1); timeline.recorder.recordingLane.store (0); timeline.recorder.beginBlock(); require (timeline.recorder.monitor (.2f) == std::array<float, 2> { .1f, 0 }, "Live recorder monitor ignores lane mixer"); timeline.recorder.recordingLane.store (-1); timeline.recorder.previewPlaying.store (false);
        const auto timelineFile = folder.getChildFile ("RetainedTimeline.avrxpreset"); require (timeline.savePreset (timelineFile), "Multiple-clip session save failed"); auto timelineRecall = std::make_unique<AvrxGrooveProcessor>(); timelineRecall->prepareToPlay (48000, 512); require (timelineRecall->loadPreset (timelineFile) && timelineRecall->recorder.getExtra (0) && timelineRecall->recorder.getExtra (0)->size() == 2 && timelineRecall->recorder.getPreviewLane() == 0, "Multiple-clip timeline / preview lane not restored");
        timelineRecall->recorder.seek (2.5); timelineRecall->recorder.playing.store (true); timelineRecall->recorder.beginBlock(); playback = timelineRecall->recorder.render (false); require (std::abs (playback[0] - .15f) < .00001f && playback[1] == 0, "Restored third take has wrong position / mix"); timelineRecall->recorder.playing.store (false);
        std::unique_ptr<juce::AudioProcessorEditor> timelineEditor (timelineRecall->createEditor());
        for (int n = 0; n < timelineEditor->getNumChildComponents(); ++n) if (auto* button = dynamic_cast<juce::TextButton*> (timelineEditor->getChildComponent (n))) if (button->getButtonText() == "Recorder") button->onClick();
        for (int n = 0; n < timelineEditor->getNumChildComponents(); ++n) if (auto* panel = dynamic_cast<MultitrackPanel*> (timelineEditor->getChildComponent (n)))
        {
            panel->refresh(); bool levelFound = false, panFound = false;
            for (int child = 0; child < panel->getNumChildComponents(); ++child) if (auto* slider = dynamic_cast<juce::Slider*> (panel->getChildComponent (child))) { if (slider->getName() == "Track 1 volume") { levelFound = true; require (std::abs (slider->getValue() + 6.0206) < .06, "Recorder fader did not reflect restored mixer"); slider->setValue (0, juce::sendNotificationSync); require (timelineRecall->recorder.strips[0].gain.load() == 1, "Recorder volume control not wired"); } if (slider->getName() == "Track 1 pan") { panFound = true; slider->setValue (1, juce::sendNotificationSync); require (timelineRecall->recorder.strips[0].pan.load() == 1 && slider->getTextFromValue (1) == "R 100", "Recorder pan control not wired / labelled"); } }
            require (levelFound && panFound, "Recorder mixer controls missing"); panel->refresh();
        }
        snapshot (*timelineEditor, folder.getChildFile ("RetainedTimeline.png"));
        auto missingFirst = juce::XmlDocument::parse (timelineFile); for (auto* trackXml : missingFirst->getChildIterator()) if (trackXml->hasTagName ("Track") && trackXml->getIntAttribute ("index") == 0) trackXml->setAttribute ("file", folder.getChildFile ("UnavailableFirstTake.wav").getFullPathName());
        const auto missingFirstFile = folder.getChildFile ("MissingFirstRegion.avrxpreset"); require (missingFirst->writeTo (missingFirstFile) && timelineRecall->loadPreset (missingFirstFile), "Missing first region recall failed"); timelineRecall->recorder.seek (2.5); timelineRecall->recorder.playing.store (true); timelineRecall->recorder.beginBlock(); playback = timelineRecall->recorder.render (false); require (std::abs (playback[0] - .15f) < .00001f, "Missing first region changed later clip positions"); timelineRecall->recorder.playing.store (false);
        recordRegion (.4f, 180, false); timeline.recorder.seek (180); timelineStrip.gain.store (1); timelineStrip.pan.store (0); timeline.recorder.playing.store (true); timeline.recorder.beginBlock(); playback = timeline.recorder.render (false); require (std::abs (playback[0] - .4f) < .00001f && timeline.recorder.getExtra (0)->size() == 3, "Longer timeline recording did not retain / play a later take"); timeline.recorder.playing.store (false);
        std::cout << "PASS v0.17: 16-slot interchange/duplicates, legacy migration, 808/shimmer/bloom stability and dry mix at 22050/48000/192000 Hz, octave-up pitch, make-up +/-6dB, TONE3000 link, repeated same-lane and Guitar recordings retained, original WAVs, L/R pan/volume in playback/preview/monitoring, multi-clip preset recall and recorder UI controls.\n";


        // Real loopback OAuth callback + mocked HTTPS API. No account or tokens
        // from a real user are used; protected fixtures stay in the test folder.
        require (Tone3000::challenge ("dBjftJeZ4CVP-mB92K27uhbUJU1p1r_wW1gFWFOEjXk") == "E9Melhoa2OwvFrEMTJguCHaoeK1t8URWbuGJSstw-cM", "OAuth PKCE SHA256 does not match RFC7636");
        require (Tone3000::validKey ("t3k_pub_offline_fixture_123456") && ! Tone3000::validKey ("t3k_cs_never_accepted") && ! Tone3000::validKey ("t3k_pub_bad\r\nHeader"), "Publishable key validation failed");
        bool badState = false; try { Tone3000::callback ("/callback?state=bad&code=x&tone_id=42", "expected"); } catch (...) { badState = true; } require (badState, "Mismatched OAuth state accepted");
        require (Tone3000::callback ("/callback?state=expected&canceled=true", "expected")["canceled"] == "true", "OAuth cancellation not handled");
        juce::MemoryBlock protectedData, restoredData, privateFixture ("offline-session-only", 20); require (Tone3000::protect (privateFixture, protectedData) && protectedData != privateFixture && Tone3000::unprotect (protectedData, restoredData) && restoredData == privateFixture, "Windows protected token storage round trip failed");
        auto toneProcessor = std::make_unique<AvrxGrooveProcessor>(); toneProcessor->prepareToPlay (48000, 512); auto& client = toneProcessor->tone3000;
        const auto toneState = folder.getChildFile ("tone3000-test-session.bin"), toneCache = folder.getChildFile ("TONE3000 Test Captures"); client.configure (toneState, toneCache); require (client.setKey ("t3k_pub_offline_fixture_123456"), "Tone client setup failed");
        int tokenRequests = 0, modelRequests = 0, authenticatedDownloads = 0; bool forceDownload401 = true;
        client.setTestTransport ([&] (const juce::String& url, const juce::String& body, const juce::String& headers)
        {
            Tone3000::Reply r; r.status = 200; juce::String json;
            if (url.endsWith ("oauth/token")) { ++tokenRequests; require (body.contains ("client_id=t3k_pub_") && (body.contains ("code_verifier=") || body.contains ("grant_type=refresh_token")), "OAuth token POST missing verifier / client"); json = "{\"access_token\":\"offline-access\",\"refresh_token\":\"offline-refresh\",\"expires_in\":3600}"; }
            else if (url.contains ("tones/42")) { require (headers.contains ("Authorization: Bearer offline-access"), "Tone metadata unauthenticated"); json = "{\"title\":\"Offline Amp Fixture\",\"user\":{\"username\":\"test-creator\"},\"url\":\"https://www.tone3000.com/tones/offline-fixture\"}"; }
            else if (url.contains ("models?tone_id=42")) { ++modelRequests; require (url.contains ("architecture=1") && headers.contains ("Authorization: Bearer"), "Model compatibility filter / authentication missing"); json = "{\"data\":[{\"id\":7,\"name\":\"Offline Linear\",\"architecture_version\":\"1\",\"model_url\":\"https://www.tone3000.com/api/v1/download/7\"},{\"id\":8,\"name\":\"Incompatible A2\",\"architecture_version\":\"2\",\"model_url\":\"https://www.tone3000.com/api/v1/download/8\"},{\"id\":9,\"name\":\"Unsafe URL\",\"architecture_version\":\"1\",\"model_url\":\"http://other.example/file\"}]}"; }
            else if (url.contains ("download/7")) { require (headers.contains ("Authorization: Bearer offline-access"), "Model download missing bearer token"); ++authenticatedDownloads; if (forceDownload401) { forceDownload401 = false; r.status = 401; json = "{}"; } else require (nativeFixture.loadFileAsData (r.body), "NAM HTTP fixture read failed"); }
            else throw std::runtime_error ("Unexpected Tone API endpoint");
            if (json.isNotEmpty()) r.body.replaceAll (json.toRawUTF8(), json.getNumBytesAsUTF8()); return r;
        });
        std::thread callbackThread;
        client.openBrowser = [&] (const juce::URL& url)
        {
            require (url.getDomain() == "www.tone3000.com" && url.getParameterNames().contains ("code_challenge"), "Select flow is not secure / malformed");
            callbackThread = std::thread ([url]
            {
                const auto names = url.getParameterNames(), values = url.getParameterValues(); const juce::URL redirect (values[names.indexOf ("redirect_uri")]); const auto state = values[names.indexOf ("state")];
                std::cout << "Offline callback port " << redirect.getPort() << '\n';
                juce::StreamingSocket socket; if (! socket.connect ("127.0.0.1", redirect.getPort(), 2000)) { std::cout << "Offline loopback socket could not connect\n"; return; }
                const juce::String request = "GET /callback?state=" + state + "&code=offline-code&tone_id=42 HTTP/1.1\r\nHost: 127.0.0.1\r\n\r\n"; socket.write (request.toRawUTF8(), static_cast<int> (request.getNumBytesAsUTF8())); socket.waitUntilReady (true, 3000); std::array<char, 4096> response {}; socket.read (response.data(), static_cast<int> (response.size()), false);
            }); return true;
        };
        std::cout << "Starting TONE3000 loopback fixture\n";
        require (client.browse(), "Select flow did not start"); client.wait(); callbackThread.join();
        if (modelRequests == 0)
        {
            require (client.status().contains ("timed out"), "OAuth callback failed for a protocol reason");
            std::cout << "ENVIRONMENT LIMIT: local TCP callback could not connect. Continuing API checks with an injected callback; native browser return remains a user check.\n";
            client.openBrowser = [] (const juce::URL&) { return true; };
            client.setTestCallback ([] (const juce::URL& u) { return "/callback?state=" + u.getParameterValues()[u.getParameterNames().indexOf ("state")] + "&code=offline-code&tone_id=42"; });
            require (client.browse(), "Injected select flow failed to start"); client.wait();
        }
        require (! client.busy.load() && modelRequests == 1 && client.models().size() == 1 && client.title() == "Offline Amp Fixture" && client.creator() == "test-creator", "Selection / model metadata failed");
        require (client.download (0), "API model download did not start"); client.wait(); require (tokenRequests == 2 && authenticatedDownloads == 2, "HTTP401 refresh / single retry failed"); toneProcessor->serviceTone3000(); require (toneProcessor->guitar.captureFile().existsAsFile() && toneProcessor->guitar.hasAmp() && toneProcessor->guitar.captureFile().isAChildOf (toneCache), "API-downloaded NAM not loaded into rig");
        require (toneProcessor->guitar.captureFile().withFileExtension ("tone3000.json").existsAsFile(), "Capture attribution not saved");
        Tone3000 restoredClient; restoredClient.configure (toneState, toneCache); require (restoredClient.getKey() == "t3k_pub_offline_fixture_123456", "Encrypted connection did not restore");
        juce::MemoryBlock diskSecrets; require (toneState.loadFileAsData (diskSecrets) && ! juce::String::fromUTF8 (static_cast<const char*> (diskSecrets.getData()), static_cast<int> (diskSecrets.getSize())).contains ("offline-refresh"), "Connection credentials saved as plaintext");
        const auto activeCapture = toneProcessor->guitar.captureFile(); client.disconnect(); require (client.models().empty() && toneProcessor->guitar.captureFile() == activeCapture && activeCapture.existsAsFile(), "Disconnect removed downloaded/current capture");
        // Cancellation while waiting for browser never changes the loaded amp.
        client.setTestCallback ({}); client.openBrowser = [] (const juce::URL&) { return true; }; require (client.browse(), "Cancellation flow did not start"); std::this_thread::sleep_for (std::chrono::milliseconds (50)); client.cancel(); client.wait(); require (! client.busy.load() && toneProcessor->guitar.captureFile() == activeCapture, "Canceled select replaced the working rig");
        auto cleanSetup = std::make_unique<AvrxGrooveProcessor>(); Tone3000Panel integratedBrowser (*cleanSetup); snapshot (integratedBrowser, folder.getChildFile ("TONE3000Setup.png"));
        std::cout << "PASS TONE3000 protocol: RFC7636 PKCE, key/state/cancel validation, authenticated metadata/model listing/download with test replies, A1 filter, 401 refresh/retry, protected Windows connection recall, real NAM load, local attribution and canceled-flow retention. Live account acceptance/native browser return remains a user check.\n";

        const auto projectFolder = packsRoot.getParentDirectory();
        const auto bundledGrooves = projectFolder.getChildFile ("Grooves/GGD Rock Groove Pack");
        int grooveCount = 0, totalMapped = 0, totalIgnored = 0; std::array<int, 15> songCounts {};
        require (MidiGroove::ggdDrumForNote (62) == 2 && MidiGroove::ggdDrumForNote (10) == 2 && MidiGroove::ggdDrumForNote (50) == 4 && MidiGroove::ggdDrumForNote (48) == 5 && MidiGroove::ggdDrumForNote (74) == 7 && MidiGroove::ggdDrumForNote (66) == -1, "GGD source mapping incorrect");
        DrumKit ggdKit; ggdKit.notes[0] = 62;
        for (const auto& entry : juce::RangedDirectoryIterator (bundledGrooves, true, "*.mid", juce::File::findFiles))
        {
            const auto file = entry.getFile(); const auto options = MidiGroove::libraryOptions (file); const auto groove = MidiGroove::read (file, ggdKit, 120, options);
            if (! groove.valid) std::cout << "GGD failure: " << file.getFileName() << " " << groove.error << '\n';
            require (options.ggd && groove.valid && groove.bpm == options.tempo && groove.numerator == options.numerator && groove.denominator == options.denominator, "Bundled groove mapping / tempo / meter import failed");
            const int songNumber = file.getParentDirectory().getFileName().substring (7, 9).getIntValue(); require (songNumber >= 1 && songNumber <= 15, "Unexpected song folder"); ++songCounts[static_cast<size_t> (songNumber - 1)]; ++grooveCount; totalMapped += groove.mapped; totalIgnored += groove.ignored;
        }
        require (grooveCount == 225 && totalIgnored == 1, "Not all 225 GGD grooves loaded / unexpected ignored notes"); for (int count : songCounts) require (count == 15, "Missing song patterns");
        auto libraryProcessor = std::make_unique<AvrxGrooveProcessor>(); libraryProcessor->prepareToPlay (48000, 512); libraryProcessor->grooveFolder = projectFolder.getChildFile ("Grooves");
        const auto ggd6File = bundledGrooves.getChildFile ("Song - 03 - 200 BPM - 6_8/Rock-Song3-Pattern01.mid");
        const auto ggd6 = MidiGroove::read (ggd6File, *libraryProcessor->getKit(), 120, MidiGroove::libraryOptions (ggd6File));
        require (ggd6.valid && ggd6.bpm == 200 && ggd6.numerator == 6 && ggd6.denominator == 8 && libraryProcessor->applyGroove (ggd6), "GGD 6/8 song failed");
        const auto ggdPreset = folder.getChildFile ("GGDGroove.avrxpreset"); require (libraryProcessor->savePreset (ggdPreset), "GGD preset save failed"); auto ggdRecall = std::make_unique<AvrxGrooveProcessor>(); require (ggdRecall->loadPreset (ggdPreset) && ggdRecall->grooveTitle == ggd6.name && ggdRecall->getKit()->pattern == libraryProcessor->getKit()->pattern && ggdRecall->getKit()->numerator == 6, "GGD groove preset restore failed");
        const auto relocatedLibrary = folder.getChildFile ("RelocatedGrooves"); require (bundledGrooves.copyDirectoryTo (relocatedLibrary), "Groove relocation failed");
        const auto movedGroove = relocatedLibrary.getChildFile ("Song - 03 - 200 BPM - 6_8/Rock-Song3-Pattern01.mid"); const auto movedOptions = MidiGroove::libraryOptions (movedGroove); require (movedOptions.ggd && movedOptions.tempo == 200 && MidiGroove::read (movedGroove, ggdKit, 120, movedOptions).valid, "Portable groove library failed");
        std::unique_ptr<juce::AudioProcessorEditor> libraryEditor (libraryProcessor->createEditor());
        for (int n = 0; n < libraryEditor->getNumChildComponents(); ++n) if (auto* button = dynamic_cast<juce::TextButton*> (libraryEditor->getChildComponent (n))) if (button->getButtonText() == "Grooves") button->onClick();
        for (int n = 0; n < libraryEditor->getNumChildComponents(); ++n) if (auto* panel = dynamic_cast<GroovePanel*> (libraryEditor->getChildComponent (n)))
        {
            bool foundLibrary = false; juce::ComboBox* librarySongs = nullptr;
            for (int child = 0; child < panel->getNumChildComponents(); ++child)
            {
                if (auto* box = dynamic_cast<juce::ListBox*> (panel->getChildComponent (child))) foundLibrary = box->getModel()->getNumRows() == 230;
                if (auto* box = dynamic_cast<juce::ComboBox*> (panel->getChildComponent (child))) if (box->getName() == "Library songs" && box->getNumItems() == 16) librarySongs = box;
            }
            require (foundLibrary && librarySongs, "Bundled library / song selector missing"); librarySongs->setSelectedId (4, juce::sendNotificationSync); panel->loadFile (ggd6File);
            for (int child = 0; child < panel->getNumChildComponents(); ++child) if (auto* box = dynamic_cast<juce::ListBox*> (panel->getChildComponent (child))) require (box->getModel()->getNumRows() == 20, "Song filter didn't show 15 grooves plus starters");
        }
        snapshot (*libraryEditor, folder.getChildFile ("GGDGrooves.png"));
        std::cout << "All 225 supplied GGD grooves / 15 songs passed; mapped=" << totalMapped << "; ignored=" << totalIgnored << ". Source map, song tempo overrides, 200 BPM 6/8, song filter, preset recall and portable library passed\n";
        std::cout << "PASS: complete offline audio, MIDI, rig FX, recording, presets, GGD library and editor suite.\n";
        return 0;
    }
    catch (const std::exception& error) { std::cerr << "FAIL: " << error.what() << '\n'; return 1; }
}
