# Version 0.17 validation

Windows x64 Release build and complete offline suite passed. New checks cover 16 visible compact slots; exchanging across rows; independent new-effect duplicates; six-parameter preset persistence and legacy eight-slot migration; +6/-6 dB block make-up; actual octave-up pitch against a known 440 Hz input / 880 Hz output frequency check; 808, shimmer and ambient-delay stability/dry mix at 22050, 48000 and 192000 Hz; existing serial NAM processing, printed FX WAV and gate-order behavior.

Recorder regression: record, stop and record again on the same lane plus Guitar Studio recording; all three original WAVs and timeline clips retained. First/second/third take alignment and audible L/R pan/volume were checked, including latest-take preview and live monitoring. Multi-clip preset reload restores every region and mixer control. Rendered recorder controls were exercised and reflected restored gain/pan; no actual interface or speakers were used.

TONE3000: RFC7636 SHA256 PKCE test vector; publishable-key/state/cancellation validation; injected OAuth callback with simulated HTTPS token, metadata, model and download replies; A1 filtering; 401 refresh plus one retry; Windows DPAPI encrypt/decrypt and persisted session recall; real downloaded-fixture NAM load; local attribution; disconnect/cancel retaining the current amp. A real local TCP callback test could not connect in this restricted environment, so native browser return remains a user check. Native Windows HTTPS transport is implemented, but actual TONE3000 authorization/download has not been tested because the user has no account/key yet. The prototype uses Select flow in the default browser, not a custom in-app catalog, and explicitly requests Amp + Cab NAM A1.

Rendered previews inspected: expanded rig, ambient effect inspector, stacked recorder regions and TONE3000 setup. Earlier audio/MIDI/analysis, all 225 GGD grooves, both packs, presets, supplied Mesa capture, NAM recording and shortcuts remain passing. Packaging verifies both ZIPs, executable hash, 383 WAVs, 225 original MIDI files and the exact supplied Mesa capture. Stock effects still need subjective listening and physical interface/latency testing; the rig remains serial mono. Historical validation records follow.

# Version 0.16 validation

Windows x64 Release standalone and the complete offline suite passed. New checks cover delay impulse time, feedback and exact dry mix, and finite decaying plate-style reverb at 22.05 / 48 / 192 kHz; actual serial NAM + delay output and bypass with dry DI preserved; effects printed into a WAV while monitoring is off; duplicate parameter independence, move/remove, duplicate-core rejection, full rig preset recall and invalid-rig rejection. Gate/Drive reorder changes the actual audio processing order. Guitar Studio and the Delay inspector were rendered offscreen and visually inspected.

GGD validation covers all 225 supplied MIDI files and all 15 folders, strict source-note mapping independent of destination notes, folder tempo/meter overrides, Song 03 at 200 BPM / 6/8, song filtering, named groove preset recall and library relocation. Only one stray note 0 is unmapped. Original MIDI assets are copied unchanged and checked by hash. Import quantizes to AVRX's grid and collapses articulations to nine pads; full source microtiming / articulation playback is not claimed.

Packaging verifies ZIP integrity, the executable hash, 383 WAV copies, 225 MIDI copies and the supplied Mesa second-file capture. Native audio hardware, interactive pickers, live latency and subjective FX tone remain user checks. The rig is serial mono; the plate-style algorithm is stock. Earlier unrelated compiler warnings remain. Sections below are historical records for earlier versions, including limitations since superseded.

# Version 0.15 validation

Windows x64 Release and offline suite passed. Added checks cover Drive/output through a known NAM model, bass-shelf boost, gate close/reopen and preserving ungated Dry DI; controlled processed WAV recording with monitoring off; all three measured pickup calibration profiles; weak/silent input rejection; manual override/cancel; complete control/pickup/trim preset restore without restarting calibration; and rendered Guitar control layout. Earlier direct-NAM/Mesa/recording/pack/human-feel checks remain passing.

The auto-input routine is a measured digital level match with pickup-specific boost limits, not physical pickup/interface dBu calibration or continuous AGC. Live input, pickup noise and subjective tone remain hardware checks. No trained amp weights or original capture assets were altered.

# Version 0.14 validation

Windows x64 Release standalone and offline suite passed with embedded NAM Core 0.6.0, Eigen 3.4.0, nlohmann JSON 3.12.0, JUCE 9.0.4 and Visual Studio 2026. Native integration requires no installed NAM VST3; the hosted option remains tested separately. Tests do not write the user's real AppData preferences or use the live audio interface.

Added checks: known Linear gain/bypass; upstream LSTM, WaveNet and slimmable example load/process; Unicode capture path; invalid capture retains the previous amp; fixed-rate neural model disabled on 44.1 kHz and recovers on 48 kHz; processed recording rejected during mismatch; wet recording with monitoring off; capture changes blocked during recording; printed WAV persists after capture unload; direct-capture preset recall with monitoring stopped; drag/drop and native Guitar controls; actual supplied Mesa SweetSpot+808 capture loads/processes, defaults can remain selected pending 48 kHz, and portable @capture references restore from a relocated folder. All drum pack/human feel/preset/recording checks remain passing.

The bundled capture bytes match the supplied second file; WAV assets are unchanged. UI snapshots are rendered offscreen. Desktop device routing, actual app-close/reopen, tone and live-interface latency still need manual checks. No cabinet IR loader, neural sample-rate conversion, training frontend or external VST3-state persistence was added.

# Version 0.13 validation

Windows x64 Release standalone and offline suite passed with JUCE 9.0.4 / Visual Studio 2026. Both supplied packs were decoded from actual WAVs and mapped into all nine drum channels. Chango Luke Holland has 283 bundled WAVs; Time Traveller has 100. The longest WAV is below 4.4 seconds, within the 10-second one-shot limit.

Added checks cover actual soft/medium/hard/hardest selection, alternate-take cycling, the second rack-tom tuned variant, both pack manifests, failed-pack rollback, selector entries and UI rendering; portable velocity-bank presets reloaded from a separate relocated sample folder; Feel/Timing restore; bounded non-degenerate velocity distribution; zero-Feel grid/velocity preservation; sample-exact live MIDI offsets matching the shared feel model and MIDI drag-out timestamps/velocities. All prior recording/NAM-host/analysis/preset checks also passed. Embedded NAM Core is pending its source dependencies and is not in this build.

Hardware playback and the user's live interface remain manual checks. The human-feel heuristic is not a statistical fit to recorded drummers. Full Kontakt articulation/velocity scripting, independent real mic buses and a distinct second rack-tom recording are not implemented.

# Version 0.12 validation

Windows x64 Release standalone and offline integration suite built successfully on this PC with JUCE 9.0.4 and Visual Studio 2026. No DAW test was requested. Tests use workspace fixture files; they do not alter the user's real AppData preferences.

Added checks: preset round trip for all nine drum strips, four actual WAV layers, complete 7-bar 7/8 32nd-note pattern, velocities, tuning, root notes, MIDI mapping, ambience, EQ/parallel compressor controls, tempo and swing; four recorder WAV lanes with NAM-printed flags, offsets and mixer controls; reference waveform/last-take reload without changing the pattern; guitar inputs/gains, record modes/count-in and armed lane; stopped startup; invalid-version rejection retaining the kit; missing-WAV reporting and retaining its path through a subsequent last-session save/load; visible Save/Load header controls. Existing audio, NAM, analysis, recording-shortcut and visual-render checks also passed.

The automatic-session file round trip was tested using a workspace path. Actual desktop app close/reopen and native Save/Load dialogs still need a manual check on the user's audio interface. Offline snapshots verify header placement on all pages. NAM capture state is not persisted in this version.

# AVRX GROOVE 0.11 validation - 12 October 2026

Release x64 Standalone and offline test executable built with Visual Studio 2026/MSVC 19.51, JUCE 9.0.4 and local JUCE source. AVRX_BUILD_VST3=OFF: no DAW plugin is included in this release. Windows ASIO and NAM VST3-host support remain enabled. No Mac build was performed. Older version check notes below retain their original feature/version context.

## Passed checks

- Synthetic 90/120/150 BPM analysis with timing-tolerant correlation, silence rejection and higher detection strength revealing softer attacks. Detected attack markers retained for display.
- Four-bar default, long-step editing, 7/8 and 6/8 lengths, triplet timing, invalid fractional-grid rejection, resolution conversion preserving musical time.
- Layered voices summing correctly, real WAV loading into two slots, per-layer gain and octave pitch ratio. Manual root/key matching chooses the nearest semitone interval.
- Audible layered drum rendering with ambience.
- MIDI drag-file generation and re-reading: format 1, tempo + kit tracks, 960 PPQ, 7/8 meter, correct loop length and a custom mapped tom on a later step.
- Live engine preserves exact 7/8 bar duration with swing on an odd number of eighth-note steps.
- A synthetic signal on active input 2 recorded to a real mono/24-bit WAV exactly 2,880,000 frames long at 48 kHz (60 seconds). Recording auto-stopped at the limit, ignored a subsequent input block, and flushed the file. The signal confirms correct input routing. No physical interface input or speaker output was used in this recording test.
- NAM-processed recording rejected when no NAM plugin is loaded.
- Installed `C:/Program Files/Common Files/VST3/NeuralAmpModeler.vst3` loaded successfully; offline processing returned finite output. No `.nam` capture was supplied, so model/cabinet tone is not validated.
- Device type enumeration includes ASIO; Standalone Settings selector and Drums/Guitar tabs rendered offscreen and were inspected. Enumeration did not open an audio device for playback.
- The audio-drop event handler accepts a WAV and loads it as reference audio on Guitar, without assigning it to a hidden drum pad. This is a handler test, not an OS drag gesture.

- Streamed input history retains eight seconds; the recorded history spans all 6,000 ten-millisecond bins of a full minute.
- Synthetic guitar attacks generate a kick/snare/hat accompaniment after one bar while retaining the selected 120 BPM. Silent input creates no attacks.
- Metronome produces 28 correctly spaced denominator pulses over seven seconds in 7/8 at 120 quarter-note BPM.
- One-bar 4/4 pre-roll skips exactly 96,000 frames at 48 kHz/120 BPM, including a block crossing the capture boundary. Only post-count-in input appears in the WAV; forced clicks and count-in input are excluded. Two-bar 7/8 count-in is exactly 3.5 seconds.
- Decoded reference has waveform peaks and seek changes playback position. Audio/Guitar/Drums/Settings pages rendered offscreen for inspection.

## New 0.7 checks passed

- Crash/ride synthesized sound and decay tails, default gains/GM notes 49/51, WAV layering on Ride and both cymbals present in MIDI drag content.
- Piano-roll event handlers add, move, change velocity and delete a snapped cymbal hit; displayed lanes sort by current MIDI mapping.
- Real installed NAM output recorded to a WAV and compared sample-by-sample with the hosted processed output. Direct take playback matches those WAV samples at preview gain, proving no second NAM pass. No capture was supplied: this validates the signal path, not a particular amp model/tone.
- Four imported audio lanes sum at their gains/start offsets; mute, solo, pan and pause during count-in work.
- A real overdub WAV starts at the chosen 0.5-second lane offset after a one-bar count-in, contains exactly 1,280 captured frames in the boundary test and excludes backing audio/clicks. Stopping through transport finalizes/imports it. Cancelling before capture keeps the previous lane/offset and clears its recording exclusion.
- Timeline seeking aligns a swung drum note with the audio cursor at the expected sample.
- Spacebar event handler starts/stops latest-take playback and suppresses held-key repeats. Recorder file-drop handler imports into the corresponding lane.
- Drums/piano roll, Guitar, Audio, Recorder and Settings screens rendered offscreen and inspected. Standalone/VST3 Release builds and manifest generation completed.

## New 0.8 layout/routing checks

- Separate Samples navigation: pads, layers, tuning and per-pad controls are hidden on the opening Drums page.
- WAV dropped onto the sample waveform loads the selected layer, retains another layer and does not change reference audio. Worker builds waveform peaks before publishing the sample.
- Reference audio dropped at the former pad area stays on Drums, updates the opening waveform and cannot load a hidden pad.
- Opening Drums and Samples pages rendered offscreen and inspected, along with the existing Audio/Guitar/Recorder/Settings pages.
- ReWire intentionally remains future feasibility work, documented in ROADMAP.md; it is absent from this build.

## New 0.9 sound-shaping checks passed

- Transparent default bypass, +6 dB parametric gain at 1 kHz and high-pass attenuation at 20 Hz.
- Stereo-linked compressor static curve, stronger attenuation at 20:1, dry/50%/wet parallel mixes and pad compression applied through the actual processor audio path.
- Finite output with extreme EQ/compressor settings at 22.05/48/192 kHz; settings remain isolated to the selected drum.
- Spectral-flux-supported imported onset detection retains strengths/grid-deviation metadata. Synthetic 90/120/150 BPM and detection-strength checks pass. Out-of-phase stereo produces the same pattern/tempo as mono.
- Tempo correlation keeps the RMS onset evidence separate from the added flux detector; flux initially shifted a synthetic tempo estimate, which was corrected before delivery.
- All existing offline checks passed again. Six pages rendered offscreen and inspected; the new Drum Lab sample waveform, pad controls and channel-strip layout fit without clipping.
- Standalone and VST3 Release x64 rebuilt; VST3 manifest generated. ZIP integrity and packaged executable identity verified during packaging.

Detailed analog modelling remains deferred. Spectral flux is an initial analysis enhancement, not validation of full-song groove accuracy. Per-hit measured offsets are retained internally but are not yet applied to playback/MIDI; live-follow retains its earlier detector. EQ/compression do not transfer through MIDI.

## New 0.10 custom studio / console checks passed

- Drum stereo balance: centre preserves equal stereo power; full left/right silences the opposite channel. Muted drums and drums excluded by another drum solo render silence. MIDI drag retains only the soloed kick in the solo fixture.
- Mixer navigation and a real fader change update the selected pad's gain. Console low-EQ gain updates the corresponding processing settings. Mixer transport starts recorder tracks plus groove and stops them on the second toggle.
- Interactive embedded kit artwork is present; kit double-click opens Sound Lab. Generated artwork is embedded into the executable with JUCE BinaryData; the source ZIP includes the original asset and generation prompt.
- Drum Engine, Sound Lab, Guitar, Analyse, Recorder, Mix Console, Recorder & buses and Settings rendered offscreen and visually inspected after the custom layout changes.
- Existing complete audio/analysis/recording/MIDI/transport checks passed again. Recorder waveform/clip drawing maps the same source duration/start offsets as playback. Colour, clip headers and grid changes do not add multiclipping/trim/automation.
- Standalone Release build succeeds with DAW-plugin generation disabled. ZIP integrity and packaged executable hashes checked during packaging.

## New 0.11 recording / groove checks passed

- Recording-folder save/restore using a temporary preferences file, unique take paths and preservation of previous files. Tests write only inside their fixture folder; the app's normal preferences location is implemented in StandaloneMain.
- Numpad 3 event starts Guitar capture without a picker, held repeats do not restart it, Space stops/saves it, and still-held numpad 3 does not restart after Space. Top-row 3 is ignored.
- Recorder shortcut captures the armed third lane, creates a Track3 WAV in the selected folder and imports it into that lane on Space stop. Existing exact 60-second recording and count-in checks pass again.
- Real generated MIDI files: PPQ tempo/meter, 7/8 two-bar duration, GM aliases, velocities, ignored unrelated pitches and triplet-grid inference. Format 2, SMPTE and changing-tempo files are rejected. Invalid data leaves current kit untouched; valid imports retain mix settings.
- Loaded 144 BPM two-bar 7/8 groove renders audible drums and kick MIDI at frames 0, 70000, 140000, 210000 and 280000 (48 kHz), within one frame. This caught and fixed a short-circuit restart flag that previously retriggered the initial hit on the next buffer.
- Groove Player library/file handlers apply the imported pattern; its transport plays only drums. Non-preset imported 2/4 is displayed correctly in Drum Engine.
- Settings folder controls, updated recording buttons and new Groove Player rendered offscreen and inspected. All existing offline integration checks pass.
- The expanded integration runner uses an 8 MB Windows stack and heap allocation for additional processor fixtures. The standalone processor is already allocated on the heap.

## Remaining interactive checks

Native audio drag-in/pickers, the recipient DAW accepting an external MIDI drop, real ASIO/WASAPI device changes and latency, physical guitar monitoring/recording, NAM's native capture chooser and tonal results require user testing. The 60-second and pre-roll tests validate file duration/recording logic rather than hardware performance. Live-follow validation uses synthetic attacks, not real guitar performances, and does not establish musical quality for full songs. Tempo remains user-selected. Source decoding fixtures cover WAV, not every included codec.

Audio routing persists in the custom Standalone; musical kit/sequence/NAM state is session-only. The long grid has no undo, so reducing its length/coarsening resolution can discard/merge hits. Room/overheads remain derived drum buses. Tuning/sample layering is not encoded in MIDI.

The official NAM DSP source download was blocked by the session's restricted network approval policy. The working integration uses the existing installed NAM VST3 instead; it is not redistributed here.
