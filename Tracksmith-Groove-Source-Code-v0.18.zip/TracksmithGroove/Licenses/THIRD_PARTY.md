Third-party code compiled into AVRX GROOVE

NeuralAmpModelerCore 0.6.0 (source archive supplied by user), Steven Atkinson; MIT.
https://github.com/sdatkinson/NeuralAmpModelerCore
Eigen 3.4.0 (source archive supplied by user); bundled COPYING files cover its headers.
https://gitlab.com/libeigen/eigen
nlohmann JSON 3.12.0, Niels Lohmann; MIT; bundled within the supplied NAM Core.
https://github.com/nlohmann/json

The source download includes the vendored NAM/Eigen/JSON headers and implementation.
JUCE 9.0.4 remains a separately supplied local SDK; its source is not in the ZIP.
Mesa capture and Chango/Time Traveller WAVs were supplied by the user and copied unchanged.
Capture metadata credits Mad Hatter Amp Lab; file is an amp_cab capture at 48000 Hz.
These capture/sample assets are separate from the open-source code licenses above.
