# AVRX GROOVE 0.17 - Expanded rig, retained takes and TONE3000 integration

Windows x64 standalone prototype. This download contains the app; the optional DAW plugin is disabled by default in the source build. The custom studio layout has a persistent sidebar, an interactive realistic drum kit, a metal sound-shaping rack and a plugin-style mix console. Sound Lab has separate processing for each drum. The opening Drum Engine page now focuses on reference-audio drag/drop, its waveform and the drum piano roll. All nine pads, WAV layers, tuning and per-pad settings live on the dedicated Sound Lab page, which also shows the selected sample's waveform. Guitar/NAM, multitrack recording, metronome/pre-roll, detection strength and MIDI drag-out remain available.

## New Guitar Studio block rig

The Guitar page has 16 compact selectable blocks across two rows, eight per row. Audio runs left to right across row 1, then left to right across row 2. Click a block for its controls and description. The live-input / guitar-take waveform panels are removed from this page; takes remain available on Recorder. Capture loading, recording mode, pre-roll, Record, Stop and Play are compact controls at the top. Numpad 3 / Space and the saved recording folder work as before.

The default rig is **Gate > Drive > NAM Capture > Tone EQ > Digital Delay > Plate Reverb > Empty > Output**. Delay and reverb start bypassed to retain your existing tone. Select one and check **Block active**. Move swaps adjacent blocks; **Swap with slot** exchanges any two of the 16 slots; Remove clears a slot; the type menu adds or replaces a block. All effect types can be duplicated into an empty slot with independent settings. This prototype supports one each of Gate, Drive, Capture, Tone EQ and Output. Their controls retain their values when temporarily removed. The second row starts empty; existing eight-slot presets retain their order and add eight empty slots.

| Block | Controls / behavior |
|---|---|
| Gate | Gate toggle, threshold, release; works at its actual chain position |
| Drive | Level from -24 to +24 dB; before NAM, drives the capture harder; not a separate pedal model |
| NAM Capture | Loaded .nam model; the bundled Mesa full-rig capture already includes amp and cabinet |
| Tone EQ | Bass 90 Hz shelf, Mid 1 kHz bell, Treble 6.5 kHz shelf, each +/-12 dB |
| Digital Delay | 10-2000 ms, feedback 0-0.85, dry/wet mix 0-1; fractional delay with smoothed time changes |
| Plate Reverb | Stock diffused four-line feedback reverb; decay 0.2-8 s, damping, dry/wet mix; plate-style ambience |
| Output | Rig gain before Monitor level and the recording tap |
| 808 Overdrive | Stock 808-inspired bass cut, mid-focused soft clipping, Overdrive, Tone, Mix; interpolated clipping stages |
| Shimmer Reverb | Diffused reverb with a dual-head octave-up tail; Decay, Damping, Mix and Shimmer amount |
| Bloom Ambient Delay | Digital repeats plus diffused ambience and attack-sensitive swelling; Time, Feedback, Mix, Swell and Diffusion |

**Make-up Gain (-24 to +24 dB)** balances the output of each active block, with a short smoothing ramp. It is outside delay/reverb feedback loops. These are AVRX stock effects, not component models or copies of proprietary hardware algorithms. Strymon Bloom is a swelling reverb; this requested ambient delay uses a related rising/diffused character. [Bloom reference](https://www.strymon.net/product/bigsky-plugin/).

Block types, positions, bypass and settings save with named presets and automatic last-session recall. Older presets get the default rig with effects bypassed. Type/order/bypass editing is disabled while recording; parameter knobs remain adjustable. Bypassing/removing/replacing an effect resets its tail; moving keeps it. **Bypass rig** bypasses all blocks. Dry DI and live-follow remain after Input Trim, before the rig. **NAM sound recording** prints the entire chain before Monitor level and requires an active Capture block at the correct device rate. Playback of a printed take does not process it again.

This first rig is one serial mono path, duplicated to stereo output. Parallel branches, stereo/ping-pong effects, cabinet IR loading and separate preamp/power-amp stages are future work. These are stock algorithms. The [Neural DSP device list](https://neuraldsp.com/device-list) is a saved reference for categories and terminology; its proprietary models are not included.

## Recorder: retained takes and working mixer controls

Recording again adds a new WAV clip at the playhead position in the armed lane. The timeline supports up to one hour; each take still stops at 60 seconds. Earlier clips remain on the timeline and on disk, including takes recorded from Guitar Studio. Imported audio also adds a clip. All clips appear as stacked waveform regions within the lane; overlaps play together. **Clear** intentionally removes the lane's timeline clips, while its WAV files remain on disk. Lane start moves the whole lane. Individual clip editing/comping is future work.

The recorder has a **Volume** fader in dB and **Pan** with **L 100 / Centre / R 100** values. Double-click for unity level or centre pan. Level, stereo balance, mute and solo apply to timeline playback, latest-take preview and the live monitor of a Recorder take. The monitor mix does not change recorded WAV samples. Take preview no longer uses an unrelated fixed volume. Recorder controls refresh from the mix console and restored presets. Save/Load preset and automatic last-session saving retain every clip's file, start offset and printed-NAM flag. Keep the recording folder available: presets reference WAVs rather than embed them.

## TONE3000: browse, select, download and load

On Guitar, **Browse TONE3000** opens the integrated capture panel; Settings also has **TONE3000 connection**. This uses the official Select flow, not a simple website link. The catalog, sign-in and auditioning run in your default browser; selection returns to AVRX through a local callback. Choose a model in AVRX, then **Download & load**. The current amp stays active until loading succeeds. Stop recording before choosing/loading a different capture.

First create a TONE3000 account. In its **Settings > API Keys**, create a **publishable** key beginning with `t3k_pub_`. Paste it into the AVRX connection panel and click **Save key**, then **Browse TONE3000 / Sign in**. The panel has an account/API setup link. No key is bundled: live sign-in/download requires your account and key. Secret keys are rejected. [Official integration guide](https://github.com/tone-3000/api), [API and account setup](https://www.tone3000.com/api).

This prototype explicitly requests **Amp + Cab / NAM A1** captures supported by the bundled engine. A2, IR/cab downloads and an in-app custom catalog are future work. Model names, tone title and creator are shown in the capture panel; attribution is saved alongside each downloaded NAM file. Downloads live under `%APPDATA%/AVRX/GROOVE/TONE3000 Captures`. Their paths save in presets and work offline after download. A model at a different sample rate stays selected until you switch to its required rate in Settings.

OAuth uses random state, SHA256 PKCE, a loopback-only temporary callback, bounded requests and explicit cancellation. Tokens and the publishable key are stored using Windows DPAPI in `tone3000-session.bin`, separately from presets/download ZIPs; expired access tokens refresh automatically and a 401 retries once. Disconnect clears the saved session, keeping downloaded captures. No partner endorsement is claimed. Protocol, encrypted storage and download-to-NAM loading passed with an injected callback and simulated API. A local TCP connection could not be exercised in this restricted environment. Live account acceptance and native browser return remain user checks because no account/key was supplied.

## Included GGD grooves

**Groove Player** automatically lists all **225 original MIDI files across Songs 01-15**, bundled under `Grooves/GGD Rock Groove Pack`. Use the song selector to show a song's 15 patterns; click a groove and press Play groove / Space. **GGD library** returns to the bundled library after browsing another folder. Keep `Grooves` beside `Standalone` when moving the app. Saving a preset retains the loaded pattern, name, tempo and meter; the library remains available on each launch.

**Auto source map** recognizes the bundled manifest. For other GGD pack files, choose **GGD groove format** before loading. This is GGD's groove-file map, which differs from its instrument maps. Note 62 maps to closed hat, 50 to Rack Tom 1, 48 to Rack Tom 2, and 74 to Crash as a china fallback. Extra cymbals, toms, snare articulations and hat openness collapse to the closest of AVRX's nine pads. Choke notes are ignored. The bundled mapping guide gives the full table. Your destination MIDI map (Logic / GM or custom notes) remains independent.

Folder BPM/meter labels override inconsistent embedded metadata in this supplied library: **Song 03 is 200 BPM / 6/8**. Original MIDI bytes are unchanged. AVRX import retains velocities but snaps timing to its selected grid; simultaneous hits on the same pad/cell merge using the stronger velocity. Feel adds optional variation; set it to zero to retain imported velocities/grid exactly. All 225 files import successfully; one stray note 0 is ignored. No Kontakt instrument or GGD sample audio is bundled.

## Included drum packs

The app download now includes all 283 WAVs from your supplied **Chango Luke Holland** kit and all 100 WAVs from your supplied **Time Traveller** kit, plus AVRX mapping manifests. Original WAV data is copied unchanged. Kontakt instruments are not included or required. Keep the `Drum Packs` folder beside `Standalone` when moving the app.

On **Sound Lab**, use the top-right pack selector to switch between Chango Luke Holland, Time Traveller and Built-in drums. A first launch defaults to Luke Holland with moderate Feel (0.35 / 12 ms). Existing custom sample sessions and an explicitly saved Built-in drums selection are retained. If upgrading from an older session with no samples, Luke Holland supplies the default kit while keeping the saved pattern/mix. Pack switching keeps your groove, EQ/compression, pad mixer, MIDI map and feel controls; it replaces all sample slots, resets layer gains/fine tuning/root labels, and applies the pack's tom tuning.

Each mapped drum has velocity groups drawn from actual soft/medium/hard recordings where available. A hit selects one group and cycles through its alternate takes, rather than playing soft and hard recordings together. Snare accents also use the hardest group. Luke Holland hats/ride have alternate takes but no separate soft/medium/hard groups; Time Traveller closed hats and crash include two strengths. Layer 1 contains the dynamic bank. Layers 2–4 remain available for stacked sounds. Loading/clearing a custom WAV in Layer 1 replaces that pad's velocity bank; the other drums keep theirs.

Both packs have one rack-tom source: Rack Tom 2 reuses it tuned down five semitones. Room and overhead controls keep their current ambience behavior; the Luke Holland room/overhead WAVs and extra cymbal/snare articulations are included for manual layering, but are not separate automatic microphone buses. These mappings use the WAVs directly and do not reproduce Kontakt scripting.

Bundled WAV references and velocity banks are stored as portable `@pack/` paths in presets. You can move the whole extracted app folder and still load them. Custom sample/recording paths stay external. Pack loading happens in the background and commits only after decoding succeeds; an incomplete/broken pack leaves the current kit intact. Additional mapped packs can be installed as subfolders of `Drum Packs` with an `.avrxpack` manifest; restart to refresh the selector.

## Human groove and feel

On **Groove Player**, set **Feel** (0–1) and **Timing** (0–25 ms). Feel changes hit strength using small approximately normal deviations, common bar energy and beat accents for hats/ride. Snare timing leans later, with smaller delays for the other drums. Timing controls the scale of those offsets; Feel scales both timing and velocity variation. Try Feel 0.25–0.45 with Timing 8–12 ms. Zero Feel retains the exact stored velocities/grid; round-robin sample variation remains active.

This is a repeatable musical heuristic, not a model fitted to human performance measurements. It does not invent notes or regenerate your pattern. Timings are delayed from the grid, bounded by the current step length, so the transport/metronome/bar duration do not drift. Velocity changes can select softer/harder recordings. The same pattern/seed gives the same timing and velocity across loops, with cyclic audio take variation. MIDI drag-out includes the same human timing and velocities; piano-roll rectangles still show the underlying editable grid. Incoming live MIDI uses the played velocities and dynamic banks without this sequence-only timing adjustment. Presets and last-session restore save Feel, Timing and the velocity banks.

## Run and route audio

1. Close the previous app, extract this ZIP into a new folder, and run `Standalone/AVRX GROOVE.exe`. Visual Studio is not required.
2. Open **Settings** and choose your audio interface/input/output devices and enabled channels. The build includes Windows Audio and ASIO support; ASIO requires the interface's installed driver. Available device types depend on the PC.
3. Choose sample rate and buffer size to suit the interface. 48 kHz is a useful starting point for NAM. Device settings are saved when you close the Standalone.
4. For guitar, connect to the interface's instrument input, then choose **Active input 1** or **2** on the Guitar tab. These refer to the ordered enabled channels, not necessarily the physical socket numbers. Check the input meter before recording.

Monitoring starts off. Enable it intentionally and use headphones or an appropriate interface output. If you use interface direct monitoring, keep AVRX monitoring off to avoid hearing the signal twice. Stop a take before changing device/routing settings; routing controls are disabled during recording. In a DAW, use the DAW's routing rather than the Standalone device manager.

## Interactive drum studio

The opening Drum Engine places performance audio beside an original photorealistic drum-kit view, with the groove piano roll beneath them. Click an instrument/hotspot to select and audition it; double-click to open its Sound Lab. Closed and open hi-hat are separate voices on the same physical hat in the artwork. The picture is visual artwork, not a bundled acoustic sample library. Sound still comes from your WAV layers or the prototype's synthesized fallback voices.

The sidebar opens Drum Engine, Groove Player, Sound Lab, Guitar, Analyse, Recorder, Mix Console and Settings. Reference/Room/Overhead levels are on the Drum Engine sidebar. The wider 1280 x 900 design scales to fit the primary display when the app opens.

## Layer drum samples

The nine-pad kit has Kick, Snare, Closed Hat, Open Hat, Rack Tom 1, Rack Tom 2, Floor Tom, Crash and Ride. Crash/ride have synthesized fallback sounds and support the same four WAV sample layers, tuning, gain, mute and editable MIDI mapping as the other drums. They feed the cymbal/overhead bus.

1. Open **Sound Lab**, select a pad and choose **Layer 1-4**.
2. Click **Load WAV**, drop a WAV directly onto a pad, or drop it onto the selected layer waveform. The Sound Lab page treats drops as drum one-shots, not reference tracks.
3. Choose another layer and load another sample. All loaded layers sound together on each hit.
4. Adjust **Layer Level**, **Pad Level**, **Mute pad** and the numeric **MIDI Note**. Click a pad to audition it. Layer level is captured when the next hit starts.
5. The selected layer waveform shows its filename, length and audio peaks. Click the waveform to audition the whole pad/layer stack. **Clear layer** removes only the selected layer. When all layers are empty, the pad uses its built-in synthesized drum.

Use mono/stereo WAV one-shots up to 10 seconds and 192 kHz. Layers keep their original start offsets; there is no automatic transient alignment, sample trimming, velocity switching or round robin. Each hit restarts the pad's voices. Invalid files retain the previous sound. There is no automatic open/closed-hat choking yet.

## Shape each drum

Select a pad on **Sound Lab**. Its layer stack feeds **CONSOLE EQ**, then **FET COMP**, then Pad Level and the drum ambience buses. Each of the nine drums has independent settings. EQ and compression start bypassed; turn on **EQ on** or **Comp on** to hear them.

- Four EQ bands have frequency and +/-15 dB gain. Low/high bands switch between shelf and bell; low-mid/high-mid have Width/Q controls. Enable High pass to remove low frequencies. EQ Blend mixes the filtered and original pad signal.
- Compression offers Input drive, Threshold, Attack (0.02-0.8 ms), Release (50-1100 ms), Output gain and 4:1/8:1/12:1/20:1 ratios. The gain-reduction bar shows attenuation. Stereo channels share the detector.
- **Parallel Mix** at 0% is the uncompressed post-EQ sound; 100% is fully compressed. Intermediate settings combine the two. Adjust Output to balance loudness when comparing.
- **Reset strip** restores only the selected drum's sound-shaping settings. Samples, tuning and the pattern remain available.

Controls take inspiration from console EQ and fast FET compressors. Current processing uses digital biquad filters and a peak compressor; detailed SSL/1176 circuit modelling is deferred. These controls affect drum audio, not reference audio or guitar. Drum processing settings are included in presets and last-session restore. Saved circuit references are in FUTURE_REFERENCES.md.

## Tune drums to the song

**Semitones** shifts the selected pad by -24 to +24 semitones. **Fine cents** adds -100 to +100 cents. All layers in that pad are tuned together. Imported samples are pitch shifted by changing playback speed, so their duration changes too. Tonal synthesized kick/toms also change pitch; noise-based drum sounds do not have a reliable musical fundamental.

To match a key, set **Root** to the sample's original pitch class, choose the song's **Key**, and click **Match song key**. This sets the nearest semitone shift within an octave. The root defaults to unknown: AVRX does not automatically determine a drum sample's pitch. Set the root by ear or from the sample's metadata. Adjust octave/fine tuning afterward if needed. Matching the root note is a tuning aid, not automatic scale analysis.

## Drum piano roll, meter and divisions

- Choose **1 through 16 bars**. The initial loop is four bars. Use the horizontal scrollbar to move through it; row labels stay fixed.
- Choose **4/4, 3/4, 5/4, 6/8, 7/8, 9/8 or 12/8**.
- Choose **quarter, eighth, sixteenth or thirty-second notes**, or **eighth/sixteenth triplets**. A division that cannot evenly fit the chosen meter is rejected and the controls revert to the prior valid configuration.
- Click empty space to add a drum note; click an existing note to select it. Drag a note horizontally to change its snapped timing or vertically to move it to another drum lane. Right-click or double-click deletes a note. Shift-drag vertically changes its velocity; the bottom velocity lane also adjusts existing notes. The playhead is a vertical line. Notes use percussive one-shot playback with short MIDI gates, so note-length resizing is not provided.
- The continuous grid shows bar/beat lines, coloured note rectangles and a collapsed piano keyboard labelled with each drum/MIDI pitch. Lanes sort by the current MIDI note number; changing mappings can reorder them. This is a drum piano roll, not a melodic 128-note editor. Dragging onto an occupied position replaces that hit; there is no multiple selection or undo.
- Changing resolution remaps hits by musical time. A coarser grid can merge hits. Reducing length can discard later hits; extending a loop repeats its existing content. There is no undo yet.
- Swing applies to pairs of straight eighth/sixteenth/thirty-second steps and preserves bar length, including odd meters. Triplet/quarter grids ignore Swing.
- **Run groove** controls drums; **Default pattern** restores a basic pattern across the selected length without removing your samples or mix settings.

The clock is internal rather than following a DAW's transport/tempo. Change Tempo manually or load reference audio to estimate it.

## Audio drag-in and analysis

Drop one audio file onto the opening **Drum Engine** page or its waveform, or use **Analyse audio**, to estimate tempo and generate a kick/snare/closed-hat accompaniment across the current loop. Drops on Drum Engine stay on Drum Engine and populate its waveform; hidden Samples pads cannot intercept them. Drops on Sound Lab load the selected/pad layer instead. The separate Audio page remains available for detailed analysis controls. Toms remain manually editable.

The opening Drum Engine page and the Audio page show the entire decoded waveform, a playback cursor, the filename/duration and detected attacks as blue lines. Click the waveform to seek the source; seeking does not reposition the drum clock. The display remains available for short/silent files that cannot yield a groove. Stereo display includes peaks from both channels.

**Detection strength** ranges from 0.5 to 3. Higher values include softer attacks; lower values focus on stronger ones. Change it, then click **Re-analyse** to rebuild the pattern from the same file. Re-analysis stops/rewinds playback and replaces the current pattern; original audio is unchanged. The setting is shared with Guitar live-follow, where it takes effect immediately. Tempo comparison now tolerates small transient-timing variations, but full-mix transcription is still approximate.

WAV, AIFF, FLAC, OGG and MP3 reference readers are included. Analysis requires at least 4 seconds of rhythmic audio and uses at most the first 3 minutes, mono/stereo, up to 192 kHz. It combines energy rises, positive spectral flux over low/mid/high frequency ranges and repeating timing, not exact drum transcription or source separation. Clear steady loops work best; full mixes, pickups, changing tempo and half/double-time ambiguity can produce poor results.

**Play together** starts the groove at its first step and source audio at the first detected transient. **Play source / Pause source** previews the reference separately. **Stop / rewind** stops both. Source audio keeps its original speed and plays once; generated drums keep looping. Changing tempo or swing manually can cause drift. Invalid references retain prior audio; decoded silent/short audio can be previewed with the default groove.

Room remains generated stereo reverb and Overheads remains a cymbal-focused filtered bus. They are not recorded microphone channels. Reference audio and guitar are excluded from these drum buses.

## Mixer

Open **Mix Console** for nine metal drum channel strips with level, stereo balance, mute, solo and segmented peak meters. Each strip also has EQ bypass, four EQ gain knobs, compressor bypass, Input drive, parallel Mix and gain-reduction readout. Click the drum name to open Sound Lab for frequency, width/Q, attack, release, ratio and other detailed controls. These shortcuts share the same processing settings as Sound Lab. Drum solo isolates selected drums within the kit; multiple solos can be active. Mute takes precedence. Meters follow drum shaping, pad level and Drum Master; they exclude ambience returns. Pan is stereo balance: centre preserves both channels, either extreme silences the opposite channel.

Switch to **Recorder & buses** for the four recorder tracks, Reference level, Room, Overheads and Drum Master. Recorder track mute/solo/pan/level share the controls on Recorder. Recorder solo operates within the recorder tracks independently of drum solo. Drum Master controls drums and their ambience, not guitar, reference or recorder tracks. Values are linear gain (1.00 is unity); double-click a pan control to centre it. Mixer changes are included in presets and last-session restore.

**Play / Space** on Mixer starts recorder tracks plus the drum groove, and stops current transport/recording. Reference playback starts separately on Analyse/Drums. MIDI drag excludes muted and non-soloed drums when a drum solo is active. Pan and level are audio controls and are not embedded in the MIDI file.

## Drag MIDI to a DAW

Choose **Logic / General MIDI** or **External GM (channel 10)**, then set custom per-pad notes if needed. Selecting a map resets the numeric notes.

Press and drag **DRAG MIDI TO DAW** onto a DAW MIDI/instrument track or onto a folder in Explorer. A standard MIDI file is created for the full current loop, with tempo, meter, note division/swing, velocities, mapping and note-offs. It has a tempo track plus a single combined drum-kit track (format 1, 960 PPQ). Muted pads are excluded. Source audio is not included.

The MIDI file triggers the destination instrument. It does **not** embed your samples, layer gains, pitch tuning, EQ, compression, room or overhead settings; recreate those in the destination drum instrument if you need matching sounds. If a DAW adjusts/ignores tempo on drag-in, set its tempo to AVRX's BPM. Native file drag must be accepted by that application.

Dragging works between applications on the **same computer**. For Logic on a separate Mac, drag to an Explorer folder and transfer the `.mid` file to that Mac. These binaries are Windows builds, not Mac plugins. Logic can import standard MIDI files; set Drum Kit Designer to GM mapping or map Drum Machine Designer pads to the note numbers. [Apple MIDI import reference](https://support.apple.com/guide/logicpro/standard-midi-files-lgcpdf6a3851/mac).

Default notes are Kick 36, Snare 38, Closed Hat 42, Open Hat 46, Rack Tom 1 48, Rack Tom 2 47, Floor Tom 41, Crash 49 and Ride 51. Logic uses channel 1; External GM uses channel 10. Generated drag files stay in `%TEMP%/AVRX_GROOVE_MIDI` so the receiving app can copy/read them. The UI shows the cache path after a drag attempt. No drum WAV-stem export remains in this version.

## Capture controls and pickup input calibration

The **Guitar** page now has **Drive**, **Bass**, **Mid**, **Treble**, **Output**, **Gate**, **Threshold** and **Release** controls. Drive adjusts level into NAM (-24 to +24 dB); Output trims the processed sound (-24 to +12 dB). Tone controls apply a post-capture 90 Hz bass shelf, 1 kHz mid bell and 6.5 kHz treble shelf, each +/-12 dB. They shape the fixed captured sound; they do not move the original amp's physical knob settings inside the trained model. Double-click a knob to reset it. These controls work with direct NAM and the hosted VST3 option.

The gate is off by default. Enable its Gate toggle and raise Threshold until idle pickup noise is reduced without cutting soft notes. Threshold ranges from -80 to 0 dBFS, Release from 10 to 500 ms; attack is 1 ms, hold 30 ms, with closing hysteresis. It gates audio at its block position. Put it after Capture to suppress model-generated noise, or before Capture to clean incoming guitar. The toggle shows open/closed. Input Trim precedes the chain. Bypass rig bypasses all blocks. Dry DI recording/live-follow use the ungated signal after Input Trim.

Select **Single-coil**, **Passive humbucker** or **Active pickup** at the top of Guitar to start a five-second calibration. Play ordinary chords and picking during that check. AVRX measures the untrimmed input RMS and peak, aims for approximately -24 dBFS RMS, and limits gain to leave peak headroom. The profile caps automatic gain at 4x/3x/2x respectively; these are conservative starting limits, not manufacturer pickup measurements. Silence/very weak input is rejected and your previous trim is retained. **Recalibrate** repeats the check. Calibration stops when a take starts.

**Input Trim remains manually adjustable** from 0 to 4x. Turning it switches the selector to Manual and cancels automatic calibration; Drive remains separately adjustable. Auto calibration is a one-time level adjustment, not continuous gain riding. It preserves playing dynamics after the check. It is not physical dBu/interface calibration and cannot infer the exact voltage represented by your interface's full-scale digital input. No pickup type alone can provide that measurement. Monitor remains off until you enable it.

Drive/tone/output/gate are printed into **NAM sound recording**, before Monitor level. Dry DI excludes them. Presets and automatic last-session restore save all controls, pickup profile and the resulting input trim; recalling a preset does not restart calibration.

## NAM guitar processing

AVRX now embeds NeuralAmpModelerCore, so a separate NAM VST3 is optional. On **Guitar**, click **Load .nam capture** or drag a `.nam` file into the app. Compatible mono input/output Linear, LSTM, WaveNet and slimmable models load directly. The source download includes NAM Core 0.6.0, Eigen 3.4.0 and nlohmann JSON 3.12.0 from the folders you supplied; no source fetch is required at build time. See `Licenses` for notices. Source builds now use C++20.

Your supplied second Mesa file, **90sDualRec-FullRig-Red-Modn-SweetSpot+808.nam**, is included unchanged in `Captures` and becomes the default when no custom capture is restored. Its metadata identifies an amp/cab capture, so AVRX adds no extra cabinet IR. Keep `Captures` beside `Standalone`. Named presets and last-session restore keep custom capture paths; the bundled default uses portable `@capture/` references so moving the entire app folder works.

This capture requires **48000 Hz**. Select 48 kHz in Settings. On startup or preset recall, a capture with a mismatched rate remains selected but processing/processed recording are disabled. Switching the device to the correct rate re-enables it. For manual loads, a mismatch leaves the previous amp intact and reports the required rate. Other captures use their declared training rate; models without rate metadata are assumed to require 48 kHz. Automatic resampling of neural models is not implemented. Core models that explicitly support arbitrary sample rates may adapt themselves.

Enable **Monitor guitar** to listen, or **Bypass NAM** for dry input. Input Gain affects the input before the model; Guitar Monitor Level affects listening volume, not the recorded WAV. Monitoring and transport remain stopped after preset recall/startup. Use **NAM sound recording** to print the processed capture into the take, even with monitoring off. Bypass/model changes are blocked while recording; **Dry DI recording** saves the clean input. Printed takes play directly and keep their sound after changing/unloading the capture; they are not processed twice. Existing DI clips are not re-amped by this feature.

**Choose NAM VST3** retains the previous external-plugin option and opens that plugin's controls, where cabinet IRs and its other controls remain available. Loading a direct capture activates the embedded engine; selecting a VST3 activates the hosted engine. External VST3/capture state remains session-only, while direct `.nam` paths and AVRX bypass are included in presets. Direct capture loading/prewarming can briefly pause the interface. Captures are limited to 32 MB and mono input/output. AVRX does not train new captures or add an IR loader/physical dBu calibration in this version.

The offline suite checks exact known-model processing, several upstream neural examples, the supplied Mesa capture, processed recording without monitoring, rate mismatch/recovery, malformed-capture retention, Unicode paths, preset recall and drag/drop. Live interface latency/tone remain hardware checks. [NAM Core project](https://github.com/sdatkinson/NeuralAmpModelerCore).

## Record a guitar take - up to 60 seconds

1. Configure Settings and verify the Guitar input meter.
2. **NAM sound recording** is selected by default. Load a direct .nam capture (or use NAM VST3 and its capture/IR controls) first, and turn AVRX bypass off. This records the processed NAM output into the WAV. Choose **Dry DI recording** if you intentionally want clean input or do not have NAM loaded. A processed take is rejected if NAM is unavailable/bypassed.
3. Set your recording folder once in **Settings -> Set recording folder**. Choose **Pre-roll: Off / 1 bar / 2 bars** (default: 1 bar). Click **RECORD / Num 3** or press numpad **3**. The take saves automatically; no folder/save prompt appears. The metronome counts in at the current tempo/meter, then capture starts. Off records immediately.
4. Play. A mono, 24-bit WAV is written at the active device sample rate. The counter reaches 60.0 seconds and recording stops automatically. **Stop recording** ends it earlier.
5. After stopping, **Play take / Space** plays the saved WAV directly. A NAM-sound take retains its recorded tone and is not processed through NAM twice. The saved status identifies NAM sound versus Dry DI. Previously saved dry takes stay dry; this release does not re-amp existing DI files.
6. Open Recorder to see the accumulating take waveform and previously recorded timeline clips. All takes remain visible after stopping. The saved file path appears in the status (hover for the full path). Existing files are preserved by choosing a unique filename. Drop the saved WAV outside the pads later if you want to preview/analyse it.

Dry DI includes AVRX Input Gain but is before NAM. Processed mode records the first NAM output channel, before Guitar Monitor Level. Drums, reference audio and drum ambience are not recorded into the guitar take. The count-in and metronome are excluded from the guitar file. The 60-second limit counts captured audio after pre-roll, not the count-in. Play take previews the latest take; every completed take also stays on the armed Recorder lane. The Recorder page adds multiple clips and audio lanes/overdubbing. Punch-in, automatic latency compensation and editing/trimming a recorded file are not implemented. If the disk writer cannot keep up, recording stops with an error rather than silently dropping blocks.

## Live accompaniment and metronome

1. Set **Tempo**, **time signature** and **note division** on Drum Engine. Choose your guitar input in Settings/Guitar and verify the waveform.
2. Turn on **Metronome** and play to it. Its clicks follow the denominator of the selected meter (quarter notes in 4/4, eighth notes in 7/8), with a higher downbeat click. It works with the drum groove stopped as well.
3. Enable **Live follow** on Guitar. It starts the drum clock and clears kick/snare/closed-hat steps to learn. Play for a bar; the detected strum accents become kick hits, with generated backbeat snare and timekeeping hats. Pattern updates are applied once a bar by the UI, without restarting the clock, and repeated over the configured loop. Stronger attacks receive stronger kick velocities.
4. Adjust **Detection strength** if soft attacks are missed or too many attacks are found. Live-follow reads the selected dry guitar input before NAM/drums/clicks, so generated sound does not feed its detector internally. The status shows the detected attack count. Monitoring is optional.
5. Disable Live follow to keep and manually edit the latest groove. **Backing groove** controls playback. Toms/open hat, sample layers, tuning and mix remain in place. Turning Live follow on again replaces the first three drum rows; there is no undo.

This is a fixed-tempo accompaniment prototype: it tracks attack placement/intensity, not automatic tempo changes or song structure. The player should follow the selected clock. Sustained notes, distorted/noisy inputs, off-grid/free-time playing and chords with weak attacks can reduce detection quality. It is not an AI drummer or exact transcription. Detection can run while recording a take; pre-roll controls capture, not the live drum transport. Keep tempo/meter steady during a count-in.

## Multitrack recorder

Open **Recorder** for four audio lanes plus the existing live drum pattern.

1. Configure the guitar input/NAM capture on Guitar and audio interface in Settings. Each take records one selected input as mono, optionally after NAM; recordings are up to 60 seconds each. This is sequential overdubbing rather than simultaneous capture of four hardware inputs.
2. Arm a lane, select **NAM sound** or **Dry DI**, and choose the count-in. NAM sound is the default and requires the loaded, non-bypassed NAM plugin/capture.
3. Click the timeline to choose the recording/playback cursor. New recordings may start from 0 through 3540 seconds (59 minutes); a full minute fits within the one-hour timeline. Click **RECORD armed lane / Num 3** or press numpad **3**. The take saves automatically to the recording folder set in Settings.
4. During the count-in, audio lanes and the drum pattern wait. Afterward existing clips play while the selected input is recorded, including prior clips on the armed lane. The lane displays the accumulating waveform and count-in/take status. Drums/other lanes/reference/metronome are not printed into the guitar file.
5. **Stop** or Space finishes the take and adds it to that lane at the capture-start cursor. The minute limit also stops automatically. A new take preserves every previous timeline clip and WAV. Cancelling before capture starts keeps the earlier clips and start offsets.
6. Arm another lane and repeat. Use level, pan, mute and solo to mix the four audio lanes. Solo affects audio lanes; the drum pattern has its separate Run/Master controls. The mix is limited at the output if loud lanes sum above full scale.
7. **Import audio**, or drop a file directly on a lane, adds a mono/stereo clip at the cursor. Supported formats are the reference readers, up to 192 kHz and the first three minutes. **Lane start (seconds)** moves the whole selected lane from 0 through 3540 seconds. **Clear** unloads that lane's timeline clips without deleting its WAV files.
8. **Play / Space** plays all audio lanes plus the live drum pattern; Pause preserves the cursor. **Rewind** returns to zero. The drum clock uses the timeline position when starting/seeking, including swing. Audio clips keep their original speed; no time stretching is applied. Stop reference/take preview modes when switching into multitrack playback.

Presets and last-session restore retain lane file references, offsets and mixer settings. Keep the individual WAVs in their saved locations. This is a basic four-lane recorder: multi-clip editing, punch-in, crossfades, latency compensation and mixdown export remain future work.

## Recorder timeline

Recorder displays four coloured track lanes, clip regions with filename headers, audio waveforms, a seconds ruler, timeline grid and a playhead spanning the lanes. Clip widths/positions reflect their duration and start offsets. Click the ruler/lane area to seek. Each lane currently holds one audio clip; visual DAW styling does not add split, trim, multiple clips, automation or timeline drag editing. Use Lane start to move a clip and the existing import/record controls to replace it.

## Recording folder and shortcuts

In **Settings**, click **Set recording folder** once. Guitar and Recorder share it. The choice is saved immediately in `%APPDATA%/AVRX/GROOVE/recording-folder.txt` and restored on app restart. The default is your Windows Documents folder's **AVRX GROOVE Recordings** subfolder (including a redirected/OneDrive Documents folder if Windows uses one); it is created when needed.

With AVRX focused and Num Lock enabled, numpad **3** starts a Guitar take on Guitar. On any other page, it starts the armed Recorder lane and opens Recorder. Record mode and count-in use that destination page's current controls. Select Dry DI if NAM is not loaded. While recording, **Space** stops capture and saves/imports the take. Held record/Space keys are suppressed; release before starting another take. Top-row 3 is not a recording shortcut. Finish typing in a numeric/text field before using shortcuts.

Buttons and shortcuts use unique timestamped names such as `Guitar_20261012_210000.wav` or `Track3_20261012_210000.wav`, adding a suffix on collisions. Previous WAVs are kept. A missing/unwritable folder reports a recording error; choose another location in Settings. The folder button is disabled during capture. There are no per-take save dialogs.

## Groove player and loader

Open **Groove Player**. Choose a starter (Straight Rock, Half-Time, Shuffle, Tom Fill or Sparse), **Load MIDI groove**, or **Browse groove folder**. Folder browsing searches subfolders for `.mid`/`.midi`, displaying up to 2,000 files. You can drop MIDI onto the app to open it here, or drop a MIDI folder onto this page. Audio-file analysis remains on Drum Engine/Analyse.

Selecting/loading a groove stops playback and replaces the drum pattern, meter, length, grid and tempo. Samples, tuning and mix settings remain. Click **Play groove / Space** to loop the current groove through your kit; **Stop groove** stops the drum clock. Groove Player playback excludes reference audio/recorder tracks. Choose Preview bar to inspect any bar. Edit the loaded pattern on Drum Engine or drag its MIDI to a DAW/folder. Tempo now supports 30-300 BPM. Selecting another groove overwrites unsaved pattern edits; there is no undo. Loaded patterns are saved in presets and last-session restore. Groove-folder browsing and preview-bar selection remain session-only.

MIDI loading supports standard formats 0/1 with PPQ timing, a single steady tempo/meter, up to 16 bars and files up to 2 MB. If tempo is absent, the current tempo is used; absent meter defaults to 4/4. Notes use your current pad map first, then General MIDI kick/snare/hat/tom/cymbal aliases; unrelated pitches are counted as ignored. All MIDI channels/tracks are considered. Use drum-groove files rather than complete mixed-instrument song MIDI.

Timing snaps to the closest supported sixteenth/thirty-second/triplet grid. Notes colliding in one drum/grid cell retain the stronger velocity and are counted as merged. Note lengths do not change one-shot playback. This version does not preserve arbitrary MIDI microtiming, changing tempo/meter, SMPTE timing or format-2 independent sequences. Unsupported files retain the current groove. Loading is blocked during recording/audio analysis.

## Spacebar transport

With the AVRX window focused, Space stops an active take or pauses active playback/drums. When stopped, it starts the transport for the current page: drum groove on Drum Engine/Settings, latest take on Guitar, reference + groove on Analyse, audio lanes + groove on Recorder/Mixer, or the drum groove alone on Groove Player. Holding Space does not repeatedly toggle playback. Typing into a numeric/text edit field keeps normal text input; finish editing before using the shortcut. NAM's separate native window uses its own keyboard controls.

## Settings/session storage and testing

Standalone audio routing is saved under `%APPDATA%/AVRX/GROOVE/audio-routing.xml` and the recording destination is saved separately.

## Save a preset and keep your session

Use **Save preset** in the top-right header, choose a name/location once, and save an `.avrxpreset` file. **Load preset** recalls it from any page. Saving the same name updates that preset using the normal overwrite prompt.

Presets contain the full piano-roll pattern, tempo/swing/master level, bars/time signature/grid, MIDI note/channel map, all four WAV layers per pad and their gains, tuning/root notes, drum mute/solo/pan/level, every EQ/compression control, room/overheads, four recorder lane file references/offsets/mixer values, reference-audio and last-take file references, guitar input/gains, recording modes/count-in/armed lane, metronome and detection strength. Loading reference audio restores its waveform without regenerating or overwriting your saved groove/tempo.

The standalone also saves the last session every 30 seconds when recording/loading has finished, and on normal exit. It restores `%APPDATA%/AVRX/GROOVE/last-session.avrxpreset` when reopened. You do not have to save a named preset every time you close. A forced shutdown/crash can lose changes since the last successful automatic save. Named presets remain separate from this automatic file.

Audio is referenced by its file path, not bundled into presets. Keep samples and recorded WAVs in their original locations. Missing/unreadable files are counted in the header; available layers still load, and the built-in sound remains available when no WAV layer is loaded. Missing sample/lane paths survive subsequent saves so moving those files back restores them. Re-load moved files manually on Sound Lab/Recorder and save again. Loading many samples or a long reference may briefly pause the interface while it reads them.

Playback, recording, monitoring and live-follow are stopped when a preset is opened or the app restarts. Direct `.nam` capture paths and bypass are included; external NAM VST3 state is not included. NAM-printed WAV takes retain their processed sound. Groove library folder, selected page/pad, song-key menu, scroll/playhead positions and open NAM windows are not included. Audio device routing and recording folder are global preferences, separate from named presets.

Save/Load is disabled while recording, analysing or loading audio. Invalid/unsupported preset files leave the current kit intact. Presets use versioned XML and atomic file replacement; do not edit them while the app is saving.

`VALIDATION.md` records build/test evidence and remaining interactive checks. Native DAW drops, actual interface recording/monitoring and user NAM captures are not claimed as tested.

## Build the source

Use Visual Studio with Desktop development with C++, x64 MSVC, Windows SDK and CMake tools, plus a local JUCE source SDK. Both C and CXX are enabled; JUCE is included with `add_subdirectory`, not FetchContent.

This PC preset uses Visual Studio 2026 and JUCE 9.0.4 at `C:/AVRX_GROOVE/JUCE-master/JUCE-master`:

```powershell
cmake --preset windows-local-vs2026
cmake --build --preset release-local --target AVRX_GROOVE_Standalone --parallel 1
```

The app output is `build-vs2026/AVRX_GROOVE_artefacts/Release/Standalone/AVRX GROOVE.exe`. The DAW plugin is disabled by default (`AVRX_BUILD_VST3=OFF`). Enable that option explicitly if it is needed in a future build. The Standalone now uses a custom JUCE application/device manager to expose in-app routing and guitar input. Windows ASIO and VST3 hosting are enabled.

The generic Visual Studio 2022 preset/root CMake default use `C:/JUCE`; override the configurable SDK path as needed:

```powershell
cmake --preset windows-vs2022 -DJUCE_PATH="C:/JUCE"
cmake --build --preset release --parallel 1
```

JUCE_PATH must contain `CMakeLists.txt` and `modules`. CMake 3.22+ is required; the Visual Studio 2026 generator needs a version supporting it. JUCE 9.0.4 is the validated version; JUCE 8 was not built.

To reset, use Visual Studio's **Delete Cache and Reconfigure**, or close it and delete only generated `build`, `build-vs2026`, `out` and `.vs` folders inside this extracted project. Keep Source/Tests, CMake files and the JUCE SDK.

```powershell
cmake --preset windows-local-vs2026 -DAVRX_BUILD_TESTS=ON
cmake --build --preset release-local --target AVRX_AnalysisTests --parallel 1
ctest --test-dir build-vs2026 -C Release --output-on-failure
```

The automated test creates temporary WAVs, a 60-second simulated-input recording and preview images, and checks the installed NAM plugin if available. It does not send audio to speakers.

JUCE is separately licensed; its source and external NAM VST3 binaries are not bundled. The embedded NAM Core and its source dependencies are included with their notices in `Licenses`. A commercial JUCE license may be required for your use; consult JUCE's `LICENSE.md` and dependency notices.

## Future polished build

ReWire is recorded as a future compatibility investigation in `ROADMAP.md`. It is not included in this build.
