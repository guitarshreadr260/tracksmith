# AVRX GROOVE — saved modelling references

Saved 12 October 2026 at the user's request. Keep these for later modelling work; they do not change the current build scope.

- [SSL schematic and drawings index — KA Electronics](https://www.ka-electronics.com/images/SSL/ssl_drawings_index.htm). Index includes channel equalizer and channel dynamics drawings. Later: identify the specific EQ circuit/revision to study.
- [1176 Compressor/Limiter Schematic — Analog Classics](https://analogclassics.com/wp-content/uploads/2021/11/1176-Compressor-Limiter-Schematic.pdf). One-page schematic. Later: verify its circuit revision before choosing a modelling approach.

The current EQ and compressor use functional digital processing. Detailed circuit modelling remains deferred, as requested.

Direct NAM integration: https://github.com/sdatkinson/neural-amp-modeler (training/export); https://github.com/sdatkinson/NeuralAmpModelerCore (C++ playback engine). Core source and Eigen dependency are required before implementation/build validation.

## Guitar block categories

[Neural DSP device list](https://neuraldsp.com/device-list): user-supplied reference for effect categories and explaining what each device does. AVRX uses its own stock algorithms; this list does not supply Neural DSP models or authorize copying them. Future menu categories: dynamics, drive, amp/capture, cabinet/IR, EQ/filter, modulation, pitch, delay, reverb and utility.

The first modular rig is one serial chain across two rows, with editable Gate / Drive / NAM Capture / Tone EQ / Digital Delay / Plate-style Reverb / Output blocks. Detailed circuit modelling and separate preamp/power-amp stages remain deferred.

## Added effects and capture discovery

User-supplied [TONE3000 API example repository](https://github.com/tone-3000/api) and [official API specification](https://www.tone3000.com/api) informed the integrated Select-flow client. This prototype uses PKCE and Windows protected storage, asks for a user-owned publishable key and requests Amp + Cab NAM A1. No credentials are shipped.

[Strymon BigSky Bloom description](https://www.strymon.net/product/bigsky-plugin/): swelling diffused ambience used as a behavioral reference for the AVRX stock ambient delay. This is not a BigSky algorithm or component model. The 808-style overdrive and shimmer are also stock approximations; circuit modelling remains deferred.
