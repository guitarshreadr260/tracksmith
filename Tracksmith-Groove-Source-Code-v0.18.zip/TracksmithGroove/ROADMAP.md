# AVRX GROOVE â€” future polished build

## ReWire compatibility investigation

User request: consider ReWire support in a future polished build; exclude it from the current build.

ReWire is discontinued. Reason Studios states that Reason 11 and later do not feature ReWire: [official compatibility note](https://help.reasonstudios.com/hc/en-us/articles/360002215514-Reason-doesn-t-work-in-ReWire-mode-with-my-DAW). Its support category is titled [ReWire (discontinued)](https://help.reasonstudios.com/hc/en-us/sections/360000648153-ReWire-discontinued).

Before committing to implementation, identify the intended DAW/version, operating system, host/device role, SDK availability/licensing and an actual supported host for testing. Treat this as feasibility work, not a promised shipping feature. Investigate VST3 host tempo/transport synchronization and multiple audio outputs as current integration options for the same workflow. Those improvements are also future work, not implemented by this page-layout update.

Current version 0.12 contains no ReWire dependency, controls or implementation.

## Proposed groove/feel analysis upgrade

User supplied a multiband crossover -> band-specific detectors -> RMS/peak ratio/spectral flux -> confidence/grid deviation -> humanized MIDI diagram. Version 0.9 begins imported-file spectral-flux support and retains per-onset strength/grid-deviation metadata. The full probability/feel engine, measured microtiming playback and MIDI output, beat/downbeat estimation and live multiband analysis remain future work.

- Extract attack evidence separately across frequency bands, with spectral flux plus loudness/envelope features and adaptive thresholds. Band energy is evidence, not an instrument identity: kick, bass, guitar, snare and cymbals overlap.
- Estimate tempo, beat phase and downbeat explicitly before measuring each attack's signed deviation from the closest grid position. Preserve onset timestamps and strength; avoid immediately collapsing everything into sixteen fixed slots.
- Store per-hit microtiming/velocity and propagate those into playback and MIDI drag. An adjustable Feel amount should blend toward measured performance timing rather than apply random jitter. Confidence should suppress uncertain events and expose unreliable tempo/half-time guesses.
- Use separate approaches for imported-audio analysis and live input. A long linear-phase FIR crossover adds delay, which must be accounted for; do not assume it is required for good transient analysis. FFT-band features or low-latency filters are candidates, with window/filter delay calibrated.
- For guitar input, infer accompaniment from strum accents rather than label low/mid/high energy as literal kick/snare/hat sounds.
- Validate with known onset timestamps, intentional ahead/behind-grid timing, varied dynamics, drums/guitar/full mixes, noise, compound meters and tempo changes. Measure onset precision/recall, timing error and BPM/beat-phase accuracy; evaluate musical results by listening.

Primary references: [Librosa spectral-flux onset strength](https://librosa.org/doc/0.10.2/generated/librosa.onset.onset_strength.html), [SciPy linear-phase FIR design and delay](https://docs.scipy.org/doc/scipy/reference/generated/scipy.signal.firwin.html).

## Later circuit modelling

Detailed SSL-style EQ and 1176-style compressor modelling is deferred at the user’s request. See [saved references](FUTURE_REFERENCES.md) for the supplied schematic links. Current channel strips provide functional digital filters and stereo-linked peak compression.

## Standalone focus

The user requested a standalone app for the current release. Optional DAW-plugin builds are disabled by default; NAM VST3 hosting remains part of the guitar workflow.

Version 0.12 adds named presets and automatic last-session restore. Future persistence work: portable audio bundles, NAM plugin/capture state, groove-library/UI selections and crash recovery during active recording.

Version 0.13 adds two selectable bundled WAV packs, dynamic velocity banks/round robin, portable bank presets and correlated human-feel controls shared by playback and MIDI drag-out. Direct NAM Core playback is pending source/dependency access; the current guitar engine still hosts NAM VST3.

Version 0.14 embeds NAM Core for direct mono .nam playback, processed recording and capture-path presets, with the supplied Mesa SweetSpot+808 default. Future NAM work: cabinet IR loader, calibrated input levels, neural resampling and optional model training integration.

Version 0.15 adds surrounding capture drive/tone/output controls, a hysteretic noise gate, measured five-second pickup-profile input adjustment and manual trim override. Physical interface dBu calibration and trained amp-knob interpolation remain future work.

Version 0.16 adds an eight-block, two-row serial guitar rig with contextual controls, move/bypass/remove, independent duplicated delay/reverb, stock digital delay and plate-style reverb, and preset persistence. Future: stereo/parallel branches, compressor, modulation, pitch, cabinet/IR loader and expanded FX categories. The saved Neural DSP device-list link is a terminology reference, not a source of proprietary algorithms. All 225 user-supplied GGD Rock grooves are now bundled with their groove-file source mapping. Original human microtiming, separate cymbal articulations and choke playback remain future enhancements.

## Version 0.17 follow-up

Sixteen compact interchangeable slots, stock 808 overdrive, octave shimmer, swelling ambient delay, block make-up gain, retained multiple recorder regions and TONE3000 Select-flow integration are implemented. Next: real-account API acceptance; A2 architecture support; richer tone attribution/artwork in the block; stereo/parallel rig branches; individual region movement, comping and fades. All existing WAVs are retained when recording; overlapping clips mix until explicitly cleared.
