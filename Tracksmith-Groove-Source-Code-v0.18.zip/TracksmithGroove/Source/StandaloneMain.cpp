#include "PluginProcessor.h"

class EditorHost final : public juce::Component
{
public:
    explicit EditorHost (std::unique_ptr<juce::AudioProcessorEditor> content) : editor (std::move (content))
    {
        float scale = 1;
        if (const auto* display = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay())
            scale = juce::jmin (1.0f, juce::jmin ((display->userArea.getWidth() - 40.0f) / editor->getWidth(), (display->userArea.getHeight() - 80.0f) / editor->getHeight()));
        scale = juce::jmax (0.4f, scale);
        addAndMakeVisible (*editor); editor->setTransform (juce::AffineTransform::scale (scale));
        setSize (static_cast<int> (std::ceil (editor->getWidth() * scale)), static_cast<int> (std::ceil (editor->getHeight() * scale)));
    }
private:
    std::unique_ptr<juce::AudioProcessorEditor> editor;
};

class GrooveWindow final : public juce::DocumentWindow, private juce::Timer
{
public:
    GrooveWindow() : DocumentWindow ("Tracksmith Groove", juce::Colour (0xff0b0c0e), DocumentWindow::allButtons), processor (std::make_unique<AvrxGrooveProcessor>())
    {
        setUsingNativeTitleBar (true);
        auto saved = juce::XmlDocument::parse (settingsFile());
        const auto error = devices.initialise (2, 2, saved.get(), true);
        if (error.isNotEmpty()) devices.initialise (0, 2, nullptr, true);
        if (auto* device = devices.getCurrentAudioDevice()) processor->guitar.prepare (device->getCurrentSampleRate(), device->getCurrentBufferSizeSamples());
        processor->recordingLocation.restore (recordingPreferences());
        const auto toneHome = recordingPreferences().getParentDirectory(); processor->tone3000.configure (toneHome.getChildFile ("tone3000-session.bin"), toneHome.getChildFile ("TONE3000 Captures"));
        processor->recordingLocationChanged = [this] { processor->recordingLocation.save (recordingPreferences()); };
        processor->packFolder = juce::File::getSpecialLocation (juce::File::currentExecutableFile).getParentDirectory().getParentDirectory().getChildFile ("Drum Packs");
        processor->captureFolder = processor->packFolder.getParentDirectory().getChildFile ("Captures");
        processor->grooveFolder = processor->packFolder.getParentDirectory().getChildFile ("Grooves");
        const bool restored = sessionFile().existsAsFile() && processor->loadPreset (sessionFile());
        bool customSamples = false; for (int n = 0; n < 9; ++n) for (int slot = 0; slot < 4; ++slot) customSamples |= processor->getKit()->layerFiles[static_cast<size_t> (n)][static_cast<size_t> (slot)] != juce::File();
        const auto defaultPack = processor->packFolder.getChildFile ("Chango Luke Holland/kit.avrxpack");
        if ((! restored || (! customSamples && processor->getKit()->packName.isEmpty())) && defaultPack.existsAsFile()) { processor->loadDrumPack (defaultPack); processor->waitForBackgroundWork(); if (! restored) processor->setHumanFeel (.35f, 12); }
        const auto defaultCapture = processor->captureFolder.getChildFile ("90sDualRec-FullRig-Red-Modn-SweetSpot+808.nam");
        if (processor->guitar.captureFile() == juce::File() && defaultCapture.existsAsFile()) processor->guitar.loadCapture (defaultCapture, true);
        processor->setDeviceManager (&devices);
        player.setProcessor (processor.get());
        devices.addAudioCallback (&player);
        devices.addMidiInputDeviceCallback ({}, &player);
        setContentOwned (new EditorHost (std::unique_ptr<juce::AudioProcessorEditor> (processor->createEditor())), true);
        setResizable (false, false);
        centreWithSize (getWidth(), getHeight()); setVisible (true); startTimer (30000);
    }
    ~GrooveWindow() override
    {
        stopTimer();
        clearContentComponent();
        processor->stopRecording();
        processor->waitForBackgroundWork(); processor->applyAnalysisTempo();
        devices.removeMidiInputDeviceCallback ({}, &player);
        devices.removeAudioCallback (&player); player.setProcessor (nullptr);
        processor->savePreset (sessionFile());
        if (auto state = devices.createStateXml())
        {
            settingsFile().getParentDirectory().createDirectory();
            state->writeTo (settingsFile());
        }
    }
    void closeButtonPressed() override { juce::JUCEApplication::getInstance()->systemRequestedQuit(); }
private:
    void timerCallback() override
    { const auto message = processor->presetStatus; processor->savePreset (sessionFile()); processor->presetStatus = message; }
    static juce::File sessionFile()
    { return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("AVRX/GROOVE/last-session.avrxpreset"); }
    static juce::File recordingPreferences()
    { return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("AVRX/GROOVE/recording-folder.txt"); }
    static juce::File settingsFile()
    { return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("AVRX/GROOVE/audio-routing.xml"); }
    std::unique_ptr<AvrxGrooveProcessor> processor;
    juce::AudioDeviceManager devices;
    juce::AudioProcessorPlayer player;
};

class GrooveApplication final : public juce::JUCEApplication
{
public:
    const juce::String getApplicationName() override { return "Tracksmith Groove"; }
    const juce::String getApplicationVersion() override { return "0.15.0"; }
    bool moreThanOneInstanceAllowed() override { return false; }
    void initialise (const juce::String&) override { window = std::make_unique<GrooveWindow>(); }
    void shutdown() override { window.reset(); }
    void systemRequestedQuit() override { quit(); }
    void anotherInstanceStarted (const juce::String&) override { if (window) window->toFront (true); }
private:
    std::unique_ptr<GrooveWindow> window;
};
START_JUCE_APPLICATION (GrooveApplication)
