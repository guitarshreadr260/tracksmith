# Tracksmith — selection and shortcuts build

Instrument tracks support box/Shift selection, group delete/move/resize, MIDI clipboard, transpose, nudge and velocity shortcuts. Right-click a track name in Edit or Mix for New/Delete. Open Shortcuts in the Arrangement toolbar for the key reference.

Extract the complete ZIP. Save and close the older app before opening Tracksmith.exe. Windows x64 and WebView2 required; keep Stock Plugins beside the application. Session format 9. Start with SELECTION-SHORTCUTS-GUIDE.md. Track deletion is not undoable; audio files remain on disk.

Earlier DAW features, piano roll and groove drops are included. Native mouse/hardware review and broader realtime reliability remain pending. Installer, custom UI and scanner improvements deferred. Tracksmith Groove stays separate; AVRX Drums is excluded.
