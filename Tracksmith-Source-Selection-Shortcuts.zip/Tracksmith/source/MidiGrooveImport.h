#pragma once
#include "MidiLane.h"
#include <algorithm>
// Build a complete candidate first; a failed import never changes the destination.
inline bool appendMidiGroove(juce::InputStream& stream,double beat,std::vector<MidiNote>& notes)
{
 if(!std::isfinite(beat)||beat<0||beat>=100000)return false;
 juce::MidiFile midi;if(!midi.readFrom(stream)||midi.getTimeFormat()<=0)return false;
 auto candidate=notes;int id=0;for(const auto& n:notes)id=std::max(id,n.id);size_t added=0;
 for(int lane=0;lane<midi.getNumTracks();++lane){juce::MidiMessageSequence sequence(*midi.getTrack(lane));sequence.updateMatchedPairs();for(int i=0;i<sequence.getNumEvents();++i){auto* event=sequence.getEventPointer(i);if(event->message.isNoteOn()){if(!event->noteOffObject)return false;const auto& m=event->message;MidiNote n{++id,m.getNoteNumber(),m.getChannel(),beat+m.getTimeStamp()/midi.getTimeFormat(),(event->noteOffObject->message.getTimeStamp()-m.getTimeStamp())/midi.getTimeFormat(),m.getFloatVelocity()};if(!validMidiNote(n)||candidate.size()>=MidiLane::maximumNotes)return false;candidate.push_back(n);++added;}}}
 if(!added)return false;
 std::sort(candidate.begin(),candidate.end(),[](const auto& a,const auto& b){return a.start<b.start;});
 for(size_t i=0;i<candidate.size();++i)for(size_t j=i+1;j<candidate.size();++j)if(candidate[i].pitch==candidate[j].pitch&&candidate[i].channel==candidate[j].channel&&candidate[j].start<candidate[i].start+candidate[i].length-1.e-8)return false;
 notes=std::move(candidate);return true;
}
