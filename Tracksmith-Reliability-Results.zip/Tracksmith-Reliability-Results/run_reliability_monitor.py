from pathlib import Path
import subprocess,time,json,ctypes
from ctypes import wintypes
base=Path(r'C:/Users/tiaii/Documents/Codex/2026-10-13/referenced-chatgpt-conversation-this-is-an')
local=Path(__file__).resolve().parent
exe=base/'work/native-build/PluginHostTests_artefacts/Release/PluginHostTests.exe'
args=[str(exe),str(base/'work/native-build/Tracksmith_artefacts/Release/Stock Plugins/AVRX NAM.vst3'),str(base/'work/native-build/DelayFixture_artefacts/Release/VST3/Tracksmith Delay Test.vst3'),str(local/'TracksmithGroove/Grooves/GGD Rock Groove Pack'),'--soak','120']
log=local/'reliability-120s.log'
class Memory(ctypes.Structure):
 _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(name,ctypes.c_size_t) for name in ['PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage','PrivateUsage']]
kernel=ctypes.WinDLL('kernel32',use_last_error=True);kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE;kernel.CloseHandle.argtypes=[wintypes.HANDLE]
memory_api=kernel.K32GetProcessMemoryInfo;memory_api.argtypes=[wintypes.HANDLE,ctypes.POINTER(Memory),wintypes.DWORD];memory_api.restype=wintypes.BOOL
samples=[];seen='';began=time.monotonic()
with log.open('w',encoding='utf-8') as output:
 process=subprocess.Popen(args,cwd=base,stdout=output,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
 handle=kernel.OpenProcess(0x410,False,process.pid)
 while process.poll() is None:
  values=Memory();values.cb=ctypes.sizeof(values)
  if handle and memory_api(handle,ctypes.byref(values),values.cb):samples.append({'seconds':round(time.monotonic()-began,2),'privateMB':round(values.PrivateUsage/1048576,2),'workingSetMB':round(values.WorkingSetSize/1048576,2),'peakWorkingSetMB':round(values.PeakWorkingSetSize/1048576,2)})
  output.flush();text=log.read_text(encoding='utf-8',errors='replace')
  if text!=seen:
   print(text[len(seen):],end='',flush=True);seen=text
  if time.monotonic()-began>240:
   process.terminate();raise RuntimeError('Soak exceeded the bounded 240-second watchdog')
  time.sleep(1)
 if handle:kernel.CloseHandle(handle)
output=log.read_text(encoding='utf-8',errors='replace');print(output[len(seen):],end='',flush=True)
resource={'exitCode':process.returncode,'wallSeconds':round(time.monotonic()-began,2),'memorySamples':samples,'peakPrivateMB':max((s['privateMB'] for s in samples),default=None),'peakWorkingSetMB':max((s['peakWorkingSetMB'] for s in samples),default=None)}
warm=[s for s in samples if 20<=s['seconds']<=40];late=[s for s in samples if s['seconds']>=100]
if warm and late:resource.update({'warmMinimumPrivateMB':min(s['privateMB'] for s in warm),'lateMinimumPrivateMB':min(s['privateMB'] for s in late),'privateFloorChangeMB':round(min(s['privateMB'] for s in late)-min(s['privateMB'] for s in warm),2)})
(local/'reliability-resources.json').write_text(json.dumps(resource,indent=2),encoding='utf-8')
print('RESOURCE_SUMMARY',json.dumps({k:v for k,v in resource.items() if k!='memorySamples'}),flush=True)
raise SystemExit(process.returncode)
