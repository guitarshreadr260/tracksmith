# Tracksmith — GGD MIDI fix

Fixes rejected GGD groove imports, with duplicate-hit normalization, visible import results and automatic scrolling to imported notes. All 225 saved GGD Rock grooves pass import checks. See GGD-MIDI-FIX-GUIDE.md.

Includes the previous MIDI selection/shortcut and track context-menu features. Save and close the older Tracksmith, extract the entire ZIP and open Tracksmith.exe. Windows x64 and WebView2 required; keep Stock Plugins beside the app. Session format 9. Live GGD drag/hardware review remains pending.
