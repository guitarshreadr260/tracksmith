import { defineConfig } from 'vite';
export default defineConfig({ base: './', resolve: { preserveSymlinks: true }, build: { assetsDir: '', rollupOptions: { output: { entryFileNames: 'app.js', assetFileNames: 'app.[ext]' } } } });
