#pragma once
#include <array>
#include <algorithm>
#include <cmath>

struct InputRouting
{
    static std::array<const float*, 2> select(const float* const* inputs, int count, int first, int channels) noexcept
    {
        std::array<const float*, 2> result {}; int active = 0, found = 0;
        if (!inputs || first < 0 || channels < 1 || channels > 2) return result;
        for (int ch = 0; ch < count && found < channels; ++ch)
            if (inputs[ch] && active++ >= first) result[static_cast<size_t>(found++)] = inputs[ch];
        return result;
    }
    static float sample(const float* input, int frame) noexcept
    { return input && std::isfinite(input[frame]) ? std::clamp(input[frame], -1.0f, 1.0f) : 0.0f; }
};
